import { Endpoints } from "./../config/endpoints"
import useJwt from "@src/auth/jwt/useJwt"

export async function login(data) {
  return await useJwt
    .post(Endpoints.login, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function register(data) {
  return await useJwt
    .post(Endpoints.register, data)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function verifyEmail(data) {
  return await useJwt
    .post(Endpoints.verifyEmail, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function resendOtp(data) {
  return await useJwt
    .post(Endpoints.resendOtp, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function forgotPassword(data) {
  return await useJwt
    .post(Endpoints.forgotPassword, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function resetPasswordTokenVerify(data) {
  return await useJwt
    .get(`${Endpoints.resetPassword}/${data.token}`)
    .then((res) => res)
    .catch((err) => err)
}

export async function resetPassword(data) {
  return await useJwt
    .post(`${Endpoints.resetPassword}?token=${data.token}`, {
      password: `${data.password}`
    })
    .then((res) => res)
    .catch((err) => err)
}

export async function changePassword(data) {
  return await useJwt
    .post(`${Endpoints.changePassword}`, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function createUser(data) {
  return await useJwt
    .post(`${Endpoints.user}`, data)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function getAllUsers(data) {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `&limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params += data.isActive ? `&isActive=${data.isActive}` : ""
    params += data.isBlocked ? `&isBlocked=${data.isBlocked}` : ""
    params += data.isEmailVerified
      ? `&isEmailVerified=${data.isEmailVerified}`
      : ""
  }
  return await useJwt
    .get(`${Endpoints.user}?role=user${params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function getRecommendedUsers(data) {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `&limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params += data.isActive ? `&isActive=${data.isActive}` : ""
    params += data.isBlocked ? `&isBlocked=${data.isBlocked}` : ""
    params += data.isEmailVerified
      ? `&isEmailVerified=${data.isEmailVerified}`
      : ""
  }
  return await useJwt
    .get(`${Endpoints.recommendedUsers}?role=user${params}`)
    .then((res) => res.data)
    .catch((err) => err)
}
export async function getUser(data) {
  return await useJwt
    .get(`${Endpoints.user}/${data}`)
    .then((res) => res)
    .catch((err) => err)
}

export async function updateUser(data) {
  return await useJwt
    .patch(`${Endpoints.user}/${data.params}`, data.body)
    .then((res) => res)
    .catch((err) => err)
}

export async function deleteUser(data) {
  return await useJwt
    .delete(`${Endpoints.user}/specific/${data.params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function blockUser(data) {
  return await useJwt
    .patch(`${Endpoints.user}/${data.params}/block`, data.body)
    .then((res) => res)
    .catch((err) => err)
}

export async function getLoggedInUser() {
  return await useJwt
    .get(`${Endpoints.loggedInUser}`)
    .then((res) => res)
    .catch((err) => err)
}

// ---------------------------------------------------

// createCourse,
// deleteCourse,
// getAllCourses,
// updateCourse

export async function getAllCourses(data) {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params = params ? `?${params}` : ""
  }

  return await useJwt
    .get(`${Endpoints.getAllCourses}${params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function createCourse(data) {
  return await useJwt
    .post(`${Endpoints.getAllCourses}`, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function updateCourse(data) {
  return await useJwt
    .patch(`${Endpoints.getAllCourses}/${data.params}`, data.body)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function deleteCourse(data) {
  return await useJwt
    .delete(`${Endpoints.getAllCourses}/${data.params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

// createInterest,
// deleteInterest,
// getAllInterest,
// updateInterest

export async function getAllInterest(data) {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params = params ? `?${params}` : ""
  }
  return await useJwt
    .get(`${Endpoints.getAllInterest}${params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function createInterest(data) {
  return await useJwt
    .post(`${Endpoints.getAllInterest}`, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function updateInterest(data) {
  return await useJwt
    .patch(`${Endpoints.getAllInterest}/${data.params}`, data.body)
    .then((res) => res.data)
    .catch((err) => err)
}

export async function deleteInterest(data) {
  return await useJwt
    .delete(`${Endpoints.getAllInterest}/${data.params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export const createGroup = (data) =>
  useJwt
    .post(Endpoints.createGroup, data)
    .then((res) => res)
    .catch((err) => err)

export const getCreatedGroups = (data) => {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params = params ? `?${params}` : ""
  }
  return useJwt
    .get(`${Endpoints.getCreatedGroups}${params}`)
    .then((res) => res.data)
    .catch((err) => err)
}

export const getMyGroups = (data) => {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params = params ? `?${params}` : ""
  }
  return useJwt
    .get(`${Endpoints.getMyGroups}${params}`)
    .then((res) => res)
    .catch((err) => err)
}

export const getOtherGroups = (data) => {
  let params = ""
  if (data) {
    const { perPage, page } = data
    params += perPage ? `limit=${perPage}` : ""
    params += page ? `&page=${page}` : ""
    params = params ? `?${params}` : ""
  }
  return useJwt
    .get(`${Endpoints.getOtherGroups}${params}`)
    .then((res) => res)
    .catch((err) => err)
}

export const joinGroup = (groupId) =>
  useJwt
    .patch(`${Endpoints.joinGroup}/${groupId}`)
    .then((res) => res)
    .catch((err) => err)

export const takeAction = (data) =>
  useJwt
    .patch(`${Endpoints.takeAction}/${data.groupId}/${data.userId}`, data.body)
    .then((res) => res)
    .catch((err) => err)

// export const addMembers = (groupId, members) =>
//   useJwt.patch(`${Endpoints.addMembers}/${groupId}`, members)
//     .then((res) => res.data)
//     .catch((err) => err)

// export const addCourses = (groupId, courses) =>
//   useJwt.patch(`${Endpoints.addCourses}/${groupId}`, courses)
//     .then((res) => res.data)
//     .catch((err) => err)

export const editGroup = (data) =>
  useJwt
    .patch(`${Endpoints.editGroup}/${data.groupId}`, data.body)
    .then((res) => res)
    .catch((err) => err)

export const getJoinRequests = () =>
  useJwt
    .get(`${Endpoints.getJoinRequests}`)
    .then((res) => res)
    .catch((err) => err)

export const getGroupDetails = (groupId) =>
  useJwt
    .get(`${Endpoints.getGroupDetails}/${groupId}`)
    .then((res) => res)
    .catch((err) => err)

export const getSearch = (data) =>
  useJwt
    .get(`${Endpoints.getSearch}?search=${data}`)
    .then((res) => res)
    .catch((err) => err)

export const getChatHistory = (data) =>
  useJwt
    .get(`${Endpoints.getChatHistory}/${data}`)
    .then((res) => res)
    .catch((err) => err)

export const updateExp = (data) =>
  useJwt
    .patch(`${Endpoints.Exp}/${data.params}`, data.body)
    .then((res) => res)
    .catch((err) => err)

export const updateEdu = (data) =>
  useJwt
    .patch(`${Endpoints.Edu}/${data.params}`, data.body)
    .then((res) => res)
    .catch((err) => err)

export const addExp = (data) =>
  useJwt
    .post(`${Endpoints.Exp}`, data)
    .then((res) => res)
    .catch((err) => err)

export const addEdu = (data) =>
  useJwt
    .post(`${Endpoints.Edu}`, data)
    .then((res) => res)
    .catch((err) => err)

export const deleteExp = (data) =>
  useJwt
    .delete(`${Endpoints.Exp}/${data}`)
    .then((res) => res)
    .catch((err) => err)

export const deleteEdu = (data) =>
  useJwt
    .delete(`${Endpoints.Edu}/${data}`)
    .then((res) => res)
    .catch((err) => err)

export const updateInterestsAndCourses = (data) =>
  useJwt
    .patch(`${Endpoints.updateInterestsAndCourses}/${data.params}`, data.body)
    .then((res) => res)
    .catch((err) => err)

export const uploadProfileImage = async (data) => {
  return await useJwt
    .post(Endpoints.uploadProfileImage, data)
    .then((res) => res)
    .catch((err) => err)
}

export const deactivateAccount = (data) => {
  return useJwt
    .post(Endpoints.deactivateAccount, data)
    .then((res) => res)
    .catch((err) => err)
}

export const getStats = () => {
  return useJwt
    .get(`${Endpoints.getStats}`)
    .then((res) => res)
    .catch((err) => err)
}

export const getGroupChatHistory = (data) => {
  return useJwt
    .get(`${Endpoints.getGroupChatHistory}/${data}`)
    .then((res) => res)
    .catch((err) => err)
}


export const  uploadChatMedia = (data) => {
  return useJwt
    .post(`${Endpoints.uploadChatMedia}`, data)
    .then((res) => res)
    .catch((err) => err)
}

export async function uploadFiles(data) {
  const formData = new FormData()
  for (const file of data) {
    formData.append("documents", file)
  }
  return useJwt
    .post(Endpoints.uploadFiles, formData)
    .then((res) => res.data)
    .catch((err) => err)
}

//chatNotification
export const chatNotification = (data) => {
  return useJwt
    .get(`${Endpoints.chatNotification}`)
    .then((res) => res)
    .catch((err) => err)
}


export const removeMember = (data) => {
  return useJwt.patch(`${Endpoints.removeMember}/${data.groupId}/${data.userId}`)
  .then((res) => res)
  .catch((err) => err)
}

export const leaveGroup = (data) => {
  return useJwt.patch(`${Endpoints.leaveGroup}/${data.groupId}`)
  .then((res) => res)
  .catch((err) => err)

}
