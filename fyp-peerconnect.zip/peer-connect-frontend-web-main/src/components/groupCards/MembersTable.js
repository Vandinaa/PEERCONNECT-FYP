import "@styles/react/libs/tables/react-dataTable-component.scss"
import { Fragment, useEffect, useState } from "react"

import Avatar from "@components/avatar"

import { Button, Card, CardHeader, CardTitle, Col, Row } from "reactstrap"

import { useNavigate } from "react-router-dom"

import DataTable from "react-data-table-component"
import { useTranslation } from "react-i18next"
import { ChevronDown } from "react-feather"

import * as groupActions from "@src/store/common/groupManagement/actions"
import { useDispatch, useSelector } from "react-redux"


function MembersTable({ members, groupId }) {
  const { t } = useTranslation()

  const navigate = useNavigate()

  const [data, setData] = useState([])

  const dispatch = useDispatch()
  const { deleted , updated } = useSelector((state) => state.groupManagementReducer)

  useEffect(() => {
    if (deleted || updated ) {
      console.log("deleted",groupId)
      dispatch(groupActions.getGroupDetailsRequest(groupId))
    }
  }, [deleted,updated])

  const renderClient = (row) => {
    if (row.hasOwnProperty("avatar") && row.avatar.length) {
      return <Avatar className="me-1" img={row.avatar} width="32" height="32" />
    } else {
      return (
        <Avatar
          initials
          className="me-1"
          color={row.avatarColor || "light-primary"}
          content={row.name != "" ? row.name.charAt(0).toUpperCase() : "N/A"}
        />
      )
    }
  }


  const handleRemoveMember = (userId) => {
    dispatch(groupActions.removeMemberRequest({ groupId, userId }))
  }

  const ColumnsHeader = [
    {
      name: "FULL NAME",
      minWidth: "250px",
      selector: (row) => row.name,
      cell: (row) => (
        <div
          className="d-flex justify-content-left align-items-center cursor-pointer"
          onClick={() => navigate(`/profile?id=${row.id}`)}
        >
          {renderClient(row)}
          <div className="d-flex flex-column">
            <div className="user_name text-truncate text-body text-capitalize">
              <span className="fw-bolder text-primary">{row.name}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      name: t("EMAIL"),
      minWidth: "250px",
      selector: (row) => row.email,
      cell: (row) => {
        return (
          <div
            className={`d-flex justify-content-left align-items-center ${
              row.isEmailVerified ? "text-success" : "text-warning"
            }`}
          >
            <span>{row.email}</span>
          </div>
        )
      }
    },
    {
      name: t("PHONE"),
      sortable: true,
      minWidth: "250px",
      selector: (row) => row.phone
    },
    {
      name: "Actions",
      minWidth: "150px",
      cell: (row) => (
        <Button color="danger" size="sm" onClick={() => handleRemoveMember(row.id)}>
          Remove
        </Button>
      )
    }
  ]

  useEffect(() => {
    if (members?.length) {
      const a = members.map((item, index) => {
        return {
          id: item.id,
          name: item.personalInfo?.fullName || "",
          email: item.email || "",
          phone: item.personalInfo?.phone || "",
          isEmailVerified: item?.isEmailVerified ?? true
        }
      })
      setData(a)
    } else {
      setData([])
    }
  }, [members])

  return (
    <Fragment>
      <Card>
        <Row>
          <Col sm="12">
            <CardHeader className="flex-md-row flex-column align-md-items-center align-items-start border-bottom">
              <CardTitle tag="h4">{t("Members")}</CardTitle>
            </CardHeader>
            <div className="react-dataTable">
              <DataTable
                noHeader
                columns={ColumnsHeader}
                className="react-dataTable"
                sortIcon={<ChevronDown size={10} />}
                data={data}
              />
            </div>
          </Col>
        </Row>
      </Card>
    </Fragment>
  )
}

export default MembersTable
