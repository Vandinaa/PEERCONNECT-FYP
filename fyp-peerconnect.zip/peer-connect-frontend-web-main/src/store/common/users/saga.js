import * as usersActions from "./actions"

import { all, call, put, takeEvery } from "redux-saga/effects"
import {
  blockUser,
  createUser,
  getUser,
  deleteUser,
  getAllUsers,
  updateUser,
  getRecommendedUsers,
  updateExp,
  updateEdu,
  addExp,
  addEdu,
  deleteExp,
  deleteEdu,
  updateInterestsAndCourses,
  uploadProfileImage,
  deactivateAccount,
  getStats

} from "@src/services/apis"

import { USERS_TYPES } from "./types"
import toast from "react-hot-toast"

function* getAllUsersRequest(action) {
  try {
    const response = yield call(getAllUsers, action.payload)
    yield put(usersActions.getAllUsersSuccess(response))
  } catch (err) {
    yield put(usersActions.getAllUsersFailure(err))
  }
}

function* getRecommendedUsersRequest(action) {
  try {
    const response = yield call(getRecommendedUsers, action.payload)
    yield put(usersActions.getRecommendedUsersSuccess(response))
  } catch (err) {
    yield put(usersActions.getRecommendedUsersFailure(err))
  }
}







function* getUserRequest(action) {
  try {
    const response = yield call(getUser, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.getUserSuccess(response.data))
    }
    else if(response?.response?.data?.code === 400){
      toast.error("User Not Found")
      yield put(usersActions.getUserFailure("User Not Found"))
    }
    else {
      yield put(usersActions.getUserFailure(response))
    }
  } catch (err) {
    yield put(usersActions.getUserFailure(err))
  }
}



function* createUserRequest(action) {
  try {
    const response = yield call(createUser, action.payload)
    if (response?.response?.status === 409) {
      yield put(
        usersActions.createUserFailure(response?.response?.data?.message)
      )
    } else if (response?.status === 201) {
      yield put(usersActions.createUserSuccess(response.message))
    }
  } catch (err) {
    yield put(usersActions.createUserFailure(err))
  }
}

function* updateUserRequest(action) {
  try {

    const response = yield call(updateUser, action.payload)
    if (response?.status === 200) {
    yield put(usersActions.updateUserSuccess(response.data))
    }
    else {
      toast.error("Something went wrong")
      yield put(usersActions.updateUserFailure(response))
    }
  } catch (err) {
    yield put(usersActions.updateUserFailure(err))
  }
}

function* deleteUserRequest(action) {
  try {
    const response = yield call(deleteUser, action.payload)
    yield put(usersActions.deleteUserSuccess(response.data))
  } catch (err) {
    yield put(usersActions.deleteUserFailure(err))
  }
}

function* blockUserRequest(action) {
  try {
    const response = yield call(blockUser, action.payload)
    if(response?.status === 200){
      yield put(usersActions.blockUserSuccess(response.data))
    }else {
      yield put(usersActions.blockUserFailure(response))
    }
  } catch (err) {
    yield put(usersActions.blockUserFailure(err))
  }
}


function* getLoggedInUserRequest(action) {
  try {
    const response = yield call(getUser, action.payload)
    if(response?.status === 200){
      yield put(usersActions.getLoggedInUserSuccess(response.data))
    }
    else {
      yield put(usersActions.getLoggedInUserFailure(response))
    }

  } catch (err) {
    yield put(usersActions.getLoggedInUserFailure(err))
  }
}
// use updateExperienceRequest for update experience and Success and Failure
function* updateExperienceRequest(action) {
  try {
    const response = yield call(updateExp, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.updateExperienceSuccess(response.data))
    }
    else {
      yield put(usersActions.updateExperienceFailure(response))
    }
  } catch (err) {
    yield put(usersActions.updateExperienceFailure(err))
  }
}

function* updateEducationRequest(action) {
  try {
    const response = yield call(updateEdu, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.updateEducationSuccess(response.data))
    }
    else {
      yield put(usersActions.updateEducationFailure(response))
    }
  } catch (err) {
    yield put(usersActions.updateEducationFailure(err))
  }
}

//Add

function* addExperienceRequest(action) {
  try {
    const response = yield call(addExp, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.addExperienceSuccess(response.data))
    }
    else {
      yield put(usersActions.addExperienceFailure(response))
    }
  } catch (err) {
    yield put(usersActions.addExperienceFailure(err))
  }
}

function* addEducationRequest(action) {
  try {
    const response = yield call(addEdu, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.addEducationSuccess(response.data))
    }
    else {
      yield put(usersActions.addEducationFailure(response))
    }
  } catch (err) {
    yield put(usersActions.addEducationFailure(err))
  }
}

//Delete

function* deleteExperienceRequest(action) {
  try {
    const response = yield call(deleteExp, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.deleteExperienceSuccess(response.data))
    }
    else {
      yield put(usersActions.deleteExperienceFailure(response))
    }
  } catch (err) {
    yield put(usersActions.deleteExperienceFailure(err))
  }
}

function* deleteEducationRequest(action) {
  try {
    const response = yield call(deleteEdu, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.deleteEducationSuccess(response.data))
    }
    else {
      yield put(usersActions.deleteEducationFailure(response))
    }
  } catch (err) {
    yield put(usersActions.deleteEducationFailure(err))
  }
}

// updateInterestsAndCourses
function* updateInterestsAndCoursesRequest(action) {
  try {
    const response = yield call(updateInterestsAndCourses, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.updateInterestsAndCoursesSuccess(response.data))
    }
    else {
      yield put(usersActions.updateInterestsAndCoursesFailure(response))
    }
  } catch (err) {
    yield put(usersActions.updateInterestsAndCoursesFailure(err))
  }
}

function* uploadProfileImageRequest(action) {
  try {
    const response = yield call(uploadProfileImage, action.payload)
    if (response?.status === 200) {
      yield put(usersActions.uploadProfileImageSuccess(response.data))
    }
    else {
      yield put(usersActions.uploadProfileImageFailure(response))
    }
  } catch (err) {
    yield put(usersActions.uploadProfileImageFailure(err))
  }
}

function* deactivateAccountRequest(action){
  try{
    const response = yield call(deactivateAccount, action.payload)
    if(response?.status === 200){
      toast.success("Account Deactivated Successfully")
      yield put(usersActions.deactivateAccountSuccess(response.data))
    }
    else {
      yield put(usersActions.deactivateAccountFailure(response))
    }
  }catch(err){
    yield put(usersActions.deactivateAccountFailure(err))
  }
}

function* getStatsRequestSaga(action){
  try{
    const response = yield call(getStats, action.payload)
    if(response?.status === 200){
      yield put(usersActions.getStatsSuccess(response.data))
    }
    else {
      yield put(usersActions.getStatsFailure(response))
    }
  }catch(err){
    yield put(usersActions.getStatsFailure(err))
  }
}







export default function* usersSaga() {
  yield all([
    takeEvery(USERS_TYPES.GET_ALL_USERS_REQUEST, getAllUsersRequest),
    takeEvery(USERS_TYPES.GET_RECOMMENDED_USERS_REQUEST, getRecommendedUsersRequest),
    takeEvery(USERS_TYPES.CREATE_USER_REQUEST, createUserRequest),
    takeEvery(USERS_TYPES.GET_USER_REQUEST, getUserRequest),
    takeEvery(USERS_TYPES.UPDATE_USER_REQUEST, updateUserRequest),
    takeEvery(USERS_TYPES.GET_LOGGED_IN_USER_REQUEST, getLoggedInUserRequest),
    takeEvery(USERS_TYPES.DELETE_USER_REQUEST, deleteUserRequest),
    takeEvery(USERS_TYPES.BLOCK_USER_REQUEST, blockUserRequest),
    takeEvery(USERS_TYPES.UPDATE_EXPERIENCE_REQUEST, updateExperienceRequest),
    takeEvery(USERS_TYPES.UPDATE_EDUCATION_REQUEST, updateEducationRequest),
    takeEvery(USERS_TYPES.ADD_EXPERIENCE_REQUEST, addExperienceRequest),
    takeEvery(USERS_TYPES.ADD_EDUCATION_REQUEST, addEducationRequest),
    takeEvery(USERS_TYPES.DELETE_EXPERIENCE_REQUEST, deleteExperienceRequest),
    takeEvery(USERS_TYPES.DELETE_EDUCATION_REQUEST, deleteEducationRequest),
    takeEvery(USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_REQUEST, updateInterestsAndCoursesRequest),
    takeEvery(USERS_TYPES.UPLOAD_PROFILE_IMAGE_REQUEST, uploadProfileImageRequest),
    takeEvery(USERS_TYPES.DEACTIVATE_ACCOUNT_REQUEST, deactivateAccountRequest),
    takeEvery(USERS_TYPES.GET_STATS_REQUEST, getStatsRequestSaga)
    
  ])
}
