import * as securityActions from "@src/store/common/security/actions"
import * as yup from "yup"

import {
  Alert,
  Button,
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Col,
  Form,
  FormFeedback,
  Row,
  Spinner
} from "reactstrap"
import { Controller, useForm } from "react-hook-form"
import { Fragment } from "react"
import { useDispatch, useSelector } from "react-redux"

import { AlertCircle } from "react-feather"
import InputPasswordToggle from "@components/input-password-toggle"
import { useEffect } from "react"
import { yupResolver } from "@hookform/resolvers/yup"
import { useTranslation } from "react-i18next"

const showErrors = (field, valueLen, min) => {
  if (valueLen === 0) {
    return `${field} field is required`
  } else if (valueLen > 0 && valueLen < min) {
    return `${field} must be at least ${min} characters`
  } else {
    return ""
  }
}
const defaultValues = {
  currentPassword: ""
}

const ChangePasswordCard = () => {
  const { t } = useTranslation()
  const dispatch = useDispatch()

  const { loading, error, success, message, data } = useSelector(
    (state) => state.securityReducer
  )

  useEffect(() => {
    if (success) {
      reset(defaultValues)
    }
  }, [success])

  const SignupSchema = yup.object().shape({
    currentPassword: yup
      .string()
      .min(8, (obj) =>
        showErrors("Current Password", obj.value.length, obj.min)
      )
      .required()
  })
  const {
    control,
    handleSubmit,
    setError,
    reset,
    formState: { errors }
  } = useForm({
    defaultValues,
    resolver: yupResolver(SignupSchema)
  })

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field.length > 0)) {
      const payload = {
        password: data.currentPassword
      }

      dispatch(securityActions.changePasswordRequest(payload))

      //return null
    } else {
      for (const key in data) {
        if (data[key].length === 0) {
          setError(key, {
            type: "manual"
          })
        }
      }
    }
  }

  return (
    <Fragment>
      <Card>
        <CardHeader className="border-bottom">
          <CardTitle tag="h4">{t("Change Password")}</CardTitle>
        </CardHeader>
        <CardBody className="pt-1">
          <Alert
            color={error !== "" ? "danger" : success ? "success" : "danger"}
            isOpen={error !== "" || success}
            toggle={() =>
              dispatch(securityActions.clearChangePasswordResponse())
            }
          >
            <div className="alert-body">
              <AlertCircle size={15} />{" "}
              <span className="ms-1">
                {error !== "" ? error : success ? message : ""}
              </span>{" "}
            </div>
          </Alert>

          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col sm="6" className="mb-1">
                <Controller
                  control={control}
                  id="currentPassword"
                  name="currentPassword"
                  render={({ field }) => (
                    <InputPasswordToggle
                      label={t("Current Password")}
                      htmlFor="currentPassword"
                      className="input-group-merge"
                      invalid={errors.currentPassword && true}
                      {...field}
                    />
                  )}
                />
                {errors.currentPassword && (
                  <FormFeedback className="d-block">
                    {errors.currentPassword.message}
                  </FormFeedback>
                )}
              </Col>
            </Row>
            <Row>
              <Col className="mt-1" sm="12">
                <Button
                  type="submit"
                  className="me-1"
                  color="primary"
                  disabled={loading}
                >
                  {loading ? <Spinner className="me-1" size="sm" /> : null}
                  {t("Reset Password")}
                </Button>
                <Button
                  color="secondary"
                  outline
                  type="button"
                  onClick={() => {
                    dispatch(securityActions.clearChangePasswordResponse())
                    reset(defaultValues)
                  }}
                  disabled={loading}
                >
                  {t("Cancel")}
                </Button>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
    </Fragment>
  )
}

export default ChangePasswordCard
