import * as Yup from "yup"
import * as courseActions from "@src/store/common/courses/actions"
import Select from "react-select"

import { selectThemeColors } from "@utils"
import makeAnimated from "react-select/animated"

import * as interestActions from "@src/store/common/interests/actions"

import {
  Alert,
  Button,
  Form,
  FormText,
  Input,
  Label,
  Spinner
} from "reactstrap"
import { fieldExists, isNullObject, isObjEmpty } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Sidebar from "@components/sidebar"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"
import { categoriesOptions } from "@src/utility/Options"

const AddCourseForm = ({ open, toggleSidebar, formType, data }) => {

  const [isSubmit, setSubmit] = useState(false)
  const dispatch = useDispatch()
  const { t } = useTranslation()
  const animatedComponents = makeAnimated()

  const { interests } = useSelector((state) => state.interestReducer)

  const { deleted, updated, created, createdUpdatedLoading } = useSelector(
    (state) => state.courseReducer
  )

  const [interestsOptions, setInterestsOptions] = useState([])

  useEffect(() => {
    if (updated || created) resetForm()
  }, [updated, created])
  
  useEffect(() => {
    if (fieldExists(interests, "results") && interests.results.length > 0) {
      const a = interests.results.map((item, index) => {
        return {
          value: item.id,
          label: item.interestName
        }
      })
      setInterestsOptions(a)
    }else {
      setInterestsOptions([])
    }
  }, [interests])

  useEffect(() => {
    if (isObjEmpty(!isNullObject(interests))) {
      dispatch(
        interestActions.getAllInterestRequest({
          perPage: 1000,
          page: 1
        })
      )
    }
  }, [dispatch])



  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    resetForm
  } = useFormik({
    initialValues: {
      name: "",
      code : "",
      description : "",
      interests : [],
    },
    validationSchema: Yup.object().shape({
      name: Yup.string().required(t("Course Name is required")),
      code: Yup.string().required(t("Course Code is required")),
      description: Yup.string().required(t("Description is required")),
      interests: Yup.array().min(1, t("At least one interest is required"))
    }),
    onSubmit: (values) => {
      if (formType === "edit") {
        dispatch(
          courseActions.updateCourseRequest({
            params: data.id,
            body: {
              courseName: values.name,
              courseCode: values.code,
              courseDescription: values.description,
              interests: values.interests.map((interest) => interest.value)
            }
          })
        )
      } else if (formType === "add") {
        dispatch(
          courseActions.createCourseRequest({
            courseName: values.name,
            courseCode: values.code,
            courseDescription: values.description,
            interests: values.interests.map((interest) => interest.value)

          })
        )
      }
      setSubmit(false)
      //toggleSidebar()
    }
  })

  useEffect(() => {

    setSubmit(false)
    if (formType === "edit" && !isNullObject(data)) {
      setFieldValue("name", data.name)
      setFieldValue("code", data.code)
      setFieldValue("description", data.description)
      setFieldValue("interests", interestsOptions.filter((interest) => 
        data.interests.some((item) => item.id === interest.value)
      ))

    } else {
      
      setFieldValue("name", "")
      setFieldValue("code", "")
      setFieldValue("description", "")
      setFieldValue("interests", [])

    }
  }, [data,interestsOptions])

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={`${formType === "edit" ? t("Edit") : t("Add")} ${t("Course")}`}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmit(true)
          handleSubmit()
        }}
      >
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Course Name")}*
          </Label>
          <Input
            type="text"
            name="name"
            onChange={handleChange}
            value={values.name}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder="Enter Course Name"
          />
          {isSubmit && errors.name && touched.name && (
            <div className="text-danger">{errors.name}</div>
          )}
        </div>
        <div className="mb-1">
            <label className="form-label" htmlFor="code">
              {t("Course Code")}*
            </label>
            <Input
              type="text"
              name="code"
              id="code"
              placeholder="Enter Course Code"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.code}
            />
            {isSubmit && errors.code && touched.code && (
              <div className="text-danger">{errors.code}</div>
            )}
          </div>

          <div className="mb-1">
            <label className="form-label" htmlFor="description">
              {t("Description")}*
            </label>
            <Input
              type="textarea"
              name="description"
              id="description"
              placeholder="Enter Description"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.description}
              rows="3"
            />
            {isSubmit && errors.description && touched.description && (
              <div className="text-danger">{errors.description}</div>
            )}
          </div>
          <div className="mb-1">
            <Label for="interests" className="form-label">
              
              {t("Interests")}* 
            </Label>
            <Select
              id="interests"
              theme={selectThemeColors}
              className="react-select"
              classNamePrefix="select"
              options={interestsOptions}
              isClearable={false}
              components={animatedComponents}
              closeMenuOnSelect={true}
              isMulti
              name="interests"
              value={values.interests}
              onChange={(value) => {
                setFieldValue("interests", value)
              }}
              onBlur={handleBlur}
            />
            {isSubmit && errors.interests && (
              <div className="text-danger text-small mt-50">
                {errors.interests}
              </div>
            )}
            </div>









        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={createdUpdatedLoading}
          >
            {createdUpdatedLoading ? (
              <Spinner className="me-1" size="sm" />
            ) : null}
            {t("Save")}
          </Button>
          <Button
            color="secondary"
            outline
            onClick={() => {
              toggleSidebar()
              setSubmit(false)
            }}
            disabled={createdUpdatedLoading}
          >
            {t("Cancel")}
          </Button>
        </div>
      </Form>
      {createdUpdatedLoading ? (
        <Alert color="success">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">
                  {formType === "edit" ? t("Updating") : t("Adding")}...
                </span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
    </Sidebar>
  )
}

export default AddCourseForm
