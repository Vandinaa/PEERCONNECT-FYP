import { GROUP_MANAGEMENT_TYPES } from "./types"
import toast from "react-hot-toast"

const initialState = {
  myGroups: {},
  otherGroups: {},
  createdGroups: {},
  error: null,
  actionTakingLoading: false,
  joinGroupLoading: false, // loading to join-group
  fetchingGroups: false,
  updated:false,
  created:false,
  deleted:false,
  leaves:false,
  requestSend:false,
  creationLoading: false,
  fetchingJoinRequests:false,
  groupNotFound : false,
  actionSuccess:false,
  joinRequests:{},
  groupDetails:{},
}

const groupManagementReducer = (state = initialState, action) => {
  switch (action.type) {

    case GROUP_MANAGEMENT_TYPES.CREATE_GROUP_REQUEST:
      return {
        ...state,
        created : false,
        creationLoading: true,
      }

    case GROUP_MANAGEMENT_TYPES.CREATE_GROUP_SUCCESS:
       return {

        ...state,
        created : true,
        creationLoading: false,
      }

    case GROUP_MANAGEMENT_TYPES.CREATE_GROUP_FAIL:
      return {
        ...state,
        creationLoading: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_REQUEST:
      return {
        ...state,
        fetchingGroups: true,
      }

    case GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_SUCCESS:

      return {
        ...state,
        createdGroups: action.payload,
        fetchingGroups: false,
      }

    case GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_FAIL:
      return {
        ...state,
        fetchingGroups: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_REQUEST:
      return {
        ...state,
        fetchingGroups: true,
      }

    case GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_SUCCESS:
      return {
        ...state,
        myGroups: action.payload,
        fetchingGroups: false,
      }

    case GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_FAIL:
      return {
        ...state,
        fetchingGroups: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_REQUEST:
      return {
        ...state,
        fetchingGroups: true,
        otherGroups: {},
      }

    case GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_SUCCESS:
      return {
        ...state,
        otherGroups: action.payload,
        fetchingGroups: false,
      }

    case GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_FAIL:
      return {
        ...state,
        fetchingGroups: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.JOIN_GROUP_REQUEST:
      return {
        ...state,
        requestSend: false,
        joinGroupLoading: true,
      }

    case GROUP_MANAGEMENT_TYPES.JOIN_GROUP_SUCCESS:
      return {
        ...state,
        requestSend: true,
        joinGroupLoading: false,
      }

    case GROUP_MANAGEMENT_TYPES.JOIN_GROUP_FAIL:
      return {
        ...state,
        requestSend: false,
        joinGroupLoading: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.TAKE_ACTION_REQUEST:
      return {
        ...state,
        actionSuccess:false,
        actionTakingLoading: true,
      }

    case GROUP_MANAGEMENT_TYPES.TAKE_ACTION_SUCCESS:
      return {
        ...state,
        actionSuccess:true,
        actionTakingLoading: false,
      }

    case GROUP_MANAGEMENT_TYPES.TAKE_ACTION_FAIL:
      return {
        ...state,
        actionSuccess:false,
        actionTakingLoading: false,
        error: action.payload,
      }


    case GROUP_MANAGEMENT_TYPES.EDIT_GROUP_REQUEST:
      return {
        ...state,
        creationLoading: true,
        updated : false,
      }

    case GROUP_MANAGEMENT_TYPES.EDIT_GROUP_SUCCESS:
      return {
        ...state,
        creationLoading: false,
        updated : true,
      }

    case GROUP_MANAGEMENT_TYPES.EDIT_GROUP_FAIL:
      return {
        ...state,
        creationLoading: false,
        updated : false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.RESET_STATUS:
      return {
        ...state,
        updated : false,
        actionSuccess:false,
        created : false,
        deleted : false,
        leaves : false,
        creationLoading: false,
        actionTakingLoading: false,
        joinGroupLoading: false,
        requestSend:false,
        groupNotFound : false,
      }

    case GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_REQUEST:
      return {
        ...state,
        fetchingJoinRequests: true,

      }

    case GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_SUCCESS:
      return {
        ...state,
        fetchingJoinRequests: false,
        joinRequests: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_FAIL:
     return {
        ...state,
        fetchingJoinRequests: false,
        error: action.payload,
      }

    case GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_REQUEST:
      return {
        ...state,
        groupDetails: {},
        deleted : false,
        updated :false,
        groupNotFound : false,
        fetchingGroups  : true,

      }

    case GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_SUCCESS:
      return {
        ...state,
        groupDetails: action.payload,
        fetchingGroups  : false,
        deleted: false,
        groupNotFound : false,

      }

    case GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_FAIL:
      return {
        ...state,
        error: action.payload,
        groupDetails: {},
        groupNotFound : true,
        fetchingGroups  : false,
      }

    case GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_REQUEST:
      return {
        ...state,
        deleted: false,
      }

      case GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_SUCCESS:
  return {
    ...state,
    deleted: true,


  }
case GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_FAIL:
  return {
    ...state,
    deleted: false,
  }

  case GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_REQUEST:
  return {
    ...state,
    leaves: false,
  }


case GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_SUCCESS:
  return {
    ...state,
    leaves: true,
    // ... other state updates ...
  }
case GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_FAIL:
  return {
    ...state,
    leaves: false,
    // ... other state updates ...
  }



















    default:
      return state
  }
}

export default groupManagementReducer
