import "react-slidedown/lib/slidedown.css"
import "@styles/react/libs/flatpickr/flatpickr.scss"
// ** React Imports
import { Fragment, useEffect, useState } from "react"

import { useFormik } from "formik"
import Select from "react-select"

import * as Yup from "yup"
import { selectThemeColors } from "@utils"

import { ArrowLeft, ArrowRight, Plus, X } from "react-feather"

import Repeater from "@components/repeater"
import { SlideDown } from "react-slidedown"

// ** Reactstrap Imports
import { Label, Row, Col, Button, Form, Input, FormFeedback } from "reactstrap"
import Flatpickr from "react-flatpickr"

const Education = ({ stepper, setData, setStep }) => {
  const GradeSystemOptions = [
    { value: "gpa_4", label: "GPA 4" },
    { value: "gpa_5", label: "GPA 5" },
    { value: "percentage", label: "Percentage" }
  ]

  const deleteForm = (e, i, formName) => {
    e.preventDefault()
    const formArray = values[formName]
    formArray.splice(i, 1)
    setFieldValue(formName, formArray)
  }

  const initialValues = {
    education: [
      {
        schoolName: "",
        degree: "",
        fieldOfStudy: "",
        startDate: "",
        endDate: "",
        isCurrentlyStudying: false,
        grade: "",
        gradeSystem: ""
      }
    ]
  }

  const exceptThisSymbols = ["e", "E", "+", "-"]

  const validationSchema = Yup.object().shape({
    education: Yup.array().of(
      Yup.object().shape({
        schoolName: Yup.string().required("Required"),
        degree: Yup.string().required("Required"),
        fieldOfStudy: Yup.string().required("Required"),
        grade: Yup.string().required("Required"),
        gradeSystem: Yup.string().required("Required"),
        startDate: Yup.date().required("Required"),
        isCurrentlyStudying: Yup.boolean(),
        endDate: Yup.date().when("isCurrentlyStudying", {
          is: false,
          then: Yup.date()
            .required("Required")
            .min(
              Yup.ref("startDate"),
              "End Date must be greater than Start Date"
            )
        })
      })
    )
  })

  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      setData(values)
      setStep(3)
      setIsSubmit(false)
      stepper.next()
    }
  })

  const [isSubmit, setIsSubmit] = useState(false)

  return (
    <Fragment>
      <div className="content-header">
        <h5 className="mb-0">Education</h5>
        <small>Enter Your Education.</small>
      </div>
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setIsSubmit(true)
          handleSubmit()
        }}
      >
        <Repeater count={values.education.length}>
          {(i) => {
            const Tag = i === 0 ? "div" : SlideDown
            return (
              <Tag key={i} className="repeater-wrapper">
                <div className="d-flex justify-content-end px-25">
                  {values.education.length > 1 && (
                    <X
                      size={18}
                      className="cursor-pointer"
                      onClick={(e) => {
                        deleteForm(e, i, "education")
                      }}
                    />
                  )}
                </div>

                <Row className="w-100 pe-lg-0 pe-1 py-2">
                  <div className="mb-1 pe-3">
                    <Label
                      for={`education.${i}.schoolName`}
                      className="form-label"
                    >
                      Institute or University Name
                    </Label>
                    <Select
                      name={`education.${i}.schoolName`}
                      value={{
                        value: values.education[i].schoolName,
                        label: values.education[i].schoolName
                      }}
                      onChange={(e) => {
                        setFieldValue(`education.${i}.schoolName`, e.value)
                      }}
                      theme={selectThemeColors}
                      className="react-select"
                      classNamePrefix="select"
                      options={[
                        { value: "SZABIST", label: "SZABIST" },
                        { value: "IBA", label: "IBA" },
                        { value: "FAST", label: "FAST" },
                        { value: "NED", label: "NED" },
                        { value: "KU", label: "KU" },
                        { value: "NUST", label: "NUST" },
                        { value: "LUMS", label: "LUMS" },
                        { value: "UET", label: "UET" },
                        { value: "NED", label: "NED" },
                        { value: "DUHS", label: "DUHS" },
                        { value: "AKU", label: "AKU" },
                        { value: "KMU", label: "KMU" },
                        { value: "JSMU", label: "JSMU" }
                      ]}
                      isClearable={false}
                      placeholder="Select Institute or University Name"
                      bsSize="sm"
                    />

                    {isSubmit &&
                      errors.education &&
                      errors.education[i] &&
                      errors.education[i].schoolName && (
                        <div className="text-danger">
                          {errors.education[i].schoolName}
                        </div>
                      )}
                  </div>
                  <Row>
                    <Col md="6" sm="12" className="mb-1">
                      <Label
                        for={`education.${i}.degree`}
                        className="form-label"
                      >
                        Degree
                      </Label>
                      <Input
                        value={values.education[i].degree}
                        id={`education.${i}.degree`}
                        bsSize="sm"
                        name={`education.${i}.degree`}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder=""
                      />
                      {isSubmit &&
                        errors.education &&
                        errors.education[i] &&
                        errors.education[i].degree && (
                          <div className="text-danger">
                            {errors.education[i].degree}
                          </div>
                        )}
                    </Col>
                    <Col md="6" sm="12" className="mb-1">
                      <Label
                        for={`education.${i}.field_of_study`}
                        className="form-label"
                      >
                        Field of Study
                      </Label>
                      <Input
                        value={values.education[i].fieldOfStudy}
                        id={`education.${i}.fieldOfStudy`}
                        bsSize="sm"
                        name={`education.${i}.fieldOfStudy`}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder=""
                      />
                      {isSubmit &&
                        errors.education &&
                        errors.education[i] &&
                        errors.education[i].fieldOfStudy && (
                          <div className="text-danger">
                            {errors.education[i].fieldOfStudy}
                          </div>
                        )}
                    </Col>
                  </Row>

                  <div className="mb-1 pe-3">
                    <Row>
                      <Col md="6" sm="12" className="">
                        <Label
                          for={`education.${i}.grade`}
                          className="form-label"
                        >
                          CGPA or Percentage
                        </Label>
                        <Input
                          id={`education.${i}.grade`}
                          type="number"
                          value={values.education[i].grade}
                          bsSize="sm"
                          name={`education.${i}.grade`}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          placeholder=""
                          onKeyDown={(e) =>
                            exceptThisSymbols.includes(e.key) &&
                            e.preventDefault()
                          }
                        />
                        {isSubmit &&
                          errors.education &&
                          errors.education[i] &&
                          errors.education[i].grade && (
                            <div className="text-danger">
                              {errors.education[i].grade}
                            </div>
                          )}
                      </Col>
                      <Col md="6" sm="12" className="">
                        <Label for="invoice-from" className="form-label">
                          Grade System
                        </Label>

                        <Select
                          name={`education.${i}.gradeSystem`}
                          defaultValue={values.education[i].gradeSystem}
                          onChange={(e) => {
                            setFieldValue(`education.${i}.gradeSystem`, e.value)
                          }}
                          theme={selectThemeColors}
                          className="react-select"
                          classNamePrefix="select"
                          options={GradeSystemOptions}
                          isClearable={false}
                          placeholder="Select Grade System"
                          bsSize="sm"
                        />
                        {isSubmit &&
                          errors.education &&
                          errors.education[i] &&
                          errors.education[i].gradeSystem && (
                            <div className="text-danger">
                              {errors.education[i].gradeSystem}
                            </div>
                          )}
                      </Col>
                    </Row>
                  </div>
                  <div className="mb-1">
                    <div className="form-check form-check-inline">
                      <Input
                        checked={values.education[i].isCurrentlyStudying}
                        type="checkbox"
                        id="is_percentage_checkbox"
                        className="form-check-input"
                        name={`education.${i}.isCurrentlyStudying`}
                        onChange={handleChange}
                        onBlur={handleBlur}
                      />

                      <Label
                        for="is_percentage_checkbox"
                        className="form-check-label"
                      >
                        is Currently Studying
                      </Label>
                      {isSubmit &&
                        errors.education &&
                        errors.education[i] &&
                        errors.education[i].isCurrentlyStudying && (
                          <div className="text-danger">
                            {errors.education[i].isCurrentlyStudying}
                          </div>
                        )}
                    </div>
                  </div>
                  <Row>
                    <Col md="6" sm="12" className="mb-1 ">
                      <Label className="form-label">Start Date</Label>

                      <Flatpickr
                        value={values.education[i].startDate}
                        placeholder="Start Date"
                        className="form-control"
                        onChange={(date) => {
                          setFieldValue(`education.${i}.startDate`, date)
                        }}
                        options={{
                          dateFormat: "F, Y",
                          mode: "single",
                          noCalendar: false,
                          enableTime: false,
                          monthSelectorType: "static",
                          disableMobile: true
                        }}
                        onBlur={handleBlur}
                      />
                      {isSubmit &&
                        errors.education &&
                        errors.education[i] &&
                        errors.education[i].startDate && (
                          <div className="text-danger">
                            {errors.education[i].startDate}
                          </div>
                        )}
                    </Col>
                    <Col md="6" sm="12" className="mb-1">
                      <Label className="form-label">End Date</Label>

                      <Flatpickr
                        placeholder="End Date"
                        className="form-control"
                        onChange={(date) => {
                          setFieldValue(`education.${i}.endDate`, date)
                        }}
                        options={{
                          dateFormat: "F, Y",
                          mode: "single",
                          noCalendar: false,
                          enableTime: false,
                          monthSelectorType: "static",
                          disableMobile: true
                        }}
                        onBlur={handleBlur}
                        disabled={values.education[i].isCurrentlyStudying}
                        value={
                          values.education[i].isCurrentlyStudying
                            ? null
                            : values.education[i].endDate
                        }
                      />
                      {isSubmit &&
                        errors.education &&
                        errors.education[i] &&
                        errors.education[i].endDate && (
                          <div className="text-danger">
                            {errors.education[i].endDate}
                          </div>
                        )}
                    </Col>
                  </Row>
                </Row>
              </Tag>
            )
          }}
        </Repeater>
        <Row className="mt-1 ps-1 mb-1">
          <Col sm="12" className="px-0">
            <Button
              color="primary"
              size="sm"
              className="btn-add-new"
              onClick={() => {
                setValues({
                  ...values,
                  education: [
                    ...values.education,
                    {
                      schoolName: "",
                      degree: "",
                      fieldOfStudy: "",
                      startDate: "",
                      endDate: "",
                      isCurrentlyStudying: false,
                      grade: "",
                      gradeSystem: ""
                    }
                  ]
                })
              }}
            >
              <Plus size={14} className="me-25" />
              <span className="align-middle">Add Item</span>
            </Button>
          </Col>
        </Row>
        <div className="d-flex justify-content-between">
          <Button
            type="button"
            color="primary"
            className="btn-prev"
            onClick={() => stepper.previous()}
          >
            <ArrowLeft
              size={14}
              className="align-middle me-sm-25 me-0"
            ></ArrowLeft>
            <span className="align-middle d-sm-inline-block d-none">
              Previous
            </span>
          </Button>
          <Button type="submit" color="primary" className="btn-next">
            <span className="align-middle d-sm-inline-block d-none">Next</span>
            <ArrowRight
              size={14}
              className="align-middle ms-sm-25 ms-0"
            ></ArrowRight>
          </Button>
        </div>
      </Form>
    </Fragment>
  )
}

export default Education
