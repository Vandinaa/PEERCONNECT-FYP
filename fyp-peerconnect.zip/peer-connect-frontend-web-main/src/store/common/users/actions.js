import { USERS_TYPES } from "./types"

export const getAllUsersRequest = (data) => ({
  type: USERS_TYPES.GET_ALL_USERS_REQUEST,
  payload: data
})

export const getAllUsersSuccess = (data) => ({
  type: USERS_TYPES.GET_ALL_USERS_SUCCESS,
  payload: data
})

export const getAllUsersFailure = (data) => ({
  type: USERS_TYPES.GET_ALL_USERS_FAIL,
  payload: data
})

export const getRecommendedUsersRequest = (data) => ({
  type: USERS_TYPES.GET_RECOMMENDED_USERS_REQUEST,
  payload: data
})

export const getRecommendedUsersSuccess = (data) => ({
  type: USERS_TYPES.GET_RECOMMENDED_USERS_SUCCESS,
  payload: data
})

export const getRecommendedUsersFailure = (data) => ({
  type: USERS_TYPES.GET_RECOMMENDED_USERS_FAIL,
  payload: data
})




export const createUserRequest = (data) => ({
  type: USERS_TYPES.CREATE_USER_REQUEST,
  payload: data
})

export const createUserSuccess = (data) => ({
  type: USERS_TYPES.CREATE_USER_SUCCESS,
  payload: data
})

export const createUserFailure = (data) => ({
  type: USERS_TYPES.CREATE_USER_FAIL,
  payload: data
})

export const updateUserRequest = (data) => ({
  type: USERS_TYPES.UPDATE_USER_REQUEST,
  payload: data
})

export const updateUserSuccess = (data) => ({
  type: USERS_TYPES.UPDATE_USER_SUCCESS,
  payload: data
})

export const updateUserFailure = (data) => ({
  type: USERS_TYPES.UPDATE_USER_FAIL,
  payload: data
})

export const deleteUserRequest = (data) => ({
  type: USERS_TYPES.DELETE_USER_REQUEST,
  payload: data
})

export const deleteUserSuccess = (data) => ({
  type: USERS_TYPES.DELETE_USER_SUCCESS,
  payload: data
})

export const deleteUserFailure = (data) => ({
  type: USERS_TYPES.DELETE_USER_FAIL,
  payload: data
})

export const blockUserRequest = (data) => ({
  type: USERS_TYPES.BLOCK_USER_REQUEST,
  payload: data
})

export const blockUserSuccess = (data) => ({
  type: USERS_TYPES.BLOCK_USER_SUCCESS,
  payload: data
})

export const blockUserFailure = (data) => ({
  type: USERS_TYPES.BLOCK_USER_FAIL,
  payload: data
})

export const getUserRequest = (data) => ({
  type: USERS_TYPES.GET_USER_REQUEST,
  payload: data
})

export const getUserSuccess = (data) => ({
  type: USERS_TYPES.GET_USER_SUCCESS,
  payload: data
})

export const getUserFailure = (data) => ({
  type: USERS_TYPES.GET_USER_FAIL,
  payload: data
})

export const resetAllStatus = () => ({
  type: USERS_TYPES.RESET_ALL_STATUS
})

export const getLoggedInUserRequest = (data) => ({
  type: USERS_TYPES.GET_LOGGED_IN_USER_REQUEST,
  payload: data
})

export const getLoggedInUserSuccess = (data) => ({
  type: USERS_TYPES.GET_LOGGED_IN_USER_SUCCESS,
  payload: data
})

export const getLoggedInUserFailure = (data) => ({
  type: USERS_TYPES.GET_LOGGED_IN_USER_FAIL,
  payload: data
})

export const updateEducationRequest = (data) => ({
  type: USERS_TYPES.UPDATE_EDUCATION_REQUEST,
  payload: data
})

export const updateEducationSuccess = (data) => ({
  type: USERS_TYPES.UPDATE_EDUCATION_SUCCESS,
  payload: data
})

export const updateEducationFailure = (data) => ({
  type: USERS_TYPES.UPDATE_EDUCATION_FAIL,
  payload: data
})

export const updateExperienceRequest = (data) => ({
  type: USERS_TYPES.UPDATE_EXPERIENCE_REQUEST,
  payload: data
})

export const updateExperienceSuccess = (data) => ({
  type: USERS_TYPES.UPDATE_EXPERIENCE_SUCCESS,
  payload: data
})

export const updateExperienceFailure = (data) => ({
  type: USERS_TYPES.UPDATE_EXPERIENCE_FAIL,
  payload: data
})

export const updateInterestsAndCoursesRequest = (data) => ({
  type: USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_REQUEST,
  payload: data
})

export const updateInterestsAndCoursesSuccess = (data) => ({
  type: USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_SUCCESS,
  payload: data
})

export const updateInterestsAndCoursesFailure = (data) => ({
  type: USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_FAIL,
  payload: data
})

export const deleteEducationRequest = (data) => ({
  type: USERS_TYPES.DELETE_EDUCATION_REQUEST,
  payload: data
})

export const deleteEducationSuccess = (data) => ({
  type: USERS_TYPES.DELETE_EDUCATION_SUCCESS,
  payload: data
})

export const deleteEducationFailure = (data) => ({
  type: USERS_TYPES.DELETE_EDUCATION_FAIL,
  payload: data
})

export const deleteExperienceRequest = (data) => ({
  type: USERS_TYPES.DELETE_EXPERIENCE_REQUEST,
  payload: data
})

export const deleteExperienceSuccess = (data) => ({
  type: USERS_TYPES.DELETE_EXPERIENCE_SUCCESS,
  payload: data
})

export const deleteExperienceFailure = (data) => ({
  type: USERS_TYPES.DELETE_EXPERIENCE_FAIL,
  payload: data
})

export const addEducationRequest = (data) => ({
  type: USERS_TYPES.ADD_EDUCATION_REQUEST,
  payload: data
})

export const addEducationSuccess = (data) => ({
  type: USERS_TYPES.ADD_EDUCATION_SUCCESS,
  payload: data
})

export const addEducationFailure = (data) => ({
  type: USERS_TYPES.ADD_EDUCATION_FAIL,
  payload: data
})

export const addExperienceRequest = (data) => ({
  type: USERS_TYPES.ADD_EXPERIENCE_REQUEST,
  payload: data
})

export const addExperienceSuccess = (data) => ({
  type: USERS_TYPES.ADD_EXPERIENCE_SUCCESS,
  payload: data
})

export const addExperienceFailure = (data) => ({
  type: USERS_TYPES.ADD_EXPERIENCE_FAIL,
  payload: data
})

export const uploadProfileImageRequest = (data) => ({
  type: USERS_TYPES.UPLOAD_PROFILE_IMAGE_REQUEST,
  payload: data
})

export const uploadProfileImageSuccess = (data) => ({
  type: USERS_TYPES.UPLOAD_PROFILE_IMAGE_SUCCESS,
  payload: data
})

export const uploadProfileImageFailure = (data) => ({
  type: USERS_TYPES.UPLOAD_PROFILE_IMAGE_FAIL,
  payload: data
})

export const deactivateAccountRequest = (data) => ({
  type: USERS_TYPES.DEACTIVATE_ACCOUNT_REQUEST,
  payload: data
})

export const deactivateAccountSuccess = (data) => ({
  type: USERS_TYPES.DEACTIVATE_ACCOUNT_SUCCESS,
  payload: data
})

export const deactivateAccountFailure = (data) => ({
  type: USERS_TYPES.DEACTIVATE_ACCOUNT_FAIL,
  payload: data
})

export const getStatsRequest = (data) => ({
  type: USERS_TYPES.GET_STATS_REQUEST,
  payload: data
})

export const getStatsSuccess = (data) => ({
  type: USERS_TYPES.GET_STATS_SUCCESS,
  payload: data
})

export const getStatsFailure = (data) => ({
  type: USERS_TYPES.GET_STATS_FAIL,
  payload: data
})


