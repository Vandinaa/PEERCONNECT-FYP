import { all, fork } from "redux-saga/effects"

import AuthWatcherSaga from "./../common/auth/saga"
import chatSaga from "../common/chat/saga"
import groupManagementSaga from "../common/groupManagement/saga"
import interestSaga from "../common/interests/saga"
import layoutSaga from "../common/layout/saga"
import loginSaga from "../common/login/saga"
import navbarSaga from "../common/navbar/saga"
import searchSaga from "../common/search/saga"
import registerSaga from "../common/register/saga"
import securitySaga from "../common/security/saga"
import courseSaga from "../common/courses/saga"
import usersSaga from "../common/users/saga"

export default function* coreSaga() {
  yield all([
    fork(layoutSaga),
    fork(navbarSaga),
    fork(loginSaga),
    fork(registerSaga),
    fork(AuthWatcherSaga),
    fork(interestSaga),
    fork(courseSaga),
    fork(securitySaga),
    fork(groupManagementSaga),
    fork(usersSaga),
    fork(searchSaga),
    fork(chatSaga),
  ])
}
