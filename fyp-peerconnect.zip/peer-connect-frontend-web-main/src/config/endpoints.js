export const Endpoints = {
    // ** Auth
    login: "/auth/login",
    register: "/auth/register",
    refresh: "/auth/refresh-token",
    logout: "/auth/logout",
    verifyEmail: "/auth/verify-otp",
    resendOtp: "/auth/resend-otp",
    forgotPassword: "/auth/forgot-password",
    resetPassword: "/auth/reset-password",
    changePassword: "/auth/change-password",
    user: "/users",
    recommendedUsers: "/users/recommended-users",
    
  
    loggedInUser: "/users/this",
    getAllCourses: "/courses",
    getAllInterest: "/interests",
    // Group management endpoints
    createGroup: "/groups",
    getCreatedGroups: "/groups/my-created-groups",
    getMyGroups: "/groups/my-groups",
    getOtherGroups: "/groups/other-groups",
    joinGroup: "/groups/join-group",
    takeAction: "/groups/take-action",
    // addMembers: "/groups/add-members",
    // addCourses: "/groups/add-courses",
    editGroup: "/groups/edit-group",
    getJoinRequests: "/groups/join-requests",
    getSearch: "/search/advance",
    getChatHistory: "/chat/chat-history",
    getGroupChatHistory : "/chat/group-chat-history",
    Exp:"/users/experience",
    Edu:"/users/education",
    updateInterestsAndCourses:"/users/interestsAndCourses",
    uploadProfileImage:"/users/uploadProfileImage",
    deactivateAccount:"/users/activateUser",
    getStats:"/stats",
    getGroupDetails:"/groups/group-details",
    uploadChatMedia:"/chat/upload-files",
    uploadFiles:"/chat/upload-document",
    chatNotification:"/chat/chat-notifications",
    removeMember:"/groups/remove-member",
    leaveGroup:"/groups/leave-group",

  
  }
  
  
  // router
  //   .route('/experience')
  //   .post(auth('manageUsers'), validate(userValidation.addExperience), userController.addExperience);
  
  // //api to patch experience
  // router
  //   .route('/experience/:experienceId')
  //   .patch(auth('manageUsers'), validate(userValidation.updateExperience), userController.updateExperience)
  //   .delete(auth('manageUsers'), validate(userValidation.deleteExperience), userController.deleteExperience);
  
  
  // //api to add education
  // router
  //   .route('/education')
  //   .post(auth('manageUsers'), validate(userValidation.addEducation), userController.addEducation);
    
    
  // //api to patch education
  // router
  //   .route('/education/:educationId')
  //   .patch(auth('manageUsers'), validate(userValidation.updateEducation), userController.updateEducation)
  //   .delete(auth('manageUsers'), validate(userValidation.deleteEducation), userController.deleteEducation);
  
  
  // //api to update interests and courses
  // router
  //   .route('/interestsAndCourses')
  //   .patch(auth('manageUsers'), validate(userValidation.updateInterestAndCourses), userController.updateInterestsAndCourses)
  
  