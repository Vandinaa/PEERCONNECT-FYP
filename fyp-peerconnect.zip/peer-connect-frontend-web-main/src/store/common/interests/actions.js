import { INTEREST_TYPES } from "./types"

export const getAllInterestRequest = (data) => ({
  type: INTEREST_TYPES.GET_ALL_INTEREST_REQUEST,
  payload: data
})

export const getAllInterestSuccess = (data) => ({
  type: INTEREST_TYPES.GET_ALL_INTEREST_SUCCESS,
  payload: data
})

export const getAllInterestFailure = (data) => ({
  type: INTEREST_TYPES.GET_ALL_INTEREST_FAIL,
  payload: data
})

export const createInterestRequest = (data) => ({
  type: INTEREST_TYPES.CREATE_INTEREST_REQUEST,
  payload: data
})

export const createInterestSuccess = (data) => ({
  type: INTEREST_TYPES.CREATE_INTEREST_SUCCESS,
  payload: data
})

export const createInterestFailure = (data) => ({
  type: INTEREST_TYPES.CREATE_INTEREST_FAIL,
  payload: data
})

export const updateInterestRequest = (data) => ({
  type: INTEREST_TYPES.UPDATE_INTEREST_REQUEST,
  payload: data
})

export const updateInterestSuccess = (data) => ({
  type: INTEREST_TYPES.UPDATE_INTEREST_SUCCESS,
  payload: data
})

export const updateInterestFailure = (data) => ({
  type: INTEREST_TYPES.UPDATE_INTEREST_FAIL,
  payload: data
})

export const deleteInterestRequest = (data) => ({
  type: INTEREST_TYPES.DELETE_INTEREST_REQUEST,
  payload: data
})

export const deleteInterestSuccess = (data) => ({
  type: INTEREST_TYPES.DELETE_INTEREST_SUCCESS,
  payload: data
})

export const deleteInterestFailure = (data) => ({
  type: INTEREST_TYPES.DELETE_INTEREST_FAIL,
  payload: data
})
