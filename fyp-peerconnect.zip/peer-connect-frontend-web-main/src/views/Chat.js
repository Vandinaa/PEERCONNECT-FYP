// ** React Imports
import CardChat from "@src/components/CardChat"

function Chat() {
  return <CardChat />
}

export default Chat
