import * as courseActions from "./actions"

import { all, call, put, takeEvery } from "redux-saga/effects"
import {
  createCourse,
  deleteCourse,
  getAllCourses,
  updateCourse
} from "@src/services/apis"

import { COURSE_TYPES } from "./types"
import toast from "react-hot-toast"

function* getAllCoursesRequest(action) {
  try {
    const response = yield call(getAllCourses, action.payload)
    yield put(courseActions.getAllCoursesSuccess(response))
  } catch (err) {
    yield put(courseActions.getAllCoursesFailure(err))
  }
}

function* createCourseRequest(action) {
  try {
    const response = yield call(createCourse, action.payload)
    if (response?.response?.data?.code === 400) {
      if (response?.response?.data?.message === "Name already taken") {
        toast.error("Course already exists with this name")
        yield put(courseActions.createCourseFailure(err))
      } else if (response?.response?.data?.message === "Code already taken") {
        toast.error("Course already exists with this code")
        yield put(courseActions.createCourseFailure(err))
      }
    } else if (response?.status === 201) {
      yield put(courseActions.createCourseSuccess(response))
    }

  } catch (err) {
    yield put(courseActions.createCourseFailure(err))
  }
}

function* updateCourseRequest(action) {
  try {
    const response = yield call(updateCourse, action.payload)
    yield put(courseActions.updateCourseSuccess(response.data))
  } catch (err) {
    yield put(courseActions.updateCourseFailure(err))
  }
}

function* deleteCourseRequest(action) {
  try {
    const response = yield call(deleteCourse, action.payload)
    yield put(courseActions.deleteCourseSuccess(response?.remaining_calls))
  } catch (err) {
    yield put(courseActions.deleteCourseFailure(err))
  }
}

export default function* courseSaga() {
  yield all([
    takeEvery(COURSE_TYPES.GET_ALL_COURSES_REQUEST, getAllCoursesRequest),
    takeEvery(COURSE_TYPES.CREATE_COURSE_REQUEST, createCourseRequest),
    takeEvery(COURSE_TYPES.UPDATE_COURSE_REQUEST, updateCourseRequest),
    takeEvery(COURSE_TYPES.DELETE_COURSE_REQUEST, deleteCourseRequest)
  ])
}
