import { AlertTriangle, Bell, Check, X } from "react-feather"
// ** Reactstrap Imports
import {
  Badge,
  Button,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  UncontrolledDropdown
} from "reactstrap"

// ** Custom Components
import MySwal from "sweetalert2"

import Avatar from "@components/avatar"
// ** React Imports
import { Fragment, useEffect, useState } from "react"
import PerfectScrollbar from "react-perfect-scrollbar"
// ** Third Party Components
import classnames from "classnames"

import * as groupActions from "@src/store/common/groupManagement/actions"
import * as chatActions from "@src/store/common/chat/actions"

import { fieldExists, getProfileId, isNullObject, isObjEmpty } from "@src/utility/Utils"

import { useDispatch, useSelector } from "react-redux"

import socketIOClient from "socket.io-client"
import { use } from "i18next"


const NotificationDropdown = () => {
  const dispatch = useDispatch()

  const [joinRequestsState, setJoinRequestsState] = useState([])

  const {
    myGroups,
    fetchingJoinRequests,
    joinRequests,
    actionTakingLoading,
    actionSuccess
  } = useSelector((state) => state.groupManagementReducer)




  useEffect(() => {
    if (actionSuccess) {
      dispatch(groupActions.getJoinRequestsRequest())
      dispatch(groupActions.getMyGroupsRequest())
      dispatch(groupActions.resetStatus())
    }
  }, [actionSuccess])

  useEffect(() => {
    console.log("fetchingJoinRequests", fetchingJoinRequests)
    if (isObjEmpty(joinRequestsState)) {
      dispatch(groupActions.getJoinRequestsRequest())
    }
  }, [dispatch])

  useEffect(() => {
    if (!isObjEmpty(joinRequests)) {
      setJoinRequestsState(joinRequests?.joinRequests)
    }
  }, [joinRequests])


  useEffect(() => {
    
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
    socket.on(getProfileId()+"-joinRequest", (payload) => {
      console.log("payload", payload)

      // APPEND PAYLOAD IN THE STATE
      const newJoinRequests = [...joinRequestsState, payload]
      setJoinRequestsState(newJoinRequests)





    })
    return () => {
      socket.off(getProfileId()+"-joinRequest")
    }
  }, [])


  const acceptRequest = (e, id, groupId) => {
    e.preventDefault()
    dispatch(
      groupActions.takeActionRequest({
        groupId,
        userId: id,
        body: {
          action: "accept"
        }
      })
    )

    // if (actionTakingLoading) {
    //   MySwal.fire({
    //     icon: "success",
    //     title: "Request Accepted",
    //     showConfirmButton: false,
    //     timer: 1500
    //   })
    // }
  }

  const rejectRequest = (e, id, groupId) => {
    e.preventDefault()

    dispatch(
      groupActions.takeActionRequest({
        groupId,
        userId: id,
        body: {
          action: "reject"
        }
      })
    )
    // if (actionTakingLoading) {
    //   MySwal.fire({
    //     icon: "success",
    //     title: "Request Rejected",
    //     showConfirmButton: false,
    //     timer: 1500
    //   })
    // }
  }

  // ** Notification Array
  // const notificationsArray = [
  //   {
  //     img: require("@src/assets/images/portrait/small/avatar-s-11.jpg").default,
  //     subtitle: "Won the monthly best seller badge.",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">Congratulation Sam 🎉</span>winner!
  //       </p>
  //     )
  //   },
  //   {
  //     img: require("@src/assets/images/portrait/small/avatar-s-11.jpg").default,
  //     subtitle: "You have 10 unread messages.",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">New message</span>&nbsp;received
  //       </p>
  //     )
  //   },
  //   {
  //     avatarContent: "MD",
  //     color: "light-danger",
  //     subtitle: "MD Inc. order updated",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">Revised Order 👋</span>&nbsp;checkout
  //       </p>
  //     )
  //   },
  //   {
  //     title: <h6 className="fw-bolder me-auto mb-0">System Notifications</h6>,
  //     switch: (
  //       <div className="form-check form-switch">
  //         <Input
  //           type="switch"
  //           name="customSwitch"
  //           id="exampleCustomSwitch"
  //           defaultChecked
  //         />
  //       </div>
  //     )
  //   },
  //   {
  //     avatarIcon: <X size={14} />,
  //     color: "light-danger",
  //     subtitle: "USA Server is down due to hight CPU usage",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">Server down</span>&nbsp;registered
  //       </p>
  //     )
  //   },
  //   {
  //     avatarIcon: <Check size={14} />,
  //     color: "light-success",
  //     subtitle: "Last month sales report generated",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">Sales report</span>&nbsp;generated
  //       </p>
  //     )
  //   },
  //   {
  //     avatarIcon: <AlertTriangle size={14} />,
  //     color: "light-warning",
  //     subtitle: "BLR Server using high memory",
  //     title: (
  //       <p className="media-heading">
  //         <span className="fw-bolder">High memory</span>&nbsp;usage
  //       </p>
  //     )
  //   }
  // ]

  // ** Function to render Notifications
  /*eslint-disable */
  const renderNotificationItems = (joinRequests) => {
    return (
      <PerfectScrollbar
        component="li"
        className="media-list scrollable-container"
        options={{
          wheelPropagation: false
        }}
      >
        {joinRequests?.length > 0
          ? joinRequests?.map((item, index) => {
              const title = `${item?.request?.personalInfo?.fullName} wants to join the group ${item?.groupName}`
              const subtitle = item?.request?.email
              const switchContent = (
                <div className="justify-content-center m-1 w-100">
                  <Button.Ripple
                    className="me-50"
                    outline
                    color="success"
                    size="sm"
                    onClick={(e) =>
                      acceptRequest(e, item.request.id, item.groupId)
                    }
                  >
                    <Check size={12} />
                  </Button.Ripple>
                  <Button.Ripple
                    outline
                    color="danger"
                    size="sm"
                    onClick={(e) =>
                      rejectRequest(e, item.request.id, item.groupId)
                    }
                  >
                    <X size={12} />
                  </Button.Ripple>
                </div>
              )
              const avatarContent = item?.request?.personalInfo?.fullName
                ? item?.request?.personalInfo?.fullName?.charAt(0).toUpperCase()
                : null
              const newItem = {
                ...item,
                title,
                subtitle,
                switch: switchContent,
                avatarContent,
                color: "light-success"
              }

              return (
                <a
                  key={index}
                  className="d-flex"
                  href={item.switch ? "#" : "/"}
                  onClick={(e) => {
                    if (!newItem.switch) {
                      e.preventDefault()
                    }
                  }}
                >
                  <div
                    className={classnames("list-item d-flex no-wrap", {
                      "align-items-start": !newItem.switch,
                      "align-items-center": newItem.switch
                    })}
                  >
                    {!item.switch ? (
                      <Fragment>
                        <div className="me-1">
                          <Avatar
                            {...(newItem.img
                              ? {
                                  img: newItem.img,
                                  imgHeight: 32,
                                  imgWidth: 32
                                }
                              : newItem.avatarContent
                              ? {
                                  content: newItem.avatarContent,
                                  color: newItem.color
                                }
                              : newItem.avatarIcon
                              ? {
                                  icon: newItem.avatarIcon,
                                  color: newItem.color
                                }
                              : null)}
                          />
                        </div>
                        <div className="fw-bolder no-wrap">
                          {newItem.title}
                          {/* <small className="notification-text">
                        {newItem.subtitle}
                      </small> */}
                        </div>
                        {newItem.switch}
                      </Fragment>
                    ) : (
                      <Fragment>
                        {newItem.title}
                        {newItem.switch}
                      </Fragment>
                    )}
                  </div>
                </a>
              )
            })
          : null}
      </PerfectScrollbar>
    )
  }
  /*eslint-enable */

  return (
    <UncontrolledDropdown
      tag="li"
      className="dropdown-notification nav-item me-25"
    >
      <DropdownToggle
        tag="div"
        className="nav-link"
        // href="/"
        // onClick={(e) => e.preventDefault()}
      >
        <Bell size={21} />
        {joinRequestsState.length > 0 ? (
          <Badge pill color="danger" className="badge-up">
            {joinRequestsState.length}
          </Badge>
        ) : null}
      </DropdownToggle>
      <DropdownMenu end tag="ul" className="dropdown-menu-media mt-0">
        <li className="dropdown-menu-header">
          <DropdownItem className="d-flex" tag="div" header>
            <h4 className="notification-title mb-0 me-auto">Notifications</h4>
            <Badge tag="div" color="light-primary" pill>
              {joinRequestsState.length} New
            </Badge>
          </DropdownItem>
        </li>
        {renderNotificationItems(joinRequestsState)}
        {/* <li className="dropdown-menu-footer">
          <Button color="primary" block>
            Read all notifications
          </Button>
        </li> */}
      </DropdownMenu>
    </UncontrolledDropdown>
  )
}

export default NotificationDropdown
