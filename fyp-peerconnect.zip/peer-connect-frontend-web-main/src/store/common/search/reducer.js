import { SEARCH_TYPES } from "./types"

const initialState = {
  listOfSearch: {},
  error: null,
  searching: false
}

export default function searchReducer(state = initialState, action) {
  switch (action.type) {
    case SEARCH_TYPES.GET_LIST_OF_SEARCH_REQUEST:
      return {
        ...state,
        searching: true,
        listOfSearch: {}
      }
    case SEARCH_TYPES.GET_LIST_OF_SEARCH_SUCCESS:
      return {
        ...state,
        searching: false,
        listOfSearch: action.payload,
        error: null
      }
    case SEARCH_TYPES.GET_LIST_OF_SEARCH_FAILURE:
      return {
        ...state,
        searching: false,
        error: action.payload,
        listOfSearch: {}
      }
    case SEARCH_TYPES.CLEAR_SEARCH_LIST:
      return {
        ...state,
        searching: false,
        listOfSearch: {}
      }

    default:
      return state
  }
}
