import * as appliedJobActions from "@src/store/common/jobs/actions"

import Avatar from "@components/avatar"
import { Button } from "reactstrap"
import Chart from "react-apexcharts"
import { ChartProps } from "@src/utility/Utils"
import { FileText } from "react-feather"
import { useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom"
import { useTranslation } from "react-i18next"

export const ApplicantColumns = () => {
  const dispatch = useDispatch()
  const Navigate = useNavigate()
  const { t } = useTranslation()

  const renderClient = (row) => {
    if (row.hasOwnProperty("avatar") && row.avatar.length) {
      return <Avatar className="me-1" img={row.avatar} width="32" height="32" />
    } else {
      return (
        <Avatar
          initials
          className="me-1"
          color={row.avatarColor || "light-primary"}
          content={row.full_name || "N/A"}
        />
      )
    }
  }

  return [
    {
      name: t("Applicants"),
      sortable: true,
      minWidth: "300px",
      sortField: "full_name",
      selector: (row) => row.full_name,
      cell: (row) => (
        <div className="d-flex justify-content-left align-items-center">
          {renderClient(row)}
          <div className="d-flex flex-column">
            <div className="user_name text-truncate text-body">
              <span className="fw-bolder">{row.full_name}</span>
            </div>
            <small className="text-truncate text-muted mb-0">{row.email}</small>
          </div>
        </div>
      )
    },

    {
      name: t("Job Title"),
      sortable: true,
      minWidth: "150px",
      selector: (row) => row.job_title
    },
    {
      name: t("Applied Date"),
      sortable: true,
      minWidth: "150px",
      selector: (row) => row.apply_date
    },
    {
      name: t("Job Category"),
      sortable: true,
      minWidth: "150px",
      selector: (row) => row.job_category
    },

    {
      name: t("Current Status"),
      sortable: true,
      minWidth: "150px",
      selector: (row) => row.current_status
    },

    // {
    //   name: t("Score"),
    //   sortable: true,
    //   minWidth: "150px",
    //   selector: (row) => row.relevancy_percentage,
    //   cell: (row) => (
    //     <div className="d-flex justify-content-between align-items-center">
    //       <div className="text-truncate text-body me-1">
    //         <span className="fw-bolder">{row.relevancy_percentage}</span>
    //       </div>
    //       <Chart
    //         options={ChartProps(row.relevancy_percentage).options}
    //         series={ChartProps(row.relevancy_percentage).series}
    //         type={ChartProps(row.relevancy_percentage).type}
    //         height={ChartProps(row.relevancy_percentage).height}
    //         width={ChartProps(row.relevancy_percentage).width}
    //       />
    //     </div>
    //   )
    // },

    // {
    //   name: t("View Details"),
    //   minWidth: "100px",
    //   cell: (row) => (
    //     <Button.Ripple
    //       className="btn-icon"
    //       size="sm"
    //       color="secondary"
    //       caret="true"
    //       outline
    //       onClick={() => {
    //         localStorage.setItem("jobId", row._id)
    //         dispatch(
    //           appliedJobActions.getSpecificAppliedJobRequest({
    //             params: row._id
    //           })
    //         )

    //         Navigate("/applicant-details/" + row._id)
    //       }}
    //     >
    //       <FileText size={17} className="me-50" />
    //       <span className="align-middle">{t("View")}</span>
    //     </Button.Ripple>
    //   )
    // }
  ]
}
