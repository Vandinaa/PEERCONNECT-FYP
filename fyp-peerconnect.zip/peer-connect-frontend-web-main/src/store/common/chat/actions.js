import { CHAT_TYPES } from "./types"

export const getChatHistoryRequest = (data) => ({
  type: CHAT_TYPES.GET_CHAT_HISTORY_REQUEST,
  payload: data
})

export const getChatHistorySuccess = (data) => ({
  type: CHAT_TYPES.GET_CHAT_HISTORY_SUCCESS,
  payload: data
})

export const getChatHistoryFailure = (data) => ({
  type: CHAT_TYPES.GET_CHAT_HISTORY_FAIL,
  payload: data
})

export const getGroupChatHistoryRequest = (data) => ({
  type: CHAT_TYPES.GET_GROUP_CHAT_HISTORY_REQUEST,
  payload: data
})

export const getGroupChatHistorySuccess = (data) => ({
  type: CHAT_TYPES.GET_GROUP_CHAT_HISTORY_SUCCESS,
  payload: data
})

export const getGroupChatHistoryFailure = (data) => ({
  type: CHAT_TYPES.GET_GROUP_CHAT_HISTORY_FAIL,
  payload: data
})

export const uploadChatMediaRequest = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_MEDIA_REQUEST,
  payload: data
})

export const uploadChatMediaSuccess = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_MEDIA_SUCCESS,
  payload: data
})

export const uploadChatMediaFailure = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_MEDIA_FAIL,
  payload: data
})

export const uploadChatDocumentRequest = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_REQUEST,
  payload: data
})

export const uploadChatDocumentSuccess = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_SUCCESS,
  payload: data
})

export const uploadChatDocumentFailure = (data) => ({
  type: CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_FAIL,
  payload: data
})

export const chatNotificationRequest = (data) => ({
  type: CHAT_TYPES.CHAT_NOTIFICATION_REQUEST,
  payload: data
})

export const chatNotificationSuccess = (data) => ({
  type: CHAT_TYPES.CHAT_NOTIFICATION_SUCCESS,
  payload: data
})

export const chatNotificationFailure = (data) => ({
  type: CHAT_TYPES.CHAT_NOTIFICATION_FAIL,
  payload: data
})








// export const createEvaluationRequest = (data) => ({
//   type: CHAT_TYPES.CREATE_CHAT_REQUEST,
//   payload: data
// })

// export const createEvaluationSuccess = (data) => ({
//   type: CHAT_TYPES.CREATE_CHAT_SUCCESS,
//   payload: data
// })

// export const createEvaluationFailure = (data) => ({
//   type: CHAT_TYPES.CREATE_CHAT_FAIL,
//   payload: data
// })

// export const resetAddedStatus = () => ({
//   type: CHAT_TYPES.RESET_ADDED_STATUS
// })

// export const getEvaluationRequest = (data) => ({
//   type: CHAT_TYPES.GET_CHAT_REQUEST,
//   payload: data
// })

// export const getEvaluationSuccess = (data) => ({
//   type: CHAT_TYPES.GET_CHAT_SUCCESS,
//   payload: data
// })

// export const getEvaluationFailure = (data) => ({
//   type: CHAT_TYPES.GET_CHAT_FAIL,
//   payload: data
// })

// export const updateEvaluationRequest = (data) => ({
//   type: CHAT_TYPES.UPDATE_CHAT_REQUEST,
//   payload: data
// })

// export const updateEvaluationSuccess = (data) => ({
//   type: CHAT_TYPES.UPDATE_CHAT_SUCCESS,
//   payload: data
// })

// export const updateEvaluationFailure = (data) => ({
//   type: CHAT_TYPES.UPDATE_CHAT_FAIL,
//   payload: data
// })

// export const deleteEvaluationRequest = (data) => ({
//   type: CHAT_TYPES.DELETE_CHAT_REQUEST,
//   payload: data
// })

// export const deleteEvaluationSuccess = (data) => ({
//   type: CHAT_TYPES.DELETE_CHAT_SUCCESS,
//   payload: data
// })

// export const deleteEvaluationFailure = (data) => ({
//   type: CHAT_TYPES.DELETE_CHAT_FAIL,
//   payload: data
// })

// export const getAllEvaluationRequest = (data) => ({
//   type: CHAT_TYPES.GET_ALL_CHAT_REQUEST,
//   payload: data
// })

// export const getAllEvaluationSuccess = (data) => ({
//   type: CHAT_TYPES.GET_ALL_CHAT_SUCCESS,
//   payload: data
// })

// export const getAllEvaluationFailure = (data) => ({
//   type: CHAT_TYPES.GET_ALL_CHAT_FAIL,
//   payload: data
// })
