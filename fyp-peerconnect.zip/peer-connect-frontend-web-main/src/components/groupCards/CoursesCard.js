import { Badge, Card, CardBody } from "reactstrap"
import { Fragment } from "react"

const CoursesCard = ({ courses }) => {
  return (
    <Fragment>
      <Card>
        <CardBody>
          <div className="d-flex justify-content-between align-items-end">
            {courses?.length > 0 ? (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Courses</h6>
                {courses?.map((course, index) => {
                  return (
                    <Badge key={index} className="me-1" color="light-primary">
                      {course?.courseName}
                    </Badge>
                  )
                })}
              </div>
            ) : (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Courses</h6>
                <p className="mb-0">No Courses Found</p>
              </div>
            )}
          </div>
        </CardBody>
      </Card>
    </Fragment>
  )
}
export default CoursesCard
