import "@styles/base/pages/app-chat-list.scss"

import * as chatActions from "@src/store/common/chat/actions"
import * as userActions from "@src/store/common/users/actions"

import Dropzone from "react-dropzone"

import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Form,
  Input,
  InputGroup,
  InputGroupText,
  Label,
  Spinner
} from "reactstrap"
import {
  FilePlus,
  FileText,
  Image,
  MoreVertical,
  Phone,
  PhoneCall,
  Send,
  Video,
  X
} from "react-feather"
import {
  encodeBase64String,
  getProfileId,
  getUserData
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Avatar from "@components/avatar"
import PerfectScrollbar from "react-perfect-scrollbar"
import classnames from "classnames"
import { isObjEmpty } from "@src/utility/Utils"
import socketIOClient from "socket.io-client"
import { Link, useNavigate } from "react-router-dom"
import toast from "react-hot-toast"

import VideoCallModal from "./VideoCallModal"

const alternateImage =
  require("@src/assets/images/avatars/avatar-blank.png").default

const imagetest =
  require("@src/assets/images/portrait/small/avatar-s-11.jpg").default

const CardChat = () => {
  // ** States
  const [msg, setMsg] = useState("")
  const [chatRef, setChatRef] = useState(null)
  const [contactId, setContactId] = useState(null)
  const [image, setImage] = useState(null)
  const [file, setFile] = useState(null)
  const [currentFileType, setCurrentFileType] = useState(true) // true for image and false for file
  const maxFileSize = 5242880
  const [chatData, setChatData] = useState({
    chat: {
      id: 2,
      userId: 1,
      unseenMsgs: 0,
      chat: []
    },
    contact: {
      id: 1,
      fullName: "N/A",
      avatar: null,
      status: "away"
    }
  })
  const dispatch = useDispatch()
  const [ChatUserId, setChatUserId] = useState(
    new URLSearchParams(window.location.search).get("id") || null
  )
  const [show, setShow] = useState(false)
  const navigate = useNavigate()

  const { user, userNotFound, fetchingUsers, userFetched } = useSelector(
    (state) => state.usersReducer
  )

  const { chatHistoryLoading, chatHistory, media } = useSelector(
    (state) => state.chatReducer
  )

  const [callType, setCallType] = useState(
    new URLSearchParams(window.location.search).get("callType") || null
  )

  useEffect(() => {
    if (typeof callType !== "undefined" && callType !== null) {
      setShow(true)
    }
  }, [callType])

  const handleModalClosed = () => {
    setShow(false)
  }

  useEffect(() => {
    console.log("media", media)
    if (media) {
      if (currentFileType) {
        setImage(media)
      } else {
        setFile(media)
      }
    }
  }, [media])

  useEffect(() => {
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
    socket.on(getProfileId(), (payload) => {
      console.log("payload", payload)
      const newMsg = {
        message: payload.message,
        time: payload.time,
        senderId: payload.senderId === getProfileId() ? 11 : 1,
        type: payload.msgType,
        link: payload.link,
        filename: payload.filename
      }

      console.log(chatData, newMsg)

      setChatData((prevState) => {
        const newChat = { ...prevState }
        newChat.chat.chat.push(newMsg)
        return newChat
      })
    })
    return () => {
      socket.off(getProfileId())
    }
  }, [])

  useEffect(() => {
    if (ChatUserId !== null) {
      setContactId(ChatUserId)
      setImage(null)
      setFile(null)
      dispatch(userActions.getUserRequest(ChatUserId))
      dispatch(chatActions.getChatHistoryRequest(ChatUserId))
    } else if (userNotFound || ChatUserId === null) {
      dispatch(userActions.resetAllStatus())
      navigate("/home")
    }
  }, [dispatch, ChatUserId, userNotFound])

  useEffect(() => {
    if (!isObjEmpty(user)) {
      const data = {
        chat: {
          id: getProfileId(),
          myId: getUserData().personalInfo?.fullName ?? "",
          userId: contactId,
          avatar: user?.personalInfo?.profile_image?.url || null,
          unseenMsgs: 0,
          chat:
            chatHistory && chatHistory.length > 0
              ? chatHistory.map((item) => {
                  return {
                    message: item.message,
                    time: new Date(),
                    senderId: item.senderId === getProfileId() ? 11 : 1,
                    type: item.msgType,
                    link: item.link,
                    filename: item.filename
                  }
                })
              : []
        },
        contact: {
          id: user._id,
          fullName: user?.personalInfo?.fullName,
          avatarContent: user?.personalInfo?.fullName,
          avatar: user?.personalInfo?.profile_image?.url || null,
          status: "Online"
        }
      }
      dispatch(userActions.resetAllStatus())

      setChatData(data)
    }
  }, [chatHistory, user])

  const formattedChatData = () => {
    let chatLog = chatData.chat.chat
    const formattedChatLog = []
    let chatMessageSenderId = chatLog[0] ? chatLog[0].senderId : undefined
    let msgGroup = {
      senderId: chatMessageSenderId,
      messages: []
    }

    chatLog.forEach((msg, index) => {
      if (chatMessageSenderId === msg.senderId) {
        msgGroup.messages.push({
          filename: msg.filename || "", // Include filename if available
          type: msg.type || "text", // Default to "text" if no type specified
          link: msg.link || "", // Include link if available
          msg: msg.message,
          time: msg.time
        })
      } else {
        formattedChatLog.push(msgGroup)
        chatMessageSenderId = msg.senderId
        msgGroup = {
          senderId: msg.senderId,
          messages: [
            {
              filename: msg.filename || "",
              type: msg.type || "text",
              link: msg.link || "",
              msg: msg.message,
              time: msg.time
            }
          ]
        }
      }
      if (index === chatLog.length - 1) formattedChatLog.push(msgGroup)
    })

    return formattedChatLog
  }

  const onDropMedia = (acceptedFiles, rejectedFiles, type) => {
    if (rejectedFiles.length) {
      if (
        rejectedFiles.length > 0 &&
        rejectedFiles[0]?.file?.size > maxFileSize
      ) {
        toast.error("File size is too large")
      } else {
        toast.error("File type is not supported")
      }

      return
    } else {
      if (type) {
        acceptedFiles.forEach((file) => {
          if (file.size > maxFileSize) {
            toast.error("File size error")
            return
          }

          encodeBase64String(file)
            .then((base64String) => {
              setCurrentFileType(true)
              dispatch(
                chatActions.uploadChatMediaRequest({
                  image: base64String
                })
              )
            })
            .catch((err) => {
              toast.error("Error in uploading image , Try Again.")
            })
        })
      } else {
        setCurrentFileType(false)
        if (acceptedFiles.length === 0) {
          return
        } else {
          let newFiles = acceptedFiles.map((file) =>
            Object.assign(file, {
              preview: URL.createObjectURL(file)
            })
          )
          dispatch(chatActions.uploadChatDocumentRequest(newFiles))
        }
      }
    }
  }

  //** Renders user chat
  const renderChats = () => {
    return formattedChatData().map((item, index) => {
      return (
        <div
          key={index}
          className={classnames("chat", {
            "chat-left": item.senderId !== 11
          })}
        >
          <div className="chat-avatar">
            <Avatar
              className="box-shadow-1 cursor-pointer"
              color="light-primary"
              content={
                item.senderId === 1
                  ? chatData.contact.avatarContent
                  : chatData.chat.myId
              }
              initials
            />
          </div>

          <div className="chat-body">
            {item.messages.map((chat, index) => (
              <div key={index} className="chat-content">
                {chat.type === "media-img" ? (
                  <div>
                  <div className="flex d-flex align-items-center">
                    

                    <img
                      src={chat.link}
                      alt={chat.message}
                      style={{ width: "100px", height: "auto" }}
                    />
                    <Button color="secondary" size="sm" className="btn-icon ms-1  ">
                      <div
                        className="underline-text hover-primary"
                        onClick={() => window.open(chat.link, "_blank")}
                      >
                        View
                      </div>
                    </Button>
                    </div>

                    <p>{chat.msg}</p>
                  </div>
                ) : chat.type === "media-doc" ? (
                  <CardBody className="flex d-flex justify-content-between align-items-center">
                    <div className="d-flex align-items-center">
                      <div className="me-1">
                        <FileText size="28" />
                      </div>
                      <div>
                        <p className="wrap-content mb-0">{chat.filename}</p>
                        <Button
                          color="secondary"
                          size="sm"
                          className="btn-icon"
                        >
                          <div
                            className="underline-text hover-primary"
                            onClick={() => window.open(chat.link, "_blank")}
                          >
                            View
                          </div>
                        </Button>
                        <p className="wrap-content mb-0">{chat.msg}</p>
                      </div>
                    </div>
                  </CardBody>
                ) : (
                  <p>{chat.msg}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )
    })
  }

  //   <div className="chat-body">
  //   {item.type === "media-img" ? (
  //     <div className="chat-content">
  //       <img src={item.link} alt={item.message} style={{ width: "100px", height: "auto" }} />
  //       <p>{item.message}</p>
  //     </div>
  //   ) : item.type === "media-doc" ? (
  //     <div className="chat-content">
  //       <Card className="border-primary">
  //         <CardBody className="flex d-flex justify-content-between align-items-center gap-3">
  //           <div className="d-flex align-items-center">
  //             <div className="me-1">
  //               <FileText size="28" />
  //             </div>
  //             <div>
  //               <p className="wrap-content mb-0">{item.message}</p>
  //               <div className="underline-text hover-primary">
  //                 <a href={item.link} target="_blank" rel="noopener noreferrer">
  //                   View
  //                 </a>
  //               </div>
  //             </div>
  //           </div>
  //         </CardBody>
  //       </Card>
  //     </div>
  //   ) : (
  //     <div className="chat-content">
  //       <p>{item.message}</p>
  //     </div>
  //   )}
  // </div>

  //** Scroll to chat bottom
  const scrollToBottom = () => {
    chatRef.scrollTop = Number.MAX_SAFE_INTEGER
  }

  useEffect(() => {
    if (chatRef !== null) {
      scrollToBottom()
    }
  }, [chatRef, chatData.chat.chat.length])

  const handleSendMsg = (e) => {
    e.preventDefault()
    if (msg.trim().length || image || file) {
      const newMsg = chatData

      newMsg.chat.chat.push({
        message: msg.trim().length ? msg : "",
        time: new Date(),
        senderId: 11,
        type: image ? "media-img" : file ? "media-doc" : "text",
        link: image ? image.url : file ? file.url : "",
        filename: file ? file.filename : ""
      })

      //      newMsg.chat.chat.push({
      //      message: msg,
      //    time: new Date(),
      //  senderId: 11
      // })

      console.log("newmsg", newMsg)

      setChatData(newMsg)

      const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
      socket.emit("message", {
        type: "chat",
        senderId: getProfileId(),
        receiverId: contactId,
        message: msg,
        msgType: image ? "media-img" : file ? "media-doc" : "text",
        link: image ? image.url : file ? file.url : "",
        filename: file ? file.filename : ""
      })

      setMsg("")

      if (image) {
        setImage(null)
      } else if (file) {
        setFile(null)
      }
    }
  }

  return fetchingUsers ? (
    <div className="text-center">
      <Spinner color="primary" className="mb-1" />
    </div>
  ) : (
    <>
      <Card className="chat-widget">
        <CardHeader>
          <div className="flex d-flex align-items-center">
            <Avatar
              color="light-primary"
              status="online"
              content={chatData.contact.avatarContent}
              imgHeight="34"
              imgWidth="34"
              initials
            />

            <h5 className="mb-0 ms-50">{chatData.contact.fullName}</h5>
          </div>
          <div className="d-flex align-items-center">
            <Video
              size={18}
              className="cursor-pointer me-2"
              onClick={() => {
                const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
                socket.emit("startCall", {
                  isGroupCall: false,
                  receiverId: contactId,
                  callerId: getProfileId(),
                  callType: "video"
                })
              }}
            />

            <Phone
              size={18}
              className="cursor-pointer me-2"
              onClick={() => {
                const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
                socket.emit("startCall", {
                  isGroupCall: false,
                  receiverId: contactId,
                  callerId: getProfileId(),
                  callType: "audio"
                })
              }}
            />
          </div>

          {/* <MoreVertical size={18} className="cursor-pointer" /> */}
        </CardHeader>
        <div className="chat-app-window">
          <PerfectScrollbar
            containerRef={(el) => setChatRef(el)}
            className="user-chats scroll-area"
            options={{ wheelPropagation: false }}
          >
            <div className="chats">{renderChats()}</div>
          </PerfectScrollbar>
          {image || file ? (
            <Card className="">
              {" "}
              <CardBody>
                <div className="flex items-center">
                  <div className="d-flex flex-row items-center gap-4">
                    {image && (
                      <div className="flex items-center gap-4">
                        <img
                          src={image.url}
                          alt="media"
                          className="rounded-md"
                          width={90}
                          height={90}
                        />
                        <Button
                          color="danger"
                          outline
                          size="sm"
                          className="btn-icon ms-2"
                          onClick={() => setImage(null)}
                        >
                          <X size={14} className="me-50" />
                          Remove
                        </Button>
                      </div>
                    )}
                    {file && (
                      <div>
                        <Card className="border-primary">
                          <CardBody className="flex d-flex justify-content-between align-items-center gap-3">
                            <div className="d-flex align-items-center">
                              <div className="me-1">
                                <FileText size="28" />
                              </div>
                              <div>
                                <p className="wrap-content mb-0">
                                  {file.filename}
                                </p>
                                <div className="underline-text hover-primary">
                                  <a
                                    href={file.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    View
                                  </a>
                                </div>
                              </div>
                            </div>

                            <Button
                              color="danger"
                              outline
                              size="sm"
                              className="btn-icon"
                              onClick={() => setFile(null)}
                            >
                              <X size={14} />
                            </Button>
                          </CardBody>
                        </Card>
                      </div>
                    )}
                  </div>
                </div>
              </CardBody>
            </Card>
          ) : null}
          {/* {
  image.map((image, index) => (
    <div key={index} className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
      <img
        alt="File Thumbnail"
        className="rounded-md"
        height={48}
        src={image.preview}
        style={{
          aspectRatio: "48/48",
          objectFit: "cover",
        }}
        width={48}
      />
      <div className="flex-1">
        <p className="text-sm font-medium">{image.name}</p>
        <p className="text-sm text-gray-500 dark:text-gray-400">{image.size} bytes</p>
      </div>
    </div>
  ))
} */}
          {/* 
              {
                file.map((file, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <FilePlus className="w-4 h-4 flex-shrink-0" />
                    <Link className="text-sm font-medium" href="#">
                      {file.name}
                    </Link>
                    <span className="text-xs ml-auto shrink-0 text-gray-500 dark:text-gray-400">{file.size} bytes</span>
                  </div>
                ))
              }
 */}
          <Form
            className="chat-app-form flex flex-col h-auto"
            onSubmit={(e) => e.preventDefault()}
          >
            <InputGroup className="input-group-merge me-1 form-send-message">
              <div className="justify-content-center align-items-center d-flex">
                <Dropzone
                  disabled={file ? true : false}
                  maxFileSize={maxFileSize}
                  multiple={false}
                  accept={{
                    "image/*": [
                      ".jpeg",
                      ".png",
                      ".gif",
                      ".bmp",
                      ".svg",
                      ".webp"
                    ]
                  }}
                  onDrop={(acceptedFiles, rejectedFiles) =>
                    onDropMedia(acceptedFiles, rejectedFiles, true)
                  }
                >
                  {({ getRootProps, getInputProps }) => (
                    <div {...getRootProps()}>
                      <input {...getInputProps()} />
                      <Image
                        className="cursor-pointer text-secondary me-1"
                        size={18}
                      />
                    </div>
                  )}
                </Dropzone>
                <Dropzone
                  disabled={image ? true : false}
                  maxFileSize={maxFileSize}
                  multiple={false}
                  accept={{
                    "application/pdf": [".pdf"],
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                      [".docx", ".doc"],
                    "text/plain": [".txt"]
                  }}
                  onDrop={(acceptedFiles, rejectedFiles) =>
                    onDropMedia(acceptedFiles, rejectedFiles, false)
                  }
                >
                  {({ getRootProps, getInputProps }) => (
                    <div {...getRootProps()}>
                      <input {...getInputProps()} />
                      <FilePlus
                        className="cursor-pointer text-secondary"
                        size={18}
                      />
                    </div>
                  )}
                </Dropzone>
              </div>

              <Input
                type="textarea"
                value={msg}
                className="border-0 resize-none overflow-hidden"
                onChange={(e) => setMsg(e.target.value)}
                placeholder="Type your message"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    setMsg((prevMsg) => prevMsg + "\n")
                  }
                }}
              />
            </InputGroup>
            {/* Add onClick to Button */}
            <Button
              className="send"
              color="primary"
              type="button"
              onClick={(e) => handleSendMsg(e)}
            >
              <Send size={14} className="d-lg-none" />
              <span className="d-none d-lg-block">Send</span>
            </Button>
          </Form>{" "}
        </div>
      </Card>
      <VideoCallModal
        show={show}
        setShow={setShow}
        handleModalClosed={handleModalClosed}
        isGroupCall={false}
        callID={contactId}
        callType={callType}
        callerId={getProfileId()}
      />
    </>
  )
}
export default CardChat
