import { COURSE_TYPES } from "./types"
import useJwt from "@src/auth/jwt/useJwt"

const config = useJwt.jwtConfig

const initialState = {
  courses: {},
  error: null,
  deleted: false,
  updated: false,
  created: false,
  createdUpdatedLoading: false
}

const courseReducer = (state = initialState, action) => {
  switch (action.type) {
    case COURSE_TYPES.GET_ALL_COURSES_REQUEST:
      return {
        ...state,
        updated: false,
        deleted: false,
        created: false
      }
    case COURSE_TYPES.GET_ALL_COURSES_SUCCESS:
      return {
        ...state,
        courses: action.payload
      }
    case COURSE_TYPES.GET_ALL_COURSES_FAIL:
      return {
        ...state,
        error: action.payload
      }
    case COURSE_TYPES.CREATE_COURSE_REQUEST:
      return {
        ...state,
        created: false,
        createdUpdatedLoading: true
      }
    case COURSE_TYPES.CREATE_COURSE_SUCCESS:
      if (localStorage.getItem(config.currentPlan) !== "advance") {
        localStorage.setItem(
          "currCreateCourseSetLimit",
          action.payload?.current
            ? action.payload?.current
            : localStorage.getItem("currCreateCourseSetLimit") > 0
            ? localStorage.getItem("currCreateCourseSetLimit") - 1
            : 0
        )
      }

      return {
        ...state,
        created: true,
        createdUpdatedLoading: false
      }
    case COURSE_TYPES.CREATE_COURSE_FAIL:
      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false
      }
    case COURSE_TYPES.UPDATE_COURSE_REQUEST:
      return {
        ...state,
        createdUpdatedLoading: true,
        updated: false
      }
    case COURSE_TYPES.UPDATE_COURSE_SUCCESS:
      return {
        ...state,
        updated: true,
        createdUpdatedLoading: false
      }
    case COURSE_TYPES.UPDATE_COURSE_FAIL:
      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false
      }

    case COURSE_TYPES.DELETE_COURSE_REQUEST:
      return {
        ...state,
        deleted: false
      }

    case COURSE_TYPES.DELETE_COURSE_SUCCESS:
      if (localStorage.getItem(config.currentPlan) !== "advance") {
        localStorage.setItem(
          "currCreateCourseSetLimit",
          action.payload?.current
            ? action.payload?.current
            : localStorage.getItem("currCreateCourseSetLimit") <
              localStorage.getItem("createCourseSetLimit")
            ? localStorage.getItem("currCreateCourseSetLimit") + 1
            : 0
        )
      }

      return {
        ...state,
        deleted: true
      }

    case COURSE_TYPES.DELETE_COURSE_FAIL:
      return {
        ...state,
        error: action.payload,
        deleted: false
      }

    default:
      return state
  }
}

export default courseReducer
