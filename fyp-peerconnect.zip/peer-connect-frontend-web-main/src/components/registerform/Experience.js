import "react-slidedown/lib/slidedown.css"
import "@styles/react/libs/flatpickr/flatpickr.scss"
import { Fragment, useState } from "react"

import { useFormik } from "formik"

import { ArrowLeft, ArrowRight, Plus, X } from "react-feather"

import Repeater from "@components/repeater"
import { SlideDown } from "react-slidedown"

import { Label, Row, Col, Button, Form, Input } from "reactstrap"
import Flatpickr from "react-flatpickr"

const Experience = ({ stepper, setData, setStep }) => {
  const deleteForm = (e, i, formName) => {
    e.preventDefault()
    const formArray = values[formName]
    formArray.splice(i, 1)
    setFieldValue(formName, formArray)
  }

  const initialValues = {
    experience: [
      {
        jobTitle: "",
        company: "",
        startDate: "",
        endDate: "",
        isCurrentlyWorking: false
      }
    ]
  }

  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues
  } = useFormik({
    initialValues,
    // validationSchema,
    onSubmit: (values) => {
      const filteredExperience = values.experience.filter(exp => {
        return exp.jobTitle || exp.company || exp.startDate || exp.endDate || exp.isCurrentlyWorking;
      });
    
      setData({ ...values, experience: filteredExperience });
      // setData(values)
      setStep(4)
      setIsSubmit(false)
      stepper.next()
    }
  })

  const [isSubmit, setIsSubmit] = useState(false)

  return (
    <Fragment>
      <div className="content-header">
        <h5 className="mb-0">Experience</h5>
        <small>Enter Your Experience.</small>
      </div>
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setIsSubmit(true)
          handleSubmit()
        }}
      >
        <Repeater count={values.experience.length}>
          {(i) => {
            const Tag = i === 0 ? "div" : SlideDown
            return (
              <Tag key={i} className="repeater-wrapper">
                <Row>
                  <Col className="d-flex position-relative pe-0" sm="12">
                    <Row className="w-100 pe-lg-0 pe-1 py-2">
                      <Row>
                        <Col md="6" sm="6" className="mb-1">
                          <Label
                            for={`experience.${i}.jobTitle`}
                            className="form-label"
                          >
                            Job Title
                          </Label>
                          <Input
                            id={`experience.${i}.jobTitle`}
                            value={values.experience[i].jobTitle}
                            name={`experience.${i}.jobTitle`}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            placeholder=""
                            bsSize="sm"
                          />
                          {isSubmit &&
                            errors.experience &&
                            errors.experience[i] &&
                            errors.experience[i].jobTitle && (
                              <div className="text-danger">
                                {errors.experience[i].jobTitle}
                              </div>
                            )}
                        </Col>
                        <Col md="6" sm="6" className="mb-1">
                          <Label
                            for={`experience.${i}.company`}
                            className="form-label"
                          >
                            Company
                          </Label>
                          <Input
                            value={values.experience[i].company}
                            id={`experience.${i}.company`}
                            bsSize="sm"
                            name={`experience.${i}.company`}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            placeholder=""
                          />
                          {isSubmit &&
                            errors.experience &&
                            errors.experience[i] &&
                            errors.experience[i].company && (
                              <div className="text-danger">
                                {errors.experience[i].company}
                              </div>
                            )}
                        </Col>
                      </Row>

                      <div className="mb-1">
                        <div className="form-check form-check-inline">
                          <Input
                            checked={values.experience[i].isCurrentlyWorking}
                            type="checkbox"
                            id="cj-checkbox"
                            className="form-check-input"
                            name={`experience.${i}.isCurrentlyWorking`}
                            onChange={handleChange}
                            onBlur={handleBlur}
                          />

                          <Label for="cj-checkbox" className="form-check-label">
                            Currently Working
                          </Label>
                          {isSubmit &&
                            errors.experience &&
                            errors.experience[i] &&
                            errors.experience[i].isCurrentlyWorking && (
                              <div className="text-danger">
                                {errors.experience[i].isCurrentlyWorking}
                              </div>
                            )}
                        </div>
                      </div>
                      <Row>
                        <Col md="6" sm="12" className="mb-1">
                          <Label
                            className="form-label"
                            for={`experience.${i}.start_date`}
                          >
                            Start Date
                          </Label>
                          <Flatpickr
                            value={values.experience[i].startDate}
                            id={`experience.${i}.start_date`}
                            placeholder="Start Date"
                            className="form-control"
                            onChange={(date) => {
                              setFieldValue(`experience.${i}.startDate`, date)
                            }}
                            options={{
                              dateFormat: "F, Y",
                              mode: "single",
                              noCalendar: false,
                              enableTime: false,
                              monthSelectorType: "static",
                              disableMobile: true
                            }}
                            onBlur={handleBlur}
                          />

                          {isSubmit &&
                            errors.experience &&
                            errors.experience[i] &&
                            errors.experience[i].startDate && (
                              <div className="text-danger">
                                {errors.experience[i].startDate}
                              </div>
                            )}
                        </Col>
                        <Col md="6" sm="12" className="mb-1">
                          <Label className="form-label" for="nameMulti">
                            End Date
                          </Label>

                          <Flatpickr
                            className="form-control"
                            disabled={values.experience[i].isCurrentlyWorking}
                            value={
                              values.experience[i].isCurrentlyWorking
                                ? ""
                                : values.experience[i].endDate
                            }
                            placeholder="End Date"
                            onChange={(date) => {
                              setFieldValue(`experience.${i}.endDate`, date)
                            }}
                            options={{
                              dateFormat: "F, Y",
                              mode: "single",
                              noCalendar: false,
                              enableTime: false,
                              monthSelectorType: "static",
                              disableMobile: true
                            }}
                            onBlur={handleBlur}
                          />

                          {isSubmit &&
                            errors.experience &&
                            errors.experience[i] &&
                            errors.experience[i].endDate && (
                              <div className="text-danger">
                                {errors.experience[i].endDate}
                              </div>
                            )}
                        </Col>
                      </Row>
                    </Row>
                    <div className="d-flex justify-content-center px-25">
                      {values.experience.length > 1 && (
                        <X
                          size={18}
                          className="cursor-pointer"
                          onClick={(e) => {
                            deleteForm(e, i, "experience")
                          }}
                        />
                      )}
                    </div>
                  </Col>
                </Row>
              </Tag>
            )
          }}
        </Repeater>

        <Row className="mt-1 ps-1 mb-1">
          <Col sm="12" className="px-0">
            <Button
              color="primary"
              size="sm"
              className="btn-add-new"
              onClick={() => {
                // functionality to add new form

                setFieldValue(`experience.${values.experience.length}`, {
                  jobTitle: "",
                  company: "",
                  startDate: "",
                  endDate: "",
                  isCurrentlyWorking: false
                })
              }}
            >
              <Plus size={14} className="me-25" />
              <span className="align-middle">Add Item</span>
            </Button>
          </Col>
        </Row>
        <div className="d-flex justify-content-between">
          <Button
            color="primary"
            className="btn-prev"
            onClick={() => stepper.previous()}
          >
            <ArrowLeft
              size={14}
              className="align-middle me-sm-25 me-0"
            ></ArrowLeft>
            <span className="align-middle d-sm-inline-block d-none">
              Previous
            </span>
          </Button>
          <Button type="submit" color="primary" className="btn-next">
            <span className="align-middle d-sm-inline-block d-none">Next</span>
            <ArrowRight
              size={14}
              className="align-middle ms-sm-25 ms-0"
            ></ArrowRight>
          </Button>
        </div>
      </Form>
    </Fragment>
  )
}

export default Experience
