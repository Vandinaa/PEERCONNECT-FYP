import { Button, Col, Modal, ModalBody, ModalHeader, Row } from "reactstrap"
import {
  Mic,
  MicOff,
  MoreHorizontal,
  PhoneOff,
  Video,
  VideoOff
} from "lucide-react"
import React, { useCallback, useEffect, useRef, useState } from "react"

import Peer from "simple-peer"
import socketIOClient from "socket.io-client"
import { useNavigate } from "react-router-dom"

const styles = {
  modalBody: {
    padding: 0,
    backgroundColor: "#1a1a2e",
    color: "white"
  },
  videoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "1rem",
    padding: "1rem"
  },
  videoItem: {
    position: "relative",
    aspectRatio: "16 / 9",
    overflow: "hidden",
    borderRadius: "0.5rem"
  },
  video: {
    width: "100%",
    height: "100%",
    objectFit: "cover"
  },
  videoOverlay: {
    position: "absolute",
    bottom: "1rem",
    left: "1rem",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    padding: "0.5rem",
    borderRadius: "0.5rem"
  },
  userName: {
    color: "white",
    fontSize: "0.9rem"
  },
  actionBar: {
    display: "flex",
    justifyContent: "center",
    gap: "1rem",
    padding: "1rem",
    backgroundColor: "rgba(0, 0, 0, 0.8)"
  },
  actionButton: {
    backgroundColor: "#2c2c2c",
    border: "none",
    color: "white",
    padding: "0.75rem",
    borderRadius: "50%",
    cursor: "pointer",
    transition: "background-color 0.3s"
  },
  endCallButton: {
    backgroundColor: "#e74c3c"
  }
}

function VideoCallModal({
  show,
  setShow,
  handleModalClosed,
  callerId,
  callID,
  callType,
  isGroupCall
}) {
  const [myStream, setMyStream] = useState(null)
  const [remoteStream, setRemoteStream] = useState(null)
  const [videoEnabled, setVideoEnabled] = useState(callType === "video")
  const [audioEnabled, setAudioEnabled] = useState(true)
  const myVideoRef = useRef(null)
  const remoteVideoRef = useRef(null)
  const socket = useRef(null)
  const peerRef = useRef(null)
  const navigate = useNavigate()
  const [connectionState, setConnectionState] = useState("new")

  useEffect(() => {
    socket.current = socketIOClient(process.env.REACT_APP_SOCKET_URL)

    socket.current.on("getOffer-" + callerId, async (data) => {
      console.log("Offer received:", data)
      if (peerRef.current && peerRef.current.connected) {
        console.warn("Received an offer while already connected")
        return
      }

      const mediaConstraints = { audio: true, video: callType === "video" }
      const stream = await navigator.mediaDevices.getUserMedia(mediaConstraints)
      setMyStream(stream)

      const peer = new Peer({ initiator: false, trickle: false, stream })

      peer.on("signal", (answer) => {
        console.log("Sending answer:", answer)
        socket.current.emit("sendAnswer", {
          answer,
          to: data.callerId,
          from: callerId
        })
      })

      peer.on("stream", (stream) => {
        console.log("Remote stream received")
        setRemoteStream(stream)
      })

      peer.on("connect", () => {
        console.log("Peer connection established")
        setConnectionState("connected")
      })

      peer.on("error", (err) => {
        console.error("Peer error:", err)
      })

      peer.on("connectionStateChange", () => {
        if (peerRef.current._pc.connectionState === "failed") {
          console.error("Connection state change: failed")
          endCall(true, callID) // end the call if connection failed
        }
      })

      peer.signal(data.offer)
      peerRef.current = peer
      setConnectionState("connecting")
    })

    socket.current.on(`getAnswer-${callerId}`, async (data) => {
      console.log("Answer received:", data)
      if (peerRef.current) {
        try {
          await applyRemoteDescription(peerRef.current, data.answer)
        } catch (error) {
          console.error("Error setting remote description after retry:", error)
        }
      } else {
        console.error("Peer instance is not available to handle answer")
      }
    })

    socket.current.on(`endCall-${callerId}`, ({ from }) => {
      console.log("Call ended by the other party")
      endCall(false, from) // Don't emit 'endCall' again to avoid loop
    })

    return () => {
      if (socket.current) {
        socket.current.disconnect()
      }
      if (peerRef.current) {
        peerRef.current.destroy()
        peerRef.current = null
      }
    }
  }, [callerId, callType])

  useEffect(() => {
    if (show && callID) {
      handleCallUser()
    }
  }, [show, callID])

  const handleCallUser = useCallback(async () => {
    const mediaConstraints = { audio: true, video: callType === "video" }
    const stream = await navigator.mediaDevices.getUserMedia(mediaConstraints)
    setMyStream(stream)

    const peer = new Peer({ initiator: true, trickle: false, stream })

    peer.on("signal", (offer) => {
      console.log("Sending offer:", offer)
      socket.current.emit("sendOffer", {
        receiverId: callID,
        offer,
        callType,
        isGroupCall,
        callerId
      })
    })

    peer.on("stream", (stream) => {
      console.log("Remote stream received")
      setRemoteStream(stream)
    })

    peer.on("connect", () => {
      console.log("Peer connection established")
      setConnectionState("connected")
    })

    peer.on("error", (err) => {
      console.error("Peer error:", err)
    })

    peer.on("connectionStateChange", () => {
      if (peerRef.current._pc.connectionState === "failed") {
        console.error("Connection state change: failed")
        endCall(true, callID) // end the call if connection failed
      }
    })

    peerRef.current = peer
    setConnectionState("connecting")
  }, [callerId, callID, callType, isGroupCall])

  const toggleVideo = () => {
    if (myStream && myStream.getVideoTracks().length > 0) {
      myStream.getVideoTracks()[0].enabled = !videoEnabled
      setVideoEnabled(!videoEnabled)
    }
  }

  const toggleAudio = () => {
    if (myStream && myStream.getAudioTracks().length > 0) {
      myStream.getAudioTracks()[0].enabled = !audioEnabled
      setAudioEnabled(!audioEnabled)
    }
  }

  const endCall = (emitEvent = true, navto) => {
    if (peerRef.current) {
      peerRef.current.destroy()
      peerRef.current = null
    }
    if (socket.current && emitEvent) {
      socket.current.emit("endCall", { to: callID, from: callerId })
    }

    setShow(false)
    handleModalClosed()
    setMyStream(null)
    setRemoteStream(null)
    navigate(`/chats?id=${navto}`)
  }

  const applyRemoteDescription = async (peer, signalData) => {
    try {
      await peer.signal(signalData)
    } catch (error) {
      console.error("Error applying remote description:", error)
      if (error.name === "InvalidStateError") {
        console.warn(
          "Invalid state error while setting remote description. Retrying..."
        )
        setTimeout(() => applyRemoteDescription(peer, signalData), 1000)
      } else {
        throw error
      }
    }
  }

  useEffect(() => {
    if (myVideoRef.current) {
      myVideoRef.current.srcObject = myStream
    }
    if (remoteVideoRef.current && remoteStream) {
      console.log("Setting remote stream")
      remoteVideoRef.current.srcObject = remoteStream
    }
  }, [myStream, remoteStream])

  return (
    <Modal
      isOpen={show}
      onClosed={handleModalClosed}
      toggle={() => setShow(false)}
      backdrop="static"
      className="modal-dialog-centered modal-xl"
    >
      <ModalBody style={styles.modalBody}>
        <div style={styles.videoGrid}>
          <div style={styles.videoItem}>
            <video
              ref={myVideoRef}
              autoPlay
              muted
              playsInline
              style={styles.video}
            ></video>
            <div style={styles.videoOverlay}>
              <span style={styles.userName}>You</span>
            </div>
          </div>
          <div style={styles.videoItem}>
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              style={styles.video}
            ></video>
            <div style={styles.videoOverlay}>
              <span style={styles.userName}>Remote User</span>
            </div>
          </div>
        </div>
        <div style={styles.actionBar}>
          <button onClick={toggleVideo} style={styles.actionButton}>
            {videoEnabled ? <Video size={24} /> : <VideoOff size={24} />}
          </button>
          <button onClick={toggleAudio} style={styles.actionButton}>
            {audioEnabled ? <Mic size={24} /> : <MicOff size={24} />}
          </button>
          <button
            onClick={() => endCall(true, callID)}
            style={{ ...styles.actionButton, ...styles.endCallButton }}
          >
            <PhoneOff size={24} />
          </button>
        </div>
      </ModalBody>
    </Modal>
  )
}

export default VideoCallModal
