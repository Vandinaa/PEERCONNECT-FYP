import { CHAT_TYPES } from "./types"

const initialState = {
  chatHistory: {},
  chatHistoryLoading: false,
  groupChatHistory: [],
  groupChatHistoryLoading: false,
  chatNotification: [],
  error: null,
  media: null,
}

const chatReducer = (state = initialState, action) => {
  switch (action.type) {
    case CHAT_TYPES.GET_CHAT_HISTORY_REQUEST:
      return {
        ...state,
        chatHistoryLoading: true
      }

    case CHAT_TYPES.GET_CHAT_HISTORY_SUCCESS:
      return {
        ...state,
        chatHistory: action.payload,
        chatHistoryLoading: false
      }

    case CHAT_TYPES.GET_CHAT_HISTORY_FAIL:
      return {
        ...state,
        error: action.payload,
        chatHistoryLoading: false
      }

    case CHAT_TYPES.GET_GROUP_CHAT_HISTORY_REQUEST:
      return {
        ...state,
        groupChatHistoryLoading: true
      }

    case CHAT_TYPES.GET_GROUP_CHAT_HISTORY_SUCCESS:
      return {
        ...state,
        groupChatHistory: action.payload,
        groupChatHistoryLoading: false
      }

    case CHAT_TYPES.GET_GROUP_CHAT_HISTORY_FAIL:
      return {
        ...state,
        error: action.payload,
        groupChatHistoryLoading: false
      }

    case CHAT_TYPES.UPLOAD_CHAT_MEDIA_REQUEST:
      return {
        ...state,
        media: null
      }

    case CHAT_TYPES.UPLOAD_CHAT_MEDIA_SUCCESS:
      return {
        ...state,
        media: action.payload
      }

    case CHAT_TYPES.UPLOAD_CHAT_MEDIA_FAIL:
      return {
       media: null,
        ...state,
        error: action.payload
      }

    case CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_REQUEST:
      return {
        ...state,
        media: null
      }

    case CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_SUCCESS:
      return {
        ...state,
        media: action.payload
      }

    case CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_FAIL:
      return {
       media: null,
        ...state,
        error: action.payload
      }
      
    case CHAT_TYPES.CHAT_NOTIFICATION_REQUEST:
      return {
        ...state,
        chatNotification: null
      }

    case CHAT_TYPES.CHAT_NOTIFICATION_SUCCESS:
      return {
        ...state,
        chatNotification: action.payload
      }

    case CHAT_TYPES.CHAT_NOTIFICATION_FAIL:
      return {
        chatNotification: null,
        ...state,
        error: action.payload
      }
      






    // case CHAT_TYPES.CREATE_CHAT_REQUEST:
    //   return {
    //     ...state,
    //     added: false,
    //     updated: false,
    //     createdUpdatedLoading: true
    //   }
    // case CHAT_TYPES.CREATE_CHAT_SUCCESS:
    //   return {
    //     ...state,
    //     added: true,
    //     createdUpdatedLoading: false
    //   }
    // case CHAT_TYPES.CREATE_CHAT_FAIL:
    //   return {
    //     ...state,
    //     error: action.payload,
    //     createdUpdatedLoading: false
    //   }

    // case CHAT_TYPES.RESET_ADDED_STATUS:
    //   return {
    //     ...state,
    //     added: false,
    //     updated: false
    //   }

    // case CHAT_TYPES.GET_CHAT_REQUEST:
    //   return {
    //     ...state,
    //     chatLoading: true
    //   }

    // case CHAT_TYPES.GET_CHAT_SUCCESS:
    //   return {
    //     ...state,
    //     chat: action.payload,
    //     chatLoading: false
    //   }

    // case CHAT_TYPES.GET_CHAT_FAIL:
    //   return {
    //     ...state,
    //     error: action.payload,
    //     chatLoading: false
    //   }

    // case CHAT_TYPES.UPDATE_CHAT_REQUEST:
    //   return {
    //     ...state,
    //     updated: false,
    //     createdUpdatedLoading: true
    //   }

    // case CHAT_TYPES.UPDATE_CHAT_SUCCESS:
    //   return {
    //     ...state,
    //     updated: true,
    //     createdUpdatedLoading: false
    //   }

    // case CHAT_TYPES.UPDATE_CHAT_FAIL:
    //   return {
    //     ...state,
    //     error: action.payload,
    //     createdUpdatedLoading: false
    //   }

    // case CHAT_TYPES.DELETE_CHAT_REQUEST:
    //   return {
    //     ...state,
    //     deleted: false
    //   }

    // case CHAT_TYPES.DELETE_CHAT_SUCCESS:
    //   return {
    //     ...state,
    //     deleted: true
    //   }

    // case CHAT_TYPES.DELETE_CHAT_FAIL:
    //   return {
    //     ...state,
    //     error: action.payload
    //   }

    // case CHAT_TYPES.GET_ALL_CHAT_REQUEST:
    //   return {
    //     ...state,
    //     added: false,
    //     updated: false,

    //     chatsLoading: true
    //   }

    // case CHAT_TYPES.GET_ALL_CHAT_SUCCESS:
    //   return {
    //     ...state,
    //     chats: action.payload,
    //     chatsLoading: false
    //   }

    // case CHAT_TYPES.GET_ALL_CHAT_FAIL:
    //   return {
    //     ...state,
    //     error: action.payload,
    //     chatsLoading: false
    //   }

    default:
      return state
  }
}

export default chatReducer
