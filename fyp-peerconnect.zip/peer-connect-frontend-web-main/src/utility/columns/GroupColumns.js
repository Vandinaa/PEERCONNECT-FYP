import classNames from "classnames"

export const groupColumns = (SidebarModulesCallback) => {
  return [
    {
      name: "ID",
      sortable: true,
      minWidth: "50px",
      maxWidth: "50px",
      selector: (row) => row.index,
      cell: (row) => (
        <div className="d-flex justify-content-center align-items-center">
          {row.index}
        </div>
      )
    },
    {
      name: "Group Name",
      sortable: true,
      minWidth: "300px",
      sortField: "name",
      selector: (row) => row.name,
      cell: (row) => (
        <div
          className={classNames(
            "d-flex justify-content-left align-items-center text-capitalize",
            { "hover cursor-pointer text-primary": row.availabilityStatus }
          )}
        >
          <div className="d-flex flex-column">
            <span
              className="fw-bolder"
              onClick={() => {
                if (row.availabilityStatus) {
                  SidebarModulesCallback(row.groupId)
                }
              }}
            >
              {row.name}
            </span>
          </div>
        </div>
      )
    },
    {
      name: "Description",
      sortable: true,
      minWidth: "150px",
      selector: (row) => row.description,
      cell: (row) => (
        <div className="d-flex justify-content-left align-items-center">
          <div className="d-flex flex-column">
            <span className="">{row.description}</span>
          </div>
        </div>
      )
    }
  ]
}
