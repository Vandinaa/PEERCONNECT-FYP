import { Fragment } from "react"
import InputPasswordToggle from "@components/input-password-toggle"

import { isObjEmpty } from "@utils"

import * as yup from "yup"
import { useForm, Controller } from "react-hook-form"
import { ArrowLeft, ArrowRight } from "react-feather"
import { yupResolver } from "@hookform/resolvers/yup"

import { Form, Label, Input, Row, Col, Button, FormFeedback } from "reactstrap"

const defaultValues = {
  email: "",
  password: "",
  confirmPassword: ""
}

const AccountDetails = ({ stepper, setData, setStep }) => {
  const SignupSchema = yup.object().shape({
    email: yup.string().email().required("Please Enter your email"),
    password: yup
      .string()
      .required("Please Enter your password")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        "Must Contain at least 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
      ),
    confirmPassword: yup
      .string()
      .required()
      .oneOf([yup.ref(`password`), null], "Passwords must match")
  })

  const {
    control,
    handleSubmit,
    formState: { errors }
  } = useForm({
    defaultValues,
    resolver: yupResolver(SignupSchema)
  })

  const onSubmit = (values) => {
    if (isObjEmpty(errors)) {
      setData(values)
      setStep(1)
      stepper.next()
    }
  }

  return (
    <Fragment>
      <div className="content-header">
        <h5 className="mb-0">Account Details</h5>
        <small className="text-muted">Enter Your Account Details.</small>
      </div>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="email">
              Email
            </Label>
            <Controller
              control={control}
              id="email"
              name="email"
              render={({ field }) => (
                <Input
                  type="email"
                  placeholder="john.doe@email.com"
                  invalid={errors.email && true}
                  {...field}
                />
              )}
            />
            {errors.email && (
              <FormFeedback>{errors.email.message}</FormFeedback>
            )}
          </Col>
        </Row>
        <Row className="justify-content-center">
          <div className="form-password-toggle col-md-6 mb-1">
            <Label className="form-label" for="password">
              Password
            </Label>
            <Controller
              id="password"
              name="password"
              control={control}
              render={({ field }) => (
                <InputPasswordToggle
                  className="input-group-merge"
                  invalid={errors.password && true}
                  {...field}
                />
              )}
            />

            {errors.password && (
              <FormFeedback>{errors.password.message}</FormFeedback>
            )}
          </div>
        </Row>
        <Row className="justify-content-center">
          <div className="form-password-toggle col-md-6 mb-1">
            <Label className="form-label" for="confirmPassword">
              Confirm Password
            </Label>
            <Controller
              id="confirmPassword"
              name="confirmPassword"
              control={control}
              render={({ field }) => (
                <InputPasswordToggle
                  className="input-group-merge"
                  invalid={errors.confirmPassword && true}
                  {...field}
                />
              )}
            />
            {errors.confirmPassword && (
              <FormFeedback>{errors.confirmPassword.message}</FormFeedback>
            )}
          </div>
        </Row>

        <div className="d-flex justify-content-between">
          <Button color="secondary" className="btn-prev" outline disabled>
            <ArrowLeft
              size={14}
              className="align-middle me-sm-25 me-0"
            ></ArrowLeft>
            <span className="align-middle d-sm-inline-block d-none">
              Previous
            </span>
          </Button>
          <Button type="submit" color="primary" className="btn-next">
            <span className="align-middle d-sm-inline-block d-none">Next</span>
            <ArrowRight
              size={14}
              className="align-middle ms-sm-25 ms-0"
            ></ArrowRight>
          </Button>
        </div>
      </Form>
    </Fragment>
  )
}

export default AccountDetails
