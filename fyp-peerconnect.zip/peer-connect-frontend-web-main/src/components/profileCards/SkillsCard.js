
import { Badge, Button, Card, CardBody, CardText, Col } from "reactstrap"
import { Fragment, useEffect, useState } from "react"
import { getProfileId } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import { Plus } from "react-feather"
import SkillForm from "../profileForms/SkillForm"
import { useTranslation } from "react-i18next"

const SkillsCard = ({ data, courses }) => {
  const { t } = useTranslation()


  const { loggedInUser } = useSelector((state) => state.usersReducer)

  const [sendSidebarOpen, setSendSidebarOpen] = useState({
    open: false,
    data: {},
    formType: ""
  })

  const toggleSendSidebar = () =>
    setSendSidebarOpen({
      open: !sendSidebarOpen.open,
      data: {},
      formType: ""
    })

  return (
    <Fragment>
      <Card>
        <CardBody>
          <div className="d-flex justify-content-between align-items-end">
            {data?.length > 0 ? (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Interests</h6>

                {data.map((interest, index) => {
                  return (
                    <Badge
                      key={index}
                      className="me-50 mt-50"
                      color="light-warning"
                    >
                      {interest.interestName}
                    </Badge>
                  )
                })}
              </div>
            ) : (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Interests</h6>
                <p className="mb-0">No Interests Found</p>
              </div>
            )}
          </div>

          <div className="d-flex justify-content-between align-items-end">
            {courses?.length > 0 ? (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Courses</h6>
                {courses?.map((course, index) => {
                  return (
                    <Badge key={index} className="me-1" color="light-primary">
                      {course?.courseName}
                    </Badge>
                  )
                })}
              </div>
            ) : (
              <div className="design-group mb-50 pt-50">
                <h6 className="section-label">Courses</h6>
                <p className="mb-0">No Courses Found</p>
              </div>
            )}
          </div>

          {getProfileId() === loggedInUser.id && (
            <div className="demo-inline-spacing">
              <Button
                color="primary"
                onClick={() => {
                  setSendSidebarOpen({
                    open: true,
                    data: {
                      interests: data,
                      courses: courses
                    },
                    formType: "edit"
                  })
                }}
              >
                <Plus className="me-50" size={14} />
                {t("Add/Edit")}
              </Button>
            </div>
          )}
        </CardBody>
      </Card>

      <SkillForm
        toggleSidebar={toggleSendSidebar}
        open={sendSidebarOpen.open}
        formType={sendSidebarOpen.formType}
        data={sendSidebarOpen.data}
      />
    </Fragment>
  )
}
export default SkillsCard
