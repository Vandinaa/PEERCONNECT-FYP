// ** React Imports

import "@styles/react/libs/flatpickr/flatpickr.scss"
import "@styles/react/libs/tables/react-dataTable-component.scss"

import * as coursesActions from "@src/store/common/courses/actions"

import { Button, Card, CardHeader, CardTitle, Col, Row } from "reactstrap"
import { ChevronDown, Edit, Plus, Trash } from "react-feather"
import { Fragment, useEffect, useState } from "react"
import { fieldExists, isNullObject, isObjEmpty } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import AddCourseForm from "@src/components/AddCourseForm"
import DataTable from "react-data-table-component"
import ReactPaginate from "react-paginate"
import Select from "react-select"
import Swal from "sweetalert2"
import { rowsItemsOptions } from "@src/utility/Options"
import { selectThemeColors } from "@utils"
import toast from "react-hot-toast"
import { useTranslation } from "react-i18next"
import withReactContent from "sweetalert2-react-content"

const MySwal = withReactContent(Swal)

const Course = () => {
  const { t } = useTranslation()

  const [rowsPerPage, setRowsPerPage] = useState({
    value: 20,
    label: "20"
  })

  const [currentPage, setCurrentPage] = useState(0)
  const [data, setData] = useState([])

  const [sendSidebarOpen, setSendSidebarOpen] = useState({
    open: false,
    data: {},
    formType: ""
  })

  const toggleSendSidebar = () =>
    setSendSidebarOpen({
      open: !sendSidebarOpen.open,
      data: {},
      formType: ""
    })

  const dispatch = useDispatch()

  const { courses, deleted, updated, created } = useSelector(
    (state) => state.courseReducer
  )

  useEffect(() => {
    if (created || updated || deleted) {
      sendSidebarOpen.open = false
      toast.success(
        created
          ? t("Course Created Successfully")
          : updated
          ? t("Course Updated Successfully")
          : t("Course Deleted Successfully")
      )
      dispatch(
        coursesActions.getAllCoursesRequest({
          perPage: rowsPerPage.value,
          page: currentPage + 1
        })
      )
    }
  }, [created, updated, deleted])

  const handleConfirmCancel = (data) => {
    return MySwal.fire({
      title: t("Are you sure?"),
      text: t("You won't be able to revert this!"),
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: t("Yes, delete it!"),
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(
          coursesActions.deleteCourseRequest({
            params: data.id
          })
        )
      }
    })
  }

  const ColumnsHeader = [
    {
      name: t("COURSE NAME"),
      // sortable: true,
      minWidth: "250px",
      capitalize: true,
      center: true,
      cell: (row) => {
        return (
          <div className="fw-bolder text-capitalize text-primary">
            <span>{row.name}</span>
          </div>
        )
      }
    },
    {
      name: t("COURSE CODE"),
      // sortable: true,
      cell : (row) => {
        return (
          <div className="fw-bolder text-uppercase">
            <span>{row.code}</span>
          </div>
        )
      }
    },
    {
      name: t("DESCRIPTION"),
      // sortable: true,
      minWidth: "250px",
      // center: true,
      selector: (row) => row.description
    },
    {
      name: t("INTERESTS"),
      // sortable: true,
      minWidth: "250px",
      cell: (row) => {
        return (
          <div>
            {row.interests && row.interests.length > 0 ? (
              row.interests.map((interest, idx, array) => {
                return (
                  <span key={idx}>
                    {idx === array.length - 1
                      ? interest.interestName
                      : interest.interestName + ", "}
                  </span>
                )
              })
            ) : (
              <span>None</span>
            )}
          </div>
        )
      }
    },
    {
      name: t("ACTIONS"),
      minWidth: "200px",
      cell: (row) => {
        return (
          <div className="d-flex justify-content-center">
            <Button
              size="sm"
              color="primary"
              outline
              className="btn btn-icon me-1"
              onClick={() => {
                setSendSidebarOpen({
                  open: true,
                  data: row,
                  formType: "edit"
                })
              }}
            >
              <Edit className="font-medium-2" />
              <span className="align-middle ms-50">{t("Edit")}</span>
            </Button>
            <Button
              size="sm"
              color="danger"
              outline
              className="btn btn-icon"
              onClick={() => {
                handleConfirmCancel(row)
              }}
            >
              <Trash className="font-medium-2" />
              <span className="align-middle ms-50">{t("Delete")}</span>
            </Button>
          </div>
        )
      }
    }
  ]

  useEffect(() => {
    setCurrentPage(0)
    if (isObjEmpty(!isNullObject(courses))) {
      dispatch(
        coursesActions.getAllCoursesRequest({
          perPage: rowsPerPage.value,
          page: currentPage + 1
        })
      )
    }
  }, [dispatch])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          id: item.id,
          name: item.courseName,
          code: item.courseCode,
          description: item.courseDescription,
          interests: item.interests
        }
      })
      setData(a)
    } else {
      setData([])
    }
    if (!isNullObject(courses)) {
      setCurrentPage(courses.page - 1)
    }
  }, [courses])

  const dataToRender = () => {
    return data
  }

  const handlePagination = (page) => {
    dispatch(
      coursesActions.getAllCoursesRequest({
        page: page.selected + 1,
        perPage: rowsPerPage
      })
    )
    setCurrentPage(page.selected)
  }

  // ** Function to handle per page
  const handlePerPage = (e) => {
    dispatch(
      coursesActions.getAllCoursesRequest({
        perPage: e.value,
        page: 1
      })
    )
    setCurrentPage(0)
    setRowsPerPage({
      value: e.value,
      label: e.label
    })
  }

  const CustomPagination = () => (
    <ReactPaginate
      nextLabel=""
      breakLabel="..."
      previousLabel=""
      pageRangeDisplayed={2}
      forcePage={currentPage}
      marginPagesDisplayed={2}
      activeClassName="active"
      pageClassName="page-item"
      breakClassName="page-item"
      nextLinkClassName="page-link"
      pageLinkClassName="page-link"
      breakLinkClassName="page-link"
      previousLinkClassName="page-link"
      nextClassName="page-item next-item"
      previousClassName="page-item prev-item"
      pageCount={courses?.totalPages ? courses.totalPages : 1}
      onPageChange={(page) => handlePagination(page)}
      containerClassName="pagination react-paginate separated-pagination pagination-sm justify-content-end pe-1 mt-1"
    />
  )

  return (
    <Fragment>
      <Card>
        <Row>
          <Col sm="12">
            <CardHeader className="flex-md-row flex-column align-md-items-center align-items-start border-bottom">
              <CardTitle tag="h4">{t("Courses")}</CardTitle>
              <div className="d-flex mt-md-0 mt-1">
                <Button
                  className="ms-2"
                  color="primary"
                  onClick={() => {
                    setSendSidebarOpen({
                      open: true,
                      data: "",
                      formType: "add"
                    })
                  }}
                >
                  <Plus size={15} />
                  <span className="align-middle ms-50">{t("Add Record")}</span>
                </Button>
              </div>
            </CardHeader>
            <div className="react-dataTable">
              <DataTable
                noHeader
                columns={ColumnsHeader}
                paginationPerPage={rowsPerPage}
                className="react-dataTable"
                sortIcon={<ChevronDown size={10} />}
                paginationDefaultPage={currentPage + 1}
                // paginationComponent={CustomPagination}
                data={dataToRender()}
              />
            </div>
            <CustomPagination />
          </Col>
          <Col lg="2" md="3" sm="1">
            <div className="ps-2 pb-2 d-flex align-items-center">
              <Select
                menuPlacement="top"
                theme={selectThemeColors}
                type="select"
                className="react-select"
                classNamePrefix="select"
                id="sort-select"
                options={rowsItemsOptions}
                isClearable={false}
                value={rowsPerPage}
                onChange={(e) => {
                  handlePerPage(e)
                }}
              />
            </div>
          </Col>
        </Row>
      </Card>
      <AddCourseForm
        toggleSidebar={toggleSendSidebar}
        open={sendSidebarOpen.open}
        formType={sendSidebarOpen.formType}
        data={sendSidebarOpen.data}
      />
    </Fragment>
  )
}
export default Course
