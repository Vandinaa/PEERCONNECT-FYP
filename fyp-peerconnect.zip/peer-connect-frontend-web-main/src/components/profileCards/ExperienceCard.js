import * as userActions from "@src/store/common/users/actions"

import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  CardTitle,
  Col
} from "reactstrap"
import { Fragment, useEffect, useState } from "react"
import {
  formatDateToShow,
  getProfileId,
  isNullObject
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import ExperienceForm from "@src/components/profileForms/ExperienceForm"
import { Plus } from "react-feather"
import Swal from "sweetalert2"
import classnames from "classnames"
import withReactContent from "sweetalert2-react-content"
import { useTranslation } from "react-i18next"
const MySwal = withReactContent(Swal)

const ExperienceCard = ({ data }) => {
  const { t } = useTranslation()
  const dispatch = useDispatch()

  const { loggedInUser, deleted, successforpatch, successforpost } =
    useSelector((state) => state.usersReducer)
  const [sendSidebarOpen, setSendSidebarOpen] = useState({
    open: false,
    data: {},
    formType: ""
  })

  useEffect(() => {
    if (successforpatch || successforpost || deleted) {
      setSendSidebarOpen({
        open: false,
        data: {},
        formType: ""
      })
      dispatch(userActions.resetAllStatus())
    }
  }, [successforpatch, successforpost, deleted])

  const toggleSendSidebar = () =>
    setSendSidebarOpen({
      open: !sendSidebarOpen.open,
      data: {},
      formType: ""
    })

  const handleConfirmDelete = (data) => {
    return MySwal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(
          userActions.deleteExperienceRequest({
            params: data._id
          })
        )
      }
    })
  }

  return (
    <Fragment>
      <Card>
        <CardBody>
          <div className="added-cards">
            {data.map((item, index) => {
              const isLastCard = index === data.length - 1
              return (
                <div
                  key={index}
                  className={classnames("cardMaster rounded border p-2", {
                    "mb-1": !isLastCard
                  })}
                >
                  <div className="d-flex justify-content-between flex-sm-row flex-column">
                    <div className="item-information d-flex flex-column">
                      <h5 className="mb-0 me-1 text-capitalize text-bold-500">
                        {item.jobTitle}
                      </h5>
                      <div className="d-flex align-items-center mt-50">
                        <h6 className="mb-0">
                          {t("Company")} : {item.company}
                        </h6>
                      </div>
                      <span className="number mt-50">
                        {t("Started from")} : {formatDateToShow(item.startDate)}{" "}
                        to{" "}
                        {item.isCurrentlyWorking
                          ? "Present"
                          : formatDateToShow(item.endDate)}
                      </span>
                    </div>

                    <div className="d-flex flex-column text-start text-lg-end">
                      {getProfileId() === loggedInUser.id && (
                        <div className="d-flex order-sm-0 order-1 mt-1 mt-sm-0">
                          <Button
                            outline
                            color="primary"
                            className="me-75"
                            size="sm"
                            onClick={() =>
                              setSendSidebarOpen({
                                open: true,
                                data: item,
                                formType: "edit"
                              })
                            }
                          >
                            {t("Edit")}
                          </Button>

                          <Button
                            size="sm"
                            outline
                            onClick={() => handleConfirmDelete(item)}
                          >
                            {t("Delete")}
                          </Button>
                        </div>
                      )}
                      <span className="mt-2"></span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {getProfileId() === loggedInUser.id && (
            <div className="demo-inline-spacing">
              <Button
                color="primary"
                onClick={() => {
                  setSendSidebarOpen({
                    open: true,
                    data: {},
                    formType: "add"
                  })
                }}
              >
                <Plus className="me-50" size={14} />
                {t("Add")}
              </Button>
            </div>
          )}
        </CardBody>
      </Card>

      <ExperienceForm
        toggleSidebar={toggleSendSidebar}
        open={sendSidebarOpen.open}
        formType={sendSidebarOpen.formType}
        data={sendSidebarOpen.data}
      />
    </Fragment>
  )
}
export default ExperienceCard
