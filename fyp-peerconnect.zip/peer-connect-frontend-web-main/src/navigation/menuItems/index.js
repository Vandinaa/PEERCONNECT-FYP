import {
  Book,
  Calendar,
  Codepen,
  Copy,
  DollarSign,
  Feather,
  FilePlus,
  FileText,
  Home,
  Link,
  Mail,
  MessageSquare,
  Package,
  Table,
  User,
  UserPlus,
  Users
} from "react-feather"

export const SideMenuItems = [
  {
    id: "home",
    title: "Home",
    icon: <Home size={20} />,
    navLink: "/home",
    role: ["user"]
  },
  {
    id: "manage-users",
    title: "Manage Users",
    icon: <User size={20} />,
    navLink: "/manage-users",
    role: ["admin"]
  },
  {
    id: "interests",
    title: "Interests",
    icon: <Feather size={20} />,
    navLink: "/interests",
    role: ["admin"]
  },
  {
    id: "courses",
    title: "Courses",
    icon: <Book size={20} />,
    navLink: "/courses",
    role: ["admin"]
  },
  {
    id: "groups",
    title: "Groups",
    icon: <Users size={20} />,
    navLink: "/groups",
    role: ["user"]
  },
  {
    id: "profile",
    title: "Profile",
    icon: <User size={20} />,
    navLink: "/profile",
    role: ["admin", "user"]
  }
]
