import { createActionTypes } from "@src/utility"

export const SECURITY_TYPES = createActionTypes("SECURITY", [
  "CHANGE_PASSWORD_REQUEST",
  "CHANGE_PASSWORD_SUCCESS",
  "CHANGE_PASSWORD_FAIL",
  "CLEAR_CHANGE_PASSWORD_RESPONSE"
])
