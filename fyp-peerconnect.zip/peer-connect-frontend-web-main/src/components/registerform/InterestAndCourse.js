import * as registerActions from "@src/store/common/register/actions"
import "react-slidedown/lib/slidedown.css"
import "@styles/react/libs/flatpickr/flatpickr.scss"
import { Fragment, useState } from "react"

import { useFormik } from "formik"
import Select from "react-select"

import * as Yup from "yup"

import { ArrowLeft } from "react-feather"

import "@styles/react/libs/react-select/_react-select.scss"
import { Label, Row, Col, Button, Form, Spinner } from "reactstrap"
import { selectThemeColors } from "@utils"
import makeAnimated from "react-select/animated"
import { useDispatch, useSelector } from "react-redux"
import { fieldExists } from "@src/utility/Utils"
import { useEffect } from "react"

const InterestAndCourse = ({ stepper, setData, setStep, data }) => {
  const animatedComponents = makeAnimated()
  const dispatch = useDispatch()

  const initialValues = {
    categories: [],
    interests: [],
    courses: []
  }

  const {
    loading
  } = useSelector((state) => state.registerReducer)

  const validationSchema = Yup.object().shape({
    categories: Yup.array()
      .min(1, "At least one category is required")
      .max(3, "At max 3 categories are allowed")
  })

  const {
    values,
    errors,
    handleSubmit,
    handleBlur,
    setFieldValue,
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      const body = {
        email: data.email,
        password: data.password,
        personalInfo: {
          fullName: data.full_name,
          gender: data.gender,
          dateOfBirth: data.date_of_birth
            ? data.date_of_birth[0].toISOString().split("T")[0]
            : null,
          phone: data.contact_number.toString(),
        },
        education: data.education.map((edu) => ({
          schoolName: edu.schoolName,
          degree: edu.degree,
          fieldOfStudy: edu.fieldOfStudy,
          startDate: edu.startDate
            ? edu.startDate[0].toISOString().split("T")[0]
            : null,
          endDate: edu.endDate
            ? edu.endDate[0].toISOString().split("T")[0]
            : null,
          isCurrentlyStudying: edu.isCurrentlyStudying,
          grade: edu.grade,
          gradeSystem: edu.gradeSystem
        })),
        experience: data.experience.map((exp) => ({
          jobTitle: exp.jobTitle,
          company: exp.company,
          startDate: exp.startDate
            ? exp.startDate[0].toISOString().split("T")[0]
            : null,
          endDate: exp.endDate
            ? exp.endDate[0].toISOString().split("T")[0]
            : null,
          isCurrentlyWorking: exp.isCurrentlyWorking
        })),
        interests: values.interests.map((item) => item.value),
        courses: values.courses.map((item) => item.value)
      }
      dispatch(registerActions.registerRequest(body))
      setIsSubmit(false)
    }
  })

  const [isSubmit, setIsSubmit] = useState(false)

  const { interests } = useSelector((state) => state.interestReducer)
  const { courses } = useSelector((state) => state.courseReducer)

  const [interestsOptions, setInterestsOptions] = useState([])
  const [coursesOptions, setCoursesOptions] = useState([])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          value: item.id,
          label: item.courseName + " - " + item.courseCode
        }
      })
      setCoursesOptions(a)
    }
  }, [courses])

  const filterInterests = (categories) => {
    if (fieldExists(interests, "results") && interests.results.length > 0) {
      const a = interests.results.filter((item, index) => {
        return categories.some((el) => el.value === item.category)
      })
      const b = a.map((item, index) => {
        return {
          value: item.id,
          label: item.interestName
        }
      })
      setInterestsOptions(b)
      // remove interests from values if not in the new interestsOptions
      const c = values.interests.filter((item, index) => {
        return b.some((el) => el.value === item.value)
      })
      setFieldValue("interests", c)
    } else {
      setInterestsOptions([])
      setFieldValue("interests", [])
    }
  }
  const [categoriesOptions, setCategoriesOptions] = useState([
    { value: "web_development", label: "Web Development" },
    { value: "mobile_development", label: "Mobile Development" },
    { value: "game_development", label: "Game Development" },
    { value: "data_science", label: "Data Science" },
    { value: "machine_learning", label: "Machine Learning" },
    { value: "artificial_intelligence", label: "Artificial Intelligence" },
    { value: "cloud_computing", label: "Cloud Computing" },
    { value: "devops", label: "DevOps" },
    { value: "cyber_security", label: "Cyber Security" },
    { value: "digital_marketing", label: "Digital Marketing" },
    { value: "business", label: "Business" },
    {
      value: "data_structures_and_algorithms",
      label: "Data Structures And Algorithms"
    },
    { value: "software_testing", label: "Software Testing" },
    { value: "databases", label: "Databases" },
    { value: "operating_systems", label: "Operating Systems" },
    { value: "computer_vision", label: "Computer Vision" },
    { value: "other", label: "Other" }
  ])


  return (
    <Fragment>
      <div className="content-header">
        <h5 className="mb-0">Interests and Courses</h5>
        <small>Enter Your Interests And Courses</small>
      </div>
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setIsSubmit(true)
          handleSubmit()
        }}
      >
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="categories">
              Categories* (At max 3)
            </Label>
            <Select
              id="categories"
              theme={selectThemeColors}
              className="react-select"
              classNamePrefix="select"
              options={categoriesOptions}
              isClearable={false}
              components={animatedComponents}
              closeMenuOnSelect={true}
              isMulti
              name="categories"
              value={values.categories}
              onChange={(value) => {
                setFieldValue("categories", value)
                filterInterests(value)
              }}
              onBlur={handleBlur}
            />
            {isSubmit && errors.categories && (
              <div className="text-danger text-small mt-50">
                {errors.categories}
              </div>
            )}
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="interests">
              Interests
            </Label>
            <Select
              id="interests"
              theme={selectThemeColors}
              className="react-select"
              classNamePrefix="select"
              options={interestsOptions}
              isClearable={false}
              components={animatedComponents}
              closeMenuOnSelect={true}
              isMulti
              name="interests"
              value={values.interests}
              onChange={(value) => {
                setFieldValue("interests", value)
              }}
              onBlur={handleBlur}
              isDisabled={values.categories.length === 0}
              // disabled={values.categories.length === 0}
            />
            {isSubmit && errors.interests && (
              <div className="text-danger text-small mt-50">
                {errors.interests}
              </div>
            )}
          </Col>
        </Row>

        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="courses">
              Courses
            </Label>
            <Select
              id="courses"
              theme={selectThemeColors}
              className="react-select"
              classNamePrefix="select"
              options={coursesOptions}
              isClearable={false}
              components={animatedComponents}
              closeMenuOnSelect={true}
              isMulti
              name="courses"
              value={values.courses}
              onChange={(value) => {
                setFieldValue("courses", value)
              }}
              onBlur={handleBlur}
            />
            {isSubmit && errors.courses && (
              <div className="text-danger text-small mt-50">
                {errors.courses}
              </div>
            )}
          </Col>
        </Row>

        <div className="d-flex justify-content-between">
          <Button
            color="primary"
            className="btn-prev"
            onClick={() => stepper.previous()}
          >
            <ArrowLeft
              size={14}
              className="align-middle me-sm-25 me-0"
            ></ArrowLeft>
            <span className="align-middle d-sm-inline-block d-none"
            disabled={loading}
            >
              Previous
            </span>
          </Button>
          <Button type="submit" color="success" className="btn-submit"
          disabled={loading}
          >
          {loading ? (
              <Spinner className="me-1" size="sm" />
            ) : null}
            Register
          </Button>
        </div>
      </Form>
    </Fragment>
  )
}
export default InterestAndCourse
