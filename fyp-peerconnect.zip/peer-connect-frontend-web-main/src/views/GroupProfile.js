import * as Yup from "yup"
import { useFormik } from "formik"

import { getAllCoursesRequest } from "@src/store/common/courses/actions"
import * as userActions from "@src/store/common/users/actions"
import * as groupActions from "@src/store/common/groupManagement/actions"

import { selectThemeColors } from "@utils"

import toast from "react-hot-toast"

import makeAnimated from "react-select/animated"

import Select from "react-select"
import { fieldExists, isNullObject, isObjEmpty } from "@src/utility/Utils"
import socketIOClient from "socket.io-client"

import { Bookmark, MessageSquare, User } from "react-feather"
import {
  Card,
  CardBody,
  Col,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
  Label,
  Input,
  Modal,
  Button,
  ModalBody,
  ModalHeader,
  Spinner
} from "reactstrap"

import { Fragment, useEffect, useState } from "react"
import { getInitials, getProfileId } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import Avatar from "@src/@core/components/avatar"
import { useTranslation } from "react-i18next"
import { useNavigate } from "react-router-dom"
import MembersTable from "@src/components/groupCards/MembersTable"
import CoursesCard from "@src/components/groupCards/CoursesCard"

const alternateImage =
  require("@src/assets/images/avatars/avatar-blank.png").default

const GroupProfile = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [sendSidebarOpen, setSendSidebarOpen] = useState(false)
  const [GroupId, setGroupId] = useState(
    new URLSearchParams(window.location.search).get("id")
  )

  const [coursesOptions, setCoursesOptions] = useState([])
  const [membersOptions, setMembersOptions] = useState([])
  const [selectedGroup, setSelectedGroup] = useState({})

  const dispatch = useDispatch()

  const [show, setShow] = useState(false)
  const [modalType, setModalType] = useState("Add New")

  const animatedComponents = makeAnimated()
    
  const [socket] = useState(socketIOClient(process.env.REACT_APP_SOCKET_URL))

  const { courses } = useSelector((state) => state.courseReducer)
  const { users } = useSelector((state) => state.usersReducer)
  const { updated, creationLoading } = useSelector(
    (state) => state.groupManagementReducer
  )

  useEffect(() => {
    if (isObjEmpty(!isNullObject(users))) {
      dispatch(
        userActions.getAllUsersRequest({
          perPage: 1000,
          page: 1
        })
      )
    }
    if (isObjEmpty(!isNullObject(courses))) {
      dispatch(
        getAllCoursesRequest({
          perPage: 1000,
          page: 1
        })
      )
    }
  }, [dispatch])

  useEffect(() => {
    if (updated) {
      if (updated) {
        toast.success("Group updated successfully")
      }
      setShow(false)
      setIsSubmit(false)
      resetForm()
      dispatch(groupActions.resetStatus())
      dispatch(
        groupActions.getMyGroupsRequest({
          perPage: 6,
          page: 1
        })
      )
    }
  }, [updated])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          value: item.id,
          label: item.courseName + " - " + item.courseCode
        }
      })
      setCoursesOptions(a)
    } else {
      setCoursesOptions([])
    }
  }, [courses])

  useEffect(() => {
    if (fieldExists(users, "results") && users.results.length > 0) {
      const a = users.results.map((item, index) => {
        return {
          value: item.id,
          label: item?.personalInfo?.fullName + " - " + item.email
        }
      })
      setMembersOptions(a)
    } else {
      setMembersOptions([])
    }
  }, [users])

  const initialValues = {
    groupName: "",
    courses: [],
    members: []
  }

  const validationSchema = Yup.object().shape({
    groupName: Yup.string().required("Required"),
    courses: Yup.array().min(1, "At least 1 course required"),
    members: Yup.array().min(2, "At least 2 members required")
  })
  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues,
    resetForm
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      if (modalType === "Edit") {
        dispatch(
          groupActions.editGroupRequest({
            groupId: selectedGroup.id,
            body: {
              groupName: values.groupName,
              courses: values.courses.map((item) => item.value),
              members: values.members.map((item) => item.value)
            }
          })
        )
      }
    }
  })

  const [isSubmit, setIsSubmit] = useState(false)

  const onReset = () => {
    setShow(false)
    setIsSubmit(false)
    resetForm()
  }

  const handleModalClosed = () => {
    setModalType("Add New")
    onReset()
  }

  const { groupDetails } = useSelector((state) => state.groupManagementReducer)

  useEffect(() => {
    if (GroupId) {
      dispatch(groupActions.getGroupDetailsRequest(GroupId))
    }
  }, [GroupId])

  const [active, setActive] = useState("1")

  const toggleTab = (tab) => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  useEffect(() => {
    if (modalType === "Edit") {
      setFieldValue("groupName", selectedGroup.groupName)
      setFieldValue(
        "courses",
        selectedGroup.courses.map((item) => {
          return {
            value: item.id,
            label: item.courseName + " - " + item.courseCode
          }
        })
      )
      setFieldValue(
        "members",
        selectedGroup.members.map((item) => {
          return {
            value: item.id,
            label: item?.personalInfo?.fullName + " - " + item.email
          }
        })
      )
    } else {
      setFieldValue("groupName", "")
      setFieldValue("courses", [])
      setFieldValue("members", [])
    }
  }, [selectedGroup, show])

  return (
    <Fragment>
      <Row>
        <Col lg="4" md="4">
          <Card title="Group Detail" actions="collapse">
            <div id="user-profile">
              <Row>
                <Col sm="12">
                  <Card className="profile-header mb-0">
                    <div className="profile-img-container d-flex align-items-center pt-5 justify-content-center text-capitalize">
                      {groupDetails?.profile_image &&
                      groupDetails?.profile_image?.url !== "" ? (
                        <div className="d-flex justify-content-center align-items-center">
                          <div className="position-relative">
                            <img
                              target="_blank"
                              alt="GroupProfile Image Preview"
                              className="rounded me-50"
                              src={
                                groupDetails?.personalInfo?.profile_image
                                  ?.url || alternateImage
                              }
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null // prevents looping
                                currentTarget.src = alternateImage
                              }}
                              height="100"
                              width="100"
                              style={{
                                objectFit: "cover",
                                objectPosition: "center",
                                borderRadius: "50%"
                              }}
                            />
                          </div>
                        </div>
                      ) : (
                        <Avatar
                          color="light-primary"
                          size="xl"
                          content={getInitials(groupDetails?.groupName)}
                          initials
                        />
                      )}
                    </div>
                  </Card>
                </Col>
              </Row>
            </div>
            <CardBody className="pt-2 ">
              <div style={{ textAlign: "center" }}>
                <h5 className="text-capitalize">{groupDetails?.groupName}</h5>
              </div>
              <h4 className="fw-bolder border-bottom pb-50 mb-1 pt-2">
                {t("Group Details")}
              </h4>
              <div className="info-container">
                <ul className="list-unstyled">
                  <li className="mb-75">
                    <span className="fw-bolder me-25">
                      {t("Creator Name")} :{" "}
                    </span>
                    <span>{groupDetails?.creator?.personalInfo?.fullName}</span>
                  </li>
                  <li className="mb-75">
                    <span className="fw-bolder me-25">
                      {t("Creator Email")} :{" "}
                    </span>
                    <span>{groupDetails?.creator?.email}</span>
                  </li>
                </ul>
              </div>
              <div className="d-flex justify-content-center pt-2">
                {getProfileId() === groupDetails?.creator?.id && (
                  <Button
                    color="primary"
                    className="me-1"
                    onClick={(e) => {
                      e.preventDefault()
                      setSelectedGroup(groupDetails)
                      setModalType("Edit")
                      setShow(true)
                    }}
                  >
                    {t("Edit")}
                  </Button>
                )}
                {groupDetails?.members?.findIndex(
                  (item) => item.id === getProfileId()
                ) !== -1 || groupDetails?.creator?.id === getProfileId() ? (
                  <Button
                    color="primary"
                    onClick={() => {
                      navigate(
                        `/group-chat?id=${groupDetails?.id}`
                      )
                    }}
                  >
                    <MessageSquare size={15} className="me-50" />
                    {t("Chat")}
                  </Button>
                ) : groupDetails?.joinRequests?.findIndex(
                    (item) => item.id === getProfileId()
                  ) !== -1 ? (
                  <Button
                    color="primary"
                    onClick={() => {
                      navigate(
                        `/app/group-chat?id=${groupDetails?.id}&name=${groupDetails?.groupName}`
                      )
                    }}
                  >
                    <MessageSquare size={15} className="me-50" />
                    {t("Pending Request")}
                  </Button>
                ) : (
                  <Button
                    color="primary"
                    onClick={() => {
                      socket.emit("joinRequest", {
                                  user: getUserData(),
                                  groupId: groupDetails?.id,
                                  groupName : groupDetails?.groupName,
                                  creator : groupDetails?.creator.id
                                })

                      dispatch(
                        groupActions.joinGroupRequest({
                          groupId: groupDetails?.id
                        })
                      )
                    }}
                  >
                    {t("Join")}
                  </Button>
                )}
              </div>
            </CardBody>
          </Card>
        </Col>

        <Col md="8" sm="12" lg="8">
          <Nav pills className="mb-2" style={{ width: "100%" }}>
            <NavItem>
              <NavLink active={active === "1"} onClick={() => toggleTab("1")}>
                <User className="font-medium-3 me-50" />
                <span className="fw-bold">{t("Members")}</span>
              </NavLink>
            </NavItem>

            <NavItem>
              <NavLink active={active === "3"} onClick={() => toggleTab("3")}>
                <Bookmark className="font-medium-3 me-50" />
                <span className="fw-bold">{t("Courses")}</span>
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={active}>
            <TabPane tabId="1">
              <MembersTable
                members={groupDetails?.members ? groupDetails?.members : []}
                groupId={groupDetails?.id}
              />
            </TabPane>

            <TabPane tabId="3">
              <CoursesCard
                courses={groupDetails?.courses ? groupDetails?.courses : []}
              />
            </TabPane>
          </TabContent>
        </Col>
      </Row>
      <Modal
        isOpen={show}
        onClosed={handleModalClosed}
        toggle={() => setShow(!show)}
        className="modal-dialog-centered modal-lg"
      >
        <ModalHeader
          className="bg-transparent"
          toggle={() => setShow(!show)}
        ></ModalHeader>
        <ModalBody className="px-5 pb-5">
          <div className="text-center mb-4">
            <h1>{modalType} Group</h1>
            <p>Fill out the details</p>
          </div>
          <Row
            tag="form"
            onSubmit={(e) => {
              e.preventDefault()
              setIsSubmit(true)
              handleSubmit()
            }}
          >
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="groupName">
                Group Name
              </Label>
              <Input
                type="text"
                id="groupName"
                name="groupName"
                placeholder="Enter group name"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.groupName}
              />
              {isSubmit && errors.groupName && touched.groupName ? (
                <div className="error-message text-danger">
                  {errors.groupName}
                </div>
              ) : null}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="courses">
                Courses
              </Label>
              <Select
                id="courses"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={coursesOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="courses"
                value={values.courses}
                onChange={(value) => {
                  setFieldValue("courses", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.courses && (
                <div className="text-danger text-small mt-50">
                  {errors.courses}
                </div>
              )}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="members">
                Members
              </Label>

              <Select
                id="members"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={membersOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="members"
                value={values.members}
                onChange={(value) => {
                  setFieldValue("members", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.members && (
                <div className="text-danger text-small mt-50">
                  {errors.members}
                </div>
              )}
            </Col>

            <Col className="text-center mt-2" xs={12}>
              <Button
                type="submit"
                color="primary"
                className="me-1"
                disabled={creationLoading}
              >
                {creationLoading ? (
                  <Spinner className="me-1" size="sm" />
                ) : null}
                Submit
              </Button>
              <Button
                type="reset"
                outline
                onClick={onReset}
                disabled={creationLoading}
              >
                Discard
              </Button>
            </Col>
          </Row>
        </ModalBody>
      </Modal>
    </Fragment>
  )
}

export default GroupProfile
