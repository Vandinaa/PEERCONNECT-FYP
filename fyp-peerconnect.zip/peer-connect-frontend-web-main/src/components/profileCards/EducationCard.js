import * as userActions from "@src/store/common/users/actions"

import { Button, Card, CardBody } from "reactstrap"
import { Fragment, useEffect, useState } from "react"
import { formatDateToShow, getProfileId } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import EducationForm from "../profileForms/EducationForm"
import { Plus } from "react-feather"
import Swal from "sweetalert2"
import classnames from "classnames"
import withReactContent from "sweetalert2-react-content"
import { useTranslation } from "react-i18next"

const MySwal = withReactContent(Swal)

const EducationCard = ({ data }) => {
  const { t } = useTranslation()
  const dispatch = useDispatch()
  const { loggedInUser, deleted, successforpatch, successforpost } =
    useSelector((state) => state.usersReducer)

  const [sendSidebarOpen, setSendSidebarOpen] = useState({
    open: false,
    data: {},
    formType: ""
  })
  useEffect(() => {
    if (successforpatch || successforpost || deleted) {
      // for rerendering
      setSendSidebarOpen({
        open: false,
        data: {},
        formType: ""
      })
      dispatch(userActions.getLoggedInUserRequest(getProfileId()))

      dispatch(userActions.resetAllStatus())
    }
  }, [successforpatch, successforpost, deleted])

  const toggleSendSidebar = () =>
    setSendSidebarOpen({
      open: !sendSidebarOpen.open,
      data: {},
      formType: ""
    })

  const handleConfirmDelete = (data) => {
    return MySwal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(userActions.deleteEducationRequest(data._id))
      }
    })
  }

  return (
    <Fragment>
      <Card>
        <CardBody>
          {data.length > 0 ? (
            <div className="added-cards">
              {data.map((item, index) => {
                const isLastCard = index === data.length - 1
                return (
                  <div
                    key={index}
                    className={classnames("cardMaster rounded border p-2", {
                      "mb-1": !isLastCard
                    })}
                  >
                    <div className="d-flex justify-content-between flex-sm-row flex-column">
                      <div className="item-information d-flex flex-column">
                        <div className="d-flex align-items-center mb-50">
                          <h6 className="mb-0">
                            {t("Degree")} : {item.degree} in {item.fieldOfStudy}
                          </h6>
                        </div>
                        <span className="item-number">
                          {t("Institute")} : {item.schoolName}
                        </span>
                        <span className="number mt-50">
                          {t("Started from")} :{" "}
                          {formatDateToShow(item.startDate)} to{" "}
                          {item.isCurrentlyStudying
                            ? "Present"
                            : formatDateToShow(item.endDate)}
                        </span>
                        <span className="number mt-50 text-medium">
                          {t("Grade or Percentage")} : {item.grade}-{" "}
                          {item.gradeSystem}
                        </span>
                      </div>

                      <div className="d-flex flex-column text-start text-lg-end">
                        {getProfileId() === loggedInUser.id && (
                          <div className="d-flex order-sm-0 order-1 mt-1 mt-sm-0">
                            <Button
                              outline
                              color="primary"
                              className="me-75"
                              size="sm"
                              onClick={() =>
                                setSendSidebarOpen({
                                  open: true,
                                  data: item,
                                  formType: "edit"
                                })
                              }
                            >
                              {t("Edit")}
                            </Button>

                            <Button
                              size="sm"
                              outline
                              onClick={() => handleConfirmDelete(item)}
                            >
                              {t("Delete")}
                            </Button>
                          </div>
                        )}
                        <span className="mt-2"></span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center mt-2">
              <h4>{t("No Education Added")}</h4>
            </div>
          )}

          {getProfileId() === loggedInUser.id && (
            <div className="demo-inline-spacing">
              <Button
                color="primary"
                onClick={() => {
                  setSendSidebarOpen({
                    open: true,
                    data: {},
                    formType: "add"
                  })
                }}
              >
                <Plus className="me-50" size={14} />
                {t("Add")}
              </Button>
            </div>
          )}
        </CardBody>
      </Card>
      <EducationForm
        toggleSidebar={toggleSendSidebar}
        open={sendSidebarOpen.open}
        formType={sendSidebarOpen.formType}
        data={sendSidebarOpen.data}
      />
    </Fragment>
  )
}
export default EducationCard
