import * as groupActions from "@src/store/common/groupManagement/actions"

import { Fragment, useState, useEffect } from "react"

import { useDispatch, useSelector } from "react-redux"
import { getUserRole, isObjEmpty } from "@src/utility/Utils"

import * as searchActions from "@src/store/common/search/actions"

import { useNavigate } from "react-router-dom"
import { Button, Spinner } from "reactstrap"

import GroupCard from "@src/components/GroupCard"
import UserCard from "@src/components/UserCard"
import toast from "react-hot-toast"
import { ChevronLeft } from "react-feather"

function SearchList() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { requestSend } = useSelector((state) => state.groupManagementReducer)

  const { listOfSearch, searching } = useSelector(
    (state) => state.searchReducer
  )

  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const searchQuery = urlParams.get("q")
    if (searchQuery) {
      setSearchQuery(searchQuery)
      if (isObjEmpty(listOfSearch)) {
        dispatch(searchActions.getListOfSearchRequest(searchQuery))
      }
    }
  }, [dispatch])

  useEffect(() => {
    if (requestSend) {
      toast.success("Request sent successfully")
      dispatch(groupActions.resetStatus())
      dispatch(searchActions.getListOfSearchRequest(searchQuery))
    }
  }, [requestSend])

  return (
    <Fragment>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center ">
        <div>
          <h4>
            <ChevronLeft
              size={18}
              className="cursor-pointer me-50 text-primary"
              onClick={() => {
                if (getUserRole() === "admin") {
                  navigate("/manage-users")
                } else {
                  navigate("/home")
                }
              }}
            />
            Search Users
          </h4>
          <p className="mb-2">
            Search results for <b>{searchQuery}</b>
          </p>
        </div>
      </div>
      {searching ? (
        <div className="text-center">
          <Spinner color="primary" className="mb-1" />
        </div>
      ) : (
        <>
          <UserCard
            users={
              listOfSearch?.usersResult?.results?.length > 0
                ? listOfSearch?.usersResult
                : []
            }
          />
          {listOfSearch?.usersResult?.totalPages >
          listOfSearch?.usersResult?.page ? (
            <div className="d-flex justify-content-end flex-wrap">
              <Button
                color="primary"
                className="text-nowrap mb-1"
                size="sm"
                onClick={() => {
                  dispatch(
                    searchActions.getListOfSearchRequest(searchQuery, {
                      perPage: listOfSearch?.usersResult?.limit + 6,
                      page: 1
                    })
                  )
                }}
              >
                View More
              </Button>
            </div>
          ) : null}
        </>
      )}

      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center ">
        <div>
          <h4>Search Groups</h4>
          <p className="mb-2">
            Groups related to your search <b>{searchQuery}</b>
          </p>
        </div>
      </div>
      {searching ? (
        <div className="text-center">
          <Spinner color="primary" className="mb-1" />
        </div>
      ) : listOfSearch?.groupsResult?.results?.length > 0 ? (
        <>
          <GroupCard groups={listOfSearch?.groupsResult} type="other" />
          {listOfSearch?.groupsResult?.totalPages >
          listOfSearch?.groupsResult?.page ? (
            <div className="d-flex justify-content-end flex-wrap">
              <Button
                color="primary"
                className="text-nowrap mb-1"
                size="sm"
                onClick={() => {
                  dispatch(
                    groupActions.getOtherGroupsRequest({
                      perPage: listOfSearch?.groupsResult?.limit + 6,
                      page: 1
                    })
                  )
                }}
              >
                View More
              </Button>
            </div>
          ) : null}
        </>
      ) : (
        <div className="text-center">
          <h3>No Groups Found</h3>
        </div>
      )}
    </Fragment>
  )
}

export default SearchList
