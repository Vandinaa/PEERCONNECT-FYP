import { all, call, put, takeEvery } from "redux-saga/effects"
import * as groupManagementActions from "./actions"
import { GROUP_MANAGEMENT_TYPES } from "./types"
import {
  createGroup,
  getCreatedGroups,
  getMyGroups,
  getOtherGroups,
  joinGroup,
  takeAction,
  editGroup,
  getJoinRequests,
  getGroupDetails
  ,
  removeMember, leaveGroup
} from "@src/services/apis"
import toast from "react-hot-toast"

function* createGroupSaga(action) {
  try {
    const response = yield call(createGroup, action.payload)
    if (
      response?.response?.data?.code === 400 &&
      response?.response?.data?.message === "Name already taken"
    ) {
      toast.error("Group already exists with this name")
      yield put(groupManagementActions.createGroupFailure(err))
    } else if (response?.status === 201) {
      yield put(groupManagementActions.createGroupSuccess(response))
    }
  } catch (err) {
    yield put(groupManagementActions.createGroupFailure(err))
  }
}

function* getCreatedGroupsSaga(action) {
  try {
    const response = yield call(getCreatedGroups, action.payload)
    yield put(groupManagementActions.getCreatedGroupsSuccess(response.data))
  } catch (err) {
    yield put(groupManagementActions.getCreatedGroupsFailure(err))
  }
}

function* getMyGroupsSaga(action) {
  try {
    const response = yield call(getMyGroups, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.getMyGroupsSuccess(response.data))
    } else {
      yield put(groupManagementActions.getMyGroupsFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.getMyGroupsFailure(err))
  }
}

function* getOtherGroupsSaga(action) {
  try {
    const response = yield call(getOtherGroups, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.getOtherGroupsSuccess(response.data))
    } else {
      yield put(groupManagementActions.getOtherGroupsFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.getOtherGroupsFailure(err))
  }
}

function* joinGroupSaga(action) {
  try {
    const response = yield call(joinGroup, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.joinGroupSuccess(response.data))
    }
else     {
      yield put(groupManagementActions.joinGroupFailure(response))
    }

  } catch (err) {
    yield put(groupManagementActions.joinGroupFailure(err))
  }
}

function* takeActionSaga(action) {
  try {

    const response = yield call(takeAction, action.payload)
    console.log("response", response)
    yield put(groupManagementActions.takeActionSuccess(response.data))
  } catch (err) {
    yield put(groupManagementActions.takeActionFailure(err))
  }
}

// function* addMembersSaga(action) {
//   try {
//     const response = yield call(addMembers, action.payload)
//     yield put(groupManagementActions.addMembersSuccess(response.data))
//   } catch (err) {
//     yield put(groupManagementActions.addMembersFailure(err))
//   }
// }

// function* addCoursesSaga(action) {
//   try {
//     const response = yield call(addCourses, action.payload)
//     yield put(groupManagementActions.addCoursesSuccess(response.data))
//   } catch (err) {
//     yield put(groupManagementActions.addCoursesFailure(err))
//   }
// }

function* editGroupSaga(action) {
  try {
    const response = yield call(editGroup, action.payload)
    if (
      response?.response?.data?.code === 400 &&
      response?.response?.data?.message === "Name already taken"
    ) {
      toast.error("Group already exists with this name")
      yield put(groupManagementActions.editGroupFailure(err))
    } else if (response?.status === 200) {
      yield put(groupManagementActions.editGroupSuccess(response))
    }
  } catch (err) {
    yield put(groupManagementActions.editGroupFailure(err))
  }
}

function* getJoinRequestsSaga(action) {
  try {
    const response = yield call(getJoinRequests, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.getJoinRequestsSuccess(response.data))
    } else {
      yield put(groupManagementActions.getJoinRequestsFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.getJoinRequestsFailure(err))
  }
}

function* getGroupDetailsSaga(action) {
  try {
    const response = yield call(getGroupDetails, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.getGroupDetailsSuccess(response.data))
    } else {
      yield put(groupManagementActions.getGroupDetailsFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.getGroupDetailsFailure(err))
  }
}

function* removeMemberSaga(action) {
  try {
    const response = yield call(removeMember, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.removeMemberSuccess(response.data))
      yield put(groupManagementActions.getGroupDetailsRequest(action.payload.groupId))
    } else {
      yield put(groupManagementActions.removeMemberFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.removeMemberFailure(err))
  }
}

function* leaveGroupSaga(action) {
  try {
    const response = yield call(leaveGroup, action.payload)
    if (response.status === 200) {
      yield put(groupManagementActions.leaveGroupSuccess(response.data))
      yield put(groupManagementActions.getMyGroupsRequest({ perPage: 6, page: 1 }))
    } else {
      yield put(groupManagementActions.leaveGroupFailure(response))
    }
  } catch (err) {
    yield put(groupManagementActions.leaveGroupFailure(err))
  }
}



export default function* groupManagementSaga() {
  yield all([
    takeEvery(GROUP_MANAGEMENT_TYPES.CREATE_GROUP_REQUEST, createGroupSaga),
    takeEvery(
      GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_REQUEST,
      getCreatedGroupsSaga
    ),
    takeEvery(GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_REQUEST, getMyGroupsSaga),
    takeEvery(
      GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_REQUEST,
      getOtherGroupsSaga
    ),
    takeEvery(GROUP_MANAGEMENT_TYPES.JOIN_GROUP_REQUEST, joinGroupSaga),
    takeEvery(GROUP_MANAGEMENT_TYPES.TAKE_ACTION_REQUEST, takeActionSaga),
    // takeEvery(GROUP_MANAGEMENT_TYPES.ADD_MEMBERS_REQUEST, addMembersSaga),
    // takeEvery(GROUP_MANAGEMENT_TYPES.ADD_COURSES_REQUEST, addCoursesSaga),
    takeEvery(GROUP_MANAGEMENT_TYPES.EDIT_GROUP_REQUEST, editGroupSaga),
    takeEvery(
      GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_REQUEST,
      getJoinRequestsSaga
    ),
    takeEvery(
      GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_REQUEST,
      getGroupDetailsSaga
    ),
    takeEvery(GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_REQUEST, removeMemberSaga),
    takeEvery(GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_REQUEST, leaveGroupSaga),
  ])
}
