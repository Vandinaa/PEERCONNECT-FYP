import { GROUP_MANAGEMENT_TYPES } from "./types"

export const createGroupRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.CREATE_GROUP_REQUEST,
  payload: data
})

export const createGroupSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.CREATE_GROUP_SUCCESS,
  payload: data
})

export const createGroupFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.CREATE_GROUP_FAIL,
  payload: data
})

export const getCreatedGroupsRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_REQUEST,
  payload: data
})

export const getCreatedGroupsSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_SUCCESS,
  payload: data
})

export const getCreatedGroupsFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_CREATED_GROUPS_FAIL,
  payload: data
})

export const getMyGroupsRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_REQUEST,
  payload: data
})

export const getMyGroupsSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_SUCCESS,
  payload: data
})

export const getMyGroupsFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_MY_GROUPS_FAIL,
  payload: data
})

export const getOtherGroupsRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_REQUEST,
  payload: data
})

export const getOtherGroupsSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_SUCCESS,
  payload: data
})

export const getOtherGroupsFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_OTHER_GROUPS_FAIL,
  payload: data
})

export const joinGroupRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.JOIN_GROUP_REQUEST,
  payload: data
})

export const joinGroupSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.JOIN_GROUP_SUCCESS,
  payload: data
})

export const joinGroupFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.JOIN_GROUP_FAIL,
  payload: data
})

export const takeActionRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.TAKE_ACTION_REQUEST,
  payload: data
})

export const takeActionSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.TAKE_ACTION_SUCCESS,
  payload: data
})

export const takeActionFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.TAKE_ACTION_FAIL,
  payload: data
})

export const addMembersRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_MEMBERS_REQUEST,
  payload: data
})

export const addMembersSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_MEMBERS_SUCCESS,
  payload: data
})

export const addMembersFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_MEMBERS_FAIL,
  payload: data
})

export const addCoursesRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_COURSES_REQUEST,
  payload: data
})

export const addCoursesSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_COURSES_SUCCESS,
  payload: data
})

export const addCoursesFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.ADD_COURSES_FAIL,
  payload: data
})

export const editGroupRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.EDIT_GROUP_REQUEST,
  payload: data
})

export const editGroupSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.EDIT_GROUP_SUCCESS,
  payload: data
})

export const editGroupFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.EDIT_GROUP_FAIL,
  payload: data
})

export const resetStatus = (data) => ({ 
  type: GROUP_MANAGEMENT_TYPES.RESET_STATUS,
  payload: data
})

export const getJoinRequestsRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_REQUEST,
  payload: data
})

export const getJoinRequestsSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_SUCCESS,
  payload: data
})

export const getJoinRequestsFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_JOIN_REQUESTS_FAIL,
  payload: data
})

export const getGroupDetailsRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_REQUEST,
  payload: data
})

export const getGroupDetailsSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_SUCCESS,
  payload: data
})

export const getGroupDetailsFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.GET_GROUP_DETAILS_FAIL,
  payload: data
})

export const removeMemberRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_REQUEST,
  payload: data
})

export const removeMemberSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_SUCCESS,
  payload: data
})

export const removeMemberFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.REMOVE_MEMBER_FAIL,
  payload: data
})

export const leaveGroupRequest = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_REQUEST,
  payload: data
})

export const leaveGroupSuccess = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_SUCCESS,
  payload: data
})

export const leaveGroupFailure = (data) => ({
  type: GROUP_MANAGEMENT_TYPES.LEAVE_GROUP_FAIL,
  payload: data
})