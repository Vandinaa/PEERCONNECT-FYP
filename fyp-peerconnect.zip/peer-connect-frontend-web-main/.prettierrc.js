module.exports = {
  semi: false,
  trailingComma: "none"
}
