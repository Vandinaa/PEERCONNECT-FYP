import { getAllCoursesRequest } from "@src/store/common/courses/actions"
import * as userActions from "@src/store/common/users/actions"
import * as groupActions from "@src/store/common/groupManagement/actions"

import { Fragment, useState, useEffect } from "react"
import Select from "react-select"

import * as Yup from "yup"

import { useFormik } from "formik"

import { useDispatch, useSelector } from "react-redux"

import { selectThemeColors } from "@utils"
import { fieldExists, isNullObject, isObjEmpty } from "@src/utility/Utils"

import makeAnimated from "react-select/animated"

import {
  Row,
  Col,
  Label,
  Input,
  Modal,
  Button,
  ModalBody,
  ModalHeader,
  Spinner
} from "reactstrap"

import GroupCard from "@src/components/GroupCard"
import toast from "react-hot-toast"

function Groups() {
  const [show, setShow] = useState(false)
  const [modalType, setModalType] = useState("Add New")

  const animatedComponents = makeAnimated()

  const dispatch = useDispatch()

  const { courses } = useSelector((state) => state.courseReducer)
  const { users } = useSelector((state) => state.usersReducer)
  const {
    myGroups,
    created,
    fetchingGroups,
    updated,
    requestSend,
    creationLoading,
    otherGroups
  } = useSelector((state) => state.groupManagementReducer)

  const [coursesOptions, setCoursesOptions] = useState([])
  const [membersOptions, setMembersOptions] = useState([])

  useEffect(() => {
      dispatch(
        userActions.getAllUsersRequest({
          perPage: 1000,
          page: 1
        })
      )
      dispatch(
        getAllCoursesRequest({
          perPage: 1000,
          page: 1
        })
      )
      dispatch(
        groupActions.getMyGroupsRequest({
          perPage: 6,
          page: 1
        })
      )
 
      dispatch(
        groupActions.getOtherGroupsRequest({
          perPage: 6,
          page: 1
        })
      )
  }, [dispatch])

  useEffect(() => {
    if (created || updated) {
      if (updated) {
        toast.success("Group updated successfully")
      } else {
        toast.success("Group created successfully")
      }
      setShow(false)
      setIsSubmit(false)
      resetForm()
      dispatch(groupActions.resetStatus())
      dispatch(
        groupActions.getMyGroupsRequest({
          perPage: 6,
          page: 1
        })
      )
    }
  }, [created, updated])

  useEffect(() => {
    if (requestSend) {
      toast.success("Request sent successfully")
      dispatch(groupActions.resetStatus())
      dispatch(
        groupActions.getOtherGroupsRequest({
          perPage: 6,
          page: 1
        })
      )
    }
  }, [requestSend])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          value: item.id,
          label: item.courseName + " - " + item.courseCode
        }
      })
      setCoursesOptions(a)
    } else {
      setCoursesOptions([])
    }
  }, [courses])

  useEffect(() => {
    if (fieldExists(users, "results") && users.results.length > 0) {
      const a = users.results.map((item, index) => {
        return {
          value: item.id,
          label: item?.personalInfo?.fullName + " - " + item.email
        }
      })
      setMembersOptions(a)
    } else {
      setMembersOptions([])
    }
  }, [users])

  const initialValues = {
    groupName: "",
    courses: [],
    members: []
  }

  const validationSchema = Yup.object().shape({
    groupName: Yup.string().required("Required"),
    courses: Yup.array().min(1, "At least 1 course required"),
    members: Yup.array().min(2, "At least 2 members required")
  })

  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues,
    resetForm
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      dispatch(
        groupActions.createGroupRequest({
          groupName: values.groupName,
          courses: values.courses.map((item) => item.value),
          members: values.members.map((item) => item.value)
        })
      )
    }
  })

  const [isSubmit, setIsSubmit] = useState(false)

  const onReset = () => {
    setShow(false)
    setIsSubmit(false)
    resetForm()
  }

  const handleModalClosed = () => {
    setModalType("Add New")
    onReset()
  }

  return (
    <Fragment>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center ">
        <div>
          <h3>My Groups</h3>
          <p className="mb-2">Groups created by you or you are a member of.</p>
        </div>
        <Button
          color="primary"
          className="text-nowrap mb-1"
          onClick={() => {
            setModalType("Add New")
            setShow(true)
          }}
        >
          Add New Group
        </Button>
      </div>
      {fetchingGroups ? (
        <div className="text-center">
          <Spinner color="primary" className="mb-1" />
        </div>
      ) : (
        <>
          <GroupCard groups={myGroups} type="my" />
          {myGroups?.totalPages > myGroups?.page ? (
            <div className="d-flex justify-content-end flex-wrap">
              <Button
                color="primary"
                className="text-nowrap mb-1"
                size="sm"
                onClick={() => {
                  dispatch(
                    groupActions.getMyGroupsRequest({
                      perPage: myGroups?.limit + 6,
                      page: 1
                    })
                  )
                }}
              >
                View More
              </Button>
            </div>
          ) : null}
        </>
      )}

      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center ">
        <div>
          <h3>Other Groups</h3>
          <p className="mb-2">
            Look Around and Join Groups that interest you.
            {/* Recommended groups based on your Interests and Courses you studied. */}
          </p>
        </div>
      </div>
      {fetchingGroups ? (
        <div className="text-center">
          <Spinner color="primary" className="mb-1" />
        </div>
      ) : otherGroups?.results?.length > 0 ? (
        <>
          <GroupCard groups={otherGroups} type="other" />
          {otherGroups?.totalPages > otherGroups?.page ? (
            <div className="d-flex justify-content-end flex-wrap">
              <Button
                color="primary"
                className="text-nowrap mb-1"
                size="sm"
                onClick={() => {
                  dispatch(
                    groupActions.getOtherGroupsRequest({
                      perPage: otherGroups?.limit + 6,
                      page: 1
                    })
                  )
                }}
              >
                View More
              </Button>
            </div>
          ) : null}
        </>
      ) : (
        <div className="text-center">
          <h3>No Groups Found</h3>
        </div>
      )}

      <Modal
        isOpen={show}
        onClosed={handleModalClosed}
        toggle={() => setShow(!show)}
        className="modal-dialog-centered modal-lg"
      >
        <ModalHeader
          className="bg-transparent"
          toggle={() => setShow(!show)}
        ></ModalHeader>
        <ModalBody className="px-5 pb-5">
          <div className="text-center mb-4">
            <h1>{modalType} Group</h1>
            <p>Fill out the details</p>
          </div>
          <Row
            tag="form"
            onSubmit={(e) => {
              e.preventDefault()
              setIsSubmit(true)
              handleSubmit()
            }}
          >
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="groupName">
                Group Name
              </Label>
              <Input
                type="text"
                id="groupName"
                name="groupName"
                placeholder="Enter group name"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.groupName}
              />
              {isSubmit && errors.groupName && touched.groupName ? (
                <div className="error-message text-danger">
                  {errors.groupName}
                </div>
              ) : null}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="courses">
                Courses
              </Label>
              <Select
                id="courses"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={coursesOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="courses"
                value={values.courses}
                onChange={(value) => {
                  setFieldValue("courses", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.courses && (
                <div className="text-danger text-small mt-50">
                  {errors.courses}
                </div>
              )}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="members">
                Members
              </Label>

              <Select
                id="members"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={membersOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="members"
                value={values.members}
                onChange={(value) => {
                  setFieldValue("members", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.members && (
                <div className="text-danger text-small mt-50">
                  {errors.members}
                </div>
              )}
            </Col>

            <Col className="text-center mt-2" xs={12}>
              <Button
                type="submit"
                color="primary"
                className="me-1"
                disabled={creationLoading}
              >
                {creationLoading ? (
                  <Spinner className="me-1" size="sm" />
                ) : null}
                Submit
              </Button>
              <Button
                type="reset"
                outline
                onClick={onReset}
                disabled={creationLoading}
              >
                Discard
              </Button>
            </Col>
          </Row>
        </ModalBody>
      </Modal>
    </Fragment>
  )
}

export default Groups
