import { INTEREST_TYPES } from "./types"

const initialState = {
  interests: {},
  error: null,
  created: false,
  deleted: false,
  updated: false,
  createdUpdatedLoading: false,
  deletedLoading: false
}

const interestReducer = (state = initialState, action) => {
  switch (action.type) {
    case INTEREST_TYPES.GET_ALL_INTEREST_REQUEST:
      return {
        ...state,
        error: null,
        created: false,
        deleted: false,
        updated: false
      }

    case INTEREST_TYPES.GET_ALL_INTEREST_SUCCESS:
      return {
        ...state,
        interests: action.payload,
        createdUpdatedLoading: false,
        deletedLoading: false
      }
    case INTEREST_TYPES.GET_ALL_INTEREST_FAIL:
      return {
        ...state,
        error: action.payload
      }

    case INTEREST_TYPES.CREATE_INTEREST_REQUEST:
      return {
        ...state,
        createdUpdatedLoading: true,
        error: null,
        created: false
      }

    case INTEREST_TYPES.CREATE_INTEREST_SUCCESS:

      return {
        ...state,
        createdUpdatedLoading: false,
        created: true
      }
    case INTEREST_TYPES.CREATE_INTEREST_FAIL:
      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false,
        created: false
      }

    case INTEREST_TYPES.UPDATE_INTEREST_REQUEST:
      return {
        ...state,
        createdUpdatedLoading: true,
        error: null,
        updated: false
      }

    case INTEREST_TYPES.UPDATE_INTEREST_SUCCESS:
      return {
        ...state,
        updated: true,
        createdUpdatedLoading: false
      }

    case INTEREST_TYPES.UPDATE_INTEREST_FAIL:
      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false,
        updated: false
      }

    case INTEREST_TYPES.DELETE_INTEREST_REQUEST:
      return {
        ...state,
        deletedLoading: true,
        error: null,
        deleted: false
      }

    case INTEREST_TYPES.DELETE_INTEREST_SUCCESS:
     
      return {
        ...state,
        deleted: true,
        deletedLoading: false
      }

    case INTEREST_TYPES.DELETE_INTEREST_FAIL:
      return {
        ...state,
        error: action.payload,
        deletedLoading: false,
        deleted: false
      }

    default:
      return state
  }
}

export default interestReducer
