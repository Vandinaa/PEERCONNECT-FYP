import toast from "react-hot-toast"
import { REGISTER_TYPES } from "./types"

const initialState = {
  data: null,
  error: null,
  loading: false,
  isRegistered: false,
  isEmailTaken: false
}

export default function registerReducer(state = initialState, action) {
  switch (action.type) {
    case REGISTER_TYPES.REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        data: null,
        isEmailTaken: false,
        isRegistered: false
      }
    case REGISTER_TYPES.SUCCESS:
      toast.success("Registration Successful","Please check your email for a verification link")
      return {
        ...state,
        data: action.payload,
        error: null,
        loading: false,
        isEmailTaken: false,
        isRegistered: true
      }
    case REGISTER_TYPES.FAILURE:
      let isEmailTakenT = false
      if ( typeof action.payload === 'string' && action.payload !== "") {
        if (action.payload === "Email already taken") {
          toast.error("Email Address already in use","Please try again with a different email address")
          isEmailTakenT = true
        }else {
          toast.error(action.payload)
        }
      } 
      return {
        ...state,
        error: action.payload,
        isEmailTaken: isEmailTakenT,
        data: null,
        loading: false,
        isRegistered: false
      }

    case REGISTER_TYPES.IS_REGISTERED:
      return {
        ...state,
        isRegistered: action.payload
      }

    default:
      return state
  }
}
