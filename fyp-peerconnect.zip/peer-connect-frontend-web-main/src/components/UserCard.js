import { Badge, Button, Card, CardBody, Col, Row } from "reactstrap"
import { getInitials, isObjEmpty } from "@src/utility/Utils"

import Avatar from "@components/avatar"
import { Fragment } from "react"
import { MessageSquare } from "react-feather"
import { useNavigate } from "react-router-dom"

const alternateImage =
  require("@src/assets/images/avatars/avatar-blank.png").default

const UserCards = ({ users }) => {
  const navigate = useNavigate()

  return (
    <Fragment>
      <Row>
        {!isObjEmpty(users) &&
          users?.results?.map((item, index) => {
            return (
              <Col key={index} xl={4} md={6}>
                <Card>
                  <CardBody>
                    <div className="d-flex justify-content-between">
                      <div
                        className="d-flex align-items-center cursor-pointer"
                        onClick={() => {
                          if (item.id) {
                            navigate(`/profile?id=${item.id}`)
                          } else if (item?._id) {
                            navigate(`/profile?id=${item._id}`)
                          }
                        }}
                      >
                        {item?.personalInfo?.profile_image &&
                        item?.personalInfo?.profile_image?.url !== "" ? (
                          <Avatar
                            img={
                              item?.personalInfo?.profile_image?.url ||
                              alternateImage
                            }
                            imgHeight={50}
                            imgWidth={50}
                          />
                        ) : (
                          <Avatar
                            color="light-primary"
                            content={getInitials(
                              item?.personalInfo?.fullName?.toUpperCase()
                            )}
                            initials
                            size="lg"
                            className="rounded"
                          />
                        )}

                        <div className="mx-1">
                          <h6 className="mb-0">
                            {item?.personalInfo?.fullName}
                          </h6>
                          <small>{item?.email}</small>
                        </div>
                      </div>

                      <div className="d-flex">
                        <Button
                          color="primary"
                          className="text-nowrap mb-1 me-1"
                          size="sm"
                          onClick={(e) => {
                            e.preventDefault()
                            if (item.id) {
                              navigate(`/chats?id=${item.id}`)
                            } else if (item?._id) {
                              navigate(`/chats?id=${item._id}`)
                            }
                          }}
                        >
                          <MessageSquare size={18} className="me-50" />
                          <span className="align-middle">Chat</span>
                        </Button>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between align-items-end">
                      {item?.courses?.length > 0 && (
                        <div className="design-group mb-50 pt-50">
                          <h6 className="section-label">Courses</h6>
                          {item?.courses?.map((course, index) => {
                            return (
                              <Badge
                                key={index}
                                className="me-1"
                                color="light-primary"
                              >
                                {course?.courseName}
                              </Badge>
                            )
                          })}
                        </div>
                      )}
                    </div>
                    <div className="d-flex justify-content-between align-items-end">
                      {item?.interests?.length > 0 && (
                        <div className="design-group mb-50 pt-50">
                          <h6 className="section-label">Interests</h6>

                          {item?.interests?.map((interest, index) => {
                            return (
                              <Badge
                                key={index}
                                className="me-50 mt-50"
                                color="light-warning"
                              >
                                {interest.interestName}
                              </Badge>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  </CardBody>
                </Card>
              </Col>
            )
          })}
      </Row>
    </Fragment>
  )
}

export default UserCards
