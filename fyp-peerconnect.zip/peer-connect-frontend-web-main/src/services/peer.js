class PeerService {
  constructor() {
    this.createPeerConnection();
  }

  createPeerConnection() {
    this.peer = new RTCPeerConnection({
      iceServers: [
        { urls: "stun:stun.l.google.com:19302" },
        { urls: "stun:global.stun.twilio.com:3478" }
      ]
    });

    this.peer.ontrack = (event) => {
      console.log("Track event received:", event);
      if (this.onTrackCallback) {
        this.onTrackCallback(event);
      }
    };

    this.peer.onicecandidate = (event) => {
      if (event.candidate) {
        console.log("ICE candidate:", event.candidate);
      }
    };

    this.peer.oniceconnectionstatechange = () => {
      console.log("ICE connection state change:", this.peer.iceConnectionState);
      if (this.peer.iceConnectionState === 'closed' || this.peer.iceConnectionState === 'failed' || this.peer.iceConnectionState === 'disconnected') {
        this.createPeerConnection(); // Recreate the peer connection if it's in a bad state
      }
    };
  }

  setStream(stream) {
    this.stream = stream;
    stream.getTracks().forEach(track => {
      this.peer.addTrack(track, stream);
    });
  }

  setOnTrackCallback(callback) {
    this.onTrackCallback = callback;
  }

  async createOffer() {
    if (this.peer.signalingState === "closed") {
      this.createPeerConnection();
    }
    const offer = await this.peer.createOffer();
    await this.peer.setLocalDescription(offer);
    return offer;
  }

  async createAnswer(offer) {
    if (this.peer.signalingState === "closed") {
      this.createPeerConnection();
    }
    await this.peer.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await this.peer.createAnswer();
    await this.peer.setLocalDescription(answer);
    return answer;
  }

  async setRemoteDescription(answer) {
    await this.peer.setRemoteDescription(new RTCSessionDescription(answer));
  }

  close() {
    if (this.peer) {
      this.peer.close();
    }
  }
}

export default new PeerService();