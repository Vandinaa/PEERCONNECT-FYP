import { SEARCH_TYPES } from "./types"

export const getListOfSearchRequest = (data) => ({
  type: SEARCH_TYPES.GET_LIST_OF_SEARCH_REQUEST,
  payload: data
})

export const getListOfSearchSuccess = (data) => ({
  type: SEARCH_TYPES.GET_LIST_OF_SEARCH_SUCCESS,
  payload: data
})

export const getListOfSearchFailure = (data) => ({
  type: SEARCH_TYPES.GET_LIST_OF_SEARCH_FAILURE,
  payload: data
})

export const clearSearchList = () => ({
  type: SEARCH_TYPES.CLEAR_SEARCH_LIST
})
