import { AlertTriangle, Bell, Check, CheckCircle, MessageSquare, X } from "react-feather"
// ** Reactstrap Imports
import {
  Badge,
  Button,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Input,
  UncontrolledDropdown
} from "reactstrap"

// ** Custom Components
import MySwal from "sweetalert2"

import Avatar from "@components/avatar"
// ** React Imports
import { Fragment, useEffect, useState } from "react"
import PerfectScrollbar from "react-perfect-scrollbar"
// ** Third Party Components
import classnames from "classnames"

import * as groupActions from "@src/store/common/groupManagement/actions"
import * as chatActions from "@src/store/common/chat/actions"

import toast, { CheckmarkIcon } from 'react-hot-toast';


import {
  fieldExists,
  getInitials,
  getProfileId,
  isNullObject,
  isObjEmpty
} from "@src/utility/Utils"

import { useDispatch, useSelector } from "react-redux"

import socketIOClient from "socket.io-client"
import { use } from "i18next"
import { useLocation, useNavigate } from "react-router-dom"

const MessagesNotificationDropdown = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()

  const [joinRequestsState, setJoinRequestsState] = useState([])

  const { chatNotification } = useSelector((state) => state.chatReducer)

  useEffect(() => {
    dispatch(chatActions.chatNotificationRequest())
  }, [dispatch])

  useEffect(() => {
    if (!isObjEmpty(chatNotification) && chatNotification.length) {
      setJoinRequestsState(chatNotification)
    }
  }, [chatNotification])

  useEffect(() => {
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
    socket.on(getProfileId() + "-chat-notifications", (payload) => {
     
      console.log("payload", payload)
      toast.success(
        <div>
          <div>{payload[0]?.personalInfo?.fullName} sent you a message</div>
          <div>{payload[0]?.email}</div>
        </div>
      )

      setJoinRequestsState(payload)
    })
    return () => {
      socket.off(getProfileId() + "-chat-notifications")
    }
  }, [])

  const handleCallAction = (data,accepting,t,socket) => {
    if(accepting){
      console.log('accepting',data)
      // 
      const { callerId, isGroupCall, action, callType, receiverId } = data;
      socket.emit('answerCall', { callerId , isGroupCall, callType, receiverId, action: 'accept' });

      if(location.pathname !== '/group-chat' && isGroupCall){
        toast.dismiss(t.id)
        navigate('/group-chat?id='+callerId + '&callType=' + callType)
      }else if (location.pathname !== '/chat' && !isGroupCall){
        toast.dismiss(t.id)
        navigate('/chats?id='+callerId + '&callType=' + callType)
      }



     
    }else {
      toast.dismiss(t.id)
    }
  }
  
  useEffect(() => {
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
    socket.on(`${getProfileId()}-incomingCall`, (data) => {
      console.log('incoming call',data)

       toast(
        t => (
          <div className='w-100 d-flex align-items-center justify-content-between'>
            <div className='d-flex align-items-center justify-content-between'>
            <div className="text-capitalize">
            <Avatar
              color="light-primary"
              content={getInitials("John Doe")}
              initials
              status="online"
            />
          </div>

              <div>
                <p className='mb-0'>{data.callerName}</p>
                <small>is calling you</small>
              </div>
              <div>
                <Button color='success' className='btn-sm' onClick={()=> handleCallAction(data,true,t,socket)}
                >
                <CheckCircle />

                </Button>
                <Button color='danger' className='btn-sm' onClick={()=> handleCallAction(data,false,t,socket)}>
                <X />
                </Button>
                </div>
            </div>
          </div>
        ),
        {
          style: {
            minWidth: '300px'
          }
        }
      )

      
    })


    return () => {
      socket.off(`${getProfileId()}-incomingCall`)
    }
  }, [])


  useEffect(() => {
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)


    socket.on(`${getProfileId()}-callAnswered`, (data) => {
      if(data.action === 'accept'){
        toast.success('Call accepted')
        console.log('data',location)
        if(location.pathname !== '/group-chat' && data.isGroupCall){
          navigate('/group-chat?id='+data.receiverId + '&callType=' + data.callType)  
        }else if (!data.isGroupCall && location.search !== '?id='+data.receiverId + '&callType=' + data.callType){
          navigate('/chats?id='+data.receiverId + '&callType=' + data.callType)
        }
       
      }else {
        toast.error('Call declined')
      }
    }
    )

    return () => {
      socket.off(`${getProfileId()}-incomingCall`)
    }
  }, [])











  const renderNotificationItems = (chatNotification) => {
    return (
      <PerfectScrollbar
        component="li"
        className="media-list scrollable-container"
        options={{
          wheelPropagation: false
        }}
      >
        {chatNotification?.length > 0
          ? chatNotification?.map((item, index) => {
              const title = `${item?.personalInfo?.fullName} sent you a message`
              const subtitle = item?.email
              const avatarContent = item?.personalInfo?.fullName
                ? item?.personalInfo?.fullName?.charAt(0).toUpperCase()
                : null
              const newItem = {
                ...item,
                title,
                subtitle,
                avatarContent,
                color: "light-success"
              }

              return (
                <div
                  key={index}
                  className="d-flex text-primary cursor-pointer"
                  // href={`/chats?id=${item._id}`}
                  onClick={(e) => {
                    // e.preventDefault()
                    setJoinRequestsState(
                      joinRequestsState.filter((item) => item._id !== newItem._id)
                    )
                    navigate(`/chats?id=${item._id}`)

                  }
                  }
                >
                  <div
                    className={classnames("list-item d-flex no-wrap", {
                      "align-items-start": true
                    })}
                  >
                    <div className="me-1">
                      <Avatar
                        content={newItem.avatarContent}
                        color={newItem.color}
                      />
                    </div>
                    <div className="fw-bolder no-wrap">{newItem.title}</div>
                  </div>
                </div>
              )
            })
          : null}
      </PerfectScrollbar>
    )
  }
  /*eslint-enable */

  return (
    <UncontrolledDropdown
      tag="li"
      className="dropdown-notification nav-item me-25"
    >
      <DropdownToggle
        tag="div"
        className="nav-link"
        // href="/"
        // onClick={(e) => e.preventDefault()}
      >
        <MessageSquare size={21} />
        {joinRequestsState.length > 0 ? (
          <Badge pill color="danger" className="badge-up">
            {joinRequestsState.length}
          </Badge>
        ) : null}
      </DropdownToggle>
      <DropdownMenu end tag="ul" className="dropdown-menu-media mt-0">
        <li className="dropdown-menu-header">
          <DropdownItem className="d-flex" tag="div" header>
            <h4 className="notification-title mb-0 me-auto">Notifications</h4>
            <Badge tag="div" color="light-primary" pill>
              {joinRequestsState.length} New
            </Badge>
          </DropdownItem>
        </li>
        {renderNotificationItems(joinRequestsState)}
        {/* <li className="dropdown-menu-footer">
          <Button color="primary" block>
            Read all notifications
          </Button>
        </li> */}
      </DropdownMenu>
    </UncontrolledDropdown>
  )
}

export default MessagesNotificationDropdown
