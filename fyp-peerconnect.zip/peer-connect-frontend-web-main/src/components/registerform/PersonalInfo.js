import { useFormik } from "formik"

import { Fragment, useState } from "react"
import * as Yup from "yup"

import { ArrowLeft, ArrowRight } from "react-feather"

import { Button, Col, Form, Input, Label, Row } from "reactstrap"

import Flatpickr from "react-flatpickr"

import "@styles/react/libs/react-select/_react-select.scss"
import RadioButtonGroup from "../RadioButtonGroup"

const PersonalInfo = ({ stepper, setData, setStep }) => {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue
  } = useFormik({
    initialValues: {
      full_name: "",
      date_of_birth: "",
      gender: "",
      contact_number: ""
    },
    validationSchema: Yup.object({
      full_name: Yup.string()
        .matches(/^[aA-zZ\s]+$/, "Only letters and spaces are allowed")
        .max(30, "Must be 30 characters or less")
        .required("Required"),
      date_of_birth: Yup.date()
        .max(
          new Date(Date.now() - 16 * 365 * 24 * 60 * 60 * 1000),
          "You must be 16 years or older"
        )
        .required("Required"),
      gender: Yup.string().required("Required"),

      contact_number: Yup.string()
        .matches(
          /^[0-9+-]{10,13}$/,
          "Only numbers , + and - are allowed , 10-13"
        )
        .required("Required")
    }),
    onSubmit: (values) => {
      setIsSubmitting(false)
      setData(values)
      setStep(2)
      stepper.next()
    }
  })

  return (
    <Fragment>
      <div className="content-header">
        <h5 className="mb-0">Personal Info</h5>
        <small>Enter Your Personal Info.</small>
      </div>
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setIsSubmitting(true)
          handleSubmit()
        }}
      >
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="firstName">
              Full Name
            </Label>
            <Input
              type="text"
              id="full_name"
              name="full_name"
              placeholder="john doe"
              autoFocus
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.full_name}
            />
            {isSubmitting && errors.full_name ? (
              <div className="error-message text-danger ">
                {errors.full_name}
              </div>
            ) : null}
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="date_of_birth">
              Birth Date*
            </Label>
            <Flatpickr
              value={values.date_of_birth}
              placeholder="Select Date..."
              className="form-control"
              onChange={(date) => {
                setFieldValue("date_of_birth", date)
              }}
              onBlur={handleBlur}
            />

            {isSubmitting && errors.date_of_birth ? (
              <div className="error-message text-danger">
                {errors.date_of_birth}
              </div>
            ) : null}
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" for="contact_number">
              Phone*
            </Label>
            <Input
              type="number"
              id="contact_number"
              name="contact_number"
              placeholder="+923001234567"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.contact_number}
            />
            {isSubmitting && errors.contact_number ? (
              <div className="error-message text-danger">
                {errors.contact_number}
              </div>
            ) : null}
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="6" className="mb-1">
            <Label className="form-label" htmlFor="gender">
              Gender*
            </Label>
            <RadioButtonGroup
              name="gender"
              options={[
                { value: "male", label: "Male" },
                { value: "female", label: "Female" }
              ]}
              label="gender"
              onChange={handleChange}
              value={values.gender}
              onBlur={handleBlur}
            />
            {isSubmitting && errors.gender ? (
              <div className="error-message text-danger mb-2">
                {errors.gender}
              </div>
            ) : null}
          </Col>
        </Row>
        <div className="d-flex justify-content-between">
          <Button
            type="button"
            color="primary"
            className="btn-prev"
            onClick={() => stepper.previous()}
          >
            <ArrowLeft
              size={14}
              className="align-middle me-sm-25 me-0"
            ></ArrowLeft>
            <span className="align-middle d-sm-inline-block d-none">
              Previous
            </span>
          </Button>
          <Button type="submit" color="primary" className="btn-next">
            <span className="align-middle d-sm-inline-block d-none">Next</span>
            <ArrowRight
              size={14}
              className="align-middle ms-sm-25 ms-0"
            ></ArrowRight>
          </Button>
        </div>
      </Form>
    </Fragment>
  )
}

export default PersonalInfo
