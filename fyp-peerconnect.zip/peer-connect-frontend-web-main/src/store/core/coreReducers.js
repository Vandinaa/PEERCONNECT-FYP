import { LOGIN_TYPES } from "../common/login/types"
import authReducer from "./../common/auth/reducer"
import { combineReducers } from "redux"
import chatReducer from "../common/chat/reducer"
import groupManagementReducer from "../common/groupManagement/reducer"
import interestReducer from "../common/interests/reducer"
import layoutReducer from "../common/layout/reducers"
import loginReducer from "./../common/login/reducer"
import navbarReducer from "./../common/navbar/reducers"
import searchReducer from "../common/search/reducer"
import registerReducer from "../common/register/reducer"
import securityReducer from "./../common/security/reducer"
import courseReducer from "../common/courses/reducer"
import usersReducer from "../common/users/reducer"

const coreReducer = combineReducers({
  loginReducer,
  layoutReducer,
  navbarReducer,
  registerReducer,
  authReducer,
  interestReducer,
  courseReducer,
  securityReducer,
  groupManagementReducer,
  usersReducer,
  searchReducer,
  chatReducer,

})

const appReducer = (state, action) => {
  if (action.type === LOGIN_TYPES.LOGOUT) {
    state = undefined
  }
  return coreReducer(state, action)
}

export default appReducer

//export default coreReducer
