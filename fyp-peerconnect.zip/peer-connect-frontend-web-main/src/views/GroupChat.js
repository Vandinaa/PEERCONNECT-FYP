import { useState, useEffect } from "react"

import Avatar from "@components/avatar"
import * as chatActions from "@src/store/common/chat/actions"

import classnames from "classnames"
import PerfectScrollbar from "react-perfect-scrollbar"
import { MoreVertical, Send, Image } from "react-feather"

import * as groupActions from "@src/store/common/groupManagement/actions"

import socketIOClient from "socket.io-client"

import {
  Card,
  CardHeader,
  Form,
  Label,
  InputGroup,
  Input,
  InputGroupText,
  Button,
  Spinner
} from "reactstrap"

import "@styles/base/pages/app-chat-list.scss"
import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import { getProfileId, getUserData } from "@src/utility/Utils"
import { isObjEmpty } from "@src/utility/Utils"

const GroupChat = () => {
  // ** States
  const [msg, setMsg] = useState("")
  const [chatRef, setChatRef] = useState(null)
  const [chatData, setChatData] = useState({
    groupId: 0,
    groupName: "",
    groupAvatar: "",
    userId: 1,
    userName: "",
    userAvatar: "",
    chat: []
  })
  const dispatch = useDispatch()
  const [groupId, setGroupId] = useState(
    new URLSearchParams(window.location.search).get("id") || null
  )
  const navigate = useNavigate()

  const { fetchingGroups, groupDetails, groupNotFound } = useSelector(
    (state) => state.groupManagementReducer
  )

  const { groupChatHistory } = useSelector((state) => state.chatReducer)

  useEffect(() => {
    const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
    socket.on(groupId, (payload) => {
      const newMsg = {
        message: payload.message,
        time: payload.time,
        senderId: payload.senderId === getProfileId() ? 11 : 1,
        userId: payload.userId,
        userName: payload.userName,
        userAvatar: payload.userAvatar
      }

      setChatData((prevState) => {
        const newChat = { ...prevState }
        newChat.chat.push(newMsg)
        return newChat
      })
    })
    return () => {
      socket.off(groupId)
    }
  }, [])

  useEffect(() => {
    console.log("groupId", groupNotFound, groupId)
    if (groupId !== null) {
      dispatch(groupActions.getGroupDetailsRequest(groupId))
      dispatch(chatActions.getGroupChatHistoryRequest(groupId))
    }
     if (groupNotFound || groupId === null) {
      dispatch(groupActions.resetStatus())
      navigate("/groups")
    }
  }, [dispatch, groupId,groupNotFound])

  useEffect(() => {
    if (!isObjEmpty(groupDetails)) {
      let gcData = {
        groupId: groupDetails.id,
        groupName: groupDetails?.groupName ?? "N/A",
        groupAvatar: groupDetails.groupImage?.url || null,
        userId: getProfileId(),
        userName: getUserData()?.personalInfo?.fullName ?? "",
        userAvatar: getUserData()?.personalInfo?.profile_image?.url || null,
        chat: groupChatHistory.map((msg) => {
          return {
            message: msg.message,
            time: msg.createdAt,
            senderId: msg.senderId === getProfileId() ? 11 : 1,
            userId: msg.userId,
            userName: msg.userName,
            userAvatar: msg.userAvatar
          }
        })
      }

      setChatData(gcData)
    }
  }, [groupChatHistory, groupDetails])

  const formattedChatData = () => {
    const chatLog = chatData?.chat || []
    const formattedChatLog = []

    let currentGroup = null
    let lastSenderId = null
    let lastUserId = null

    for (const msg of chatLog) {
      const { senderId, userId, message, time, userName, userAvatar } = msg

      if (
        senderId !== lastSenderId ||
        (senderId === 1 && userId !== lastUserId)
      ) {
        // If the senderId has changed or it's a new userId for senderId 1, start a new group
        currentGroup = { senderId, userId, userName, userAvatar, messages: [] }
        formattedChatLog.push(currentGroup)
        lastSenderId = senderId
        lastUserId = userId
      }

      currentGroup.messages.push({ msg: message, time })
    }

    return formattedChatLog
  }

  //** Renders user chat
  const renderChats = () => {
    return formattedChatData().map((item, index) => {
      return (
        <div
          key={index}
          className={classnames("chat", {
            "chat-left": item.senderId !== 11
          })}
        >
          <div className="chat-avatar flex d-flex">
            <RenderClient
              avatar={
                item.senderId === 1 ? item.userAvatar : chatData.userAvatar
              }
              name={item.senderId === 1 ? item?.userName : chatData?.userName}
              avatarColor={"light-primary"}
            />
          </div>
          <div className="chat-body">
            <div
              className={classnames("chat-name", {
                // "chat-content-left": item.senderId !== 11
              })}
            >
              <h6 className="mb-0">
                {item.senderId === 1 ? item?.userName : chatData?.userName}
              </h6>
            </div>

            {item.messages.map((chat) => (
              <div key={chat.msg} className="chat-content">
                <p>{chat.msg}</p>
              </div>
            ))}
          </div>
        </div>
      )
    })
  }

  //** Scroll to chat bottom
  const scrollToBottom = () => {
    chatRef.scrollTop = Number.MAX_SAFE_INTEGER
  }

  useEffect(() => {
    if (chatRef !== null) {
      scrollToBottom()
    }
  }, [chatRef, chatData.chat.length])

  const handleSendMsg = (e) => {
    e.preventDefault()
    if (msg.trim().length) {
      // const newMsg = structuredClone(chatData)

      // newMsg.chat.push({
      //   message: msg,
      //   time: new Date(),
      //   senderId: 11,
      //   userId: getProfileId(),
      // })

      // setChatData(newMsg)

      const socket = socketIOClient(process.env.REACT_APP_SOCKET_URL)
      socket.emit("message", {
        type: "groupchat",
        senderId: getProfileId(),
        receiverId: groupId,
        message: msg
      })

      setMsg("")
    }
  }

  const RenderClient = ({ avatar, name, avatarColor }) => {
    if (avatar && avatar.length) {
      return <Avatar className="me-1" img={avatar} width="32" height="32" />
    } else {
      return (
        <Avatar
          initials
          color={avatarColor || "light-primary"}
          content={
            name != "" && name !== undefined
              ? name.charAt(0).toUpperCase()
              : "N/A"
          }
        />
      )
    }
  }

  return fetchingGroups ? (
    <div className="text-center">
      <Spinner color="primary" className="mb-1" />
    </div>
  ) : (
    <Card className="chat-widget">
      <CardHeader>
        <div className="d-flex align-items-center">
          <RenderClient
            avatar={chatData.groupAvatar}
            name={chatData.groupName}
            avatarColor={"light-primary"}
          />
          <h5 className="mb-0 ms-50">{chatData.groupName}</h5>
        </div>
        <MoreVertical size={18} className="cursor-pointer" />
      </CardHeader>
      <div className="chat-app-window">
        <PerfectScrollbar
          containerRef={(el) => setChatRef(el)}
          className="user-chats scroll-area"
          options={{ wheelPropagation: false }}
        >
          <div className="chats">{renderChats()}</div>
        </PerfectScrollbar>
        <Form className="chat-app-form" onSubmit={(e) => e.preventDefault()}>
          <InputGroup className="input-group-merge me-1 form-send-message">
            <InputGroupText>
              <Label className="attachment-icon mb-0" for="attach-doc">
                <Image className="cursor-pointer text-secondary" size={14} />
                <input type="file" id="attach-doc" hidden />
              </Label>
            </InputGroupText>
            <Input
              type="textarea"
              value={msg}
              className="border-0"
              onChange={(e) => setMsg(e.target.value)}
              placeholder="Type your message"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault()
                  setMsg((prevMsg) => prevMsg + "\n")
                }
              }}
            />
          </InputGroup>
          <Button
            className="send"
            color="primary"
            type="button"
            onClick={(e) => handleSendMsg(e)}
          >
            <Send size={14} className="d-lg-none" />
            <span className="d-none d-lg-block">Send</span>
          </Button>
        </Form>{" "}
      </div>
    </Card>
  )
}
export default GroupChat
