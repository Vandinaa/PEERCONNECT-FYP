import "@styles/react/libs/flatpickr/flatpickr.scss"
import "@styles/react/libs/tables/react-dataTable-component.scss"

import * as userActions from "@src/store/common/users/actions"

import {
  Button,
  Badge,
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Col,
  Row
} from "reactstrap"

import {
  Book,
  Check,
  ChevronDown,
  Feather,
  Slash,
  UserPlus,
  Users
} from "react-feather"
import { Fragment, useEffect, useState } from "react"
import { fieldExists, isNullObject, isObjEmpty } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import DataTable from "react-data-table-component"
import ReactPaginate from "react-paginate"
import Select from "react-select"
import Swal from "sweetalert2"
import { rowsItemsOptions } from "@src/utility/Options"
import { selectThemeColors } from "@utils"
import toast from "react-hot-toast"
import { useNavigate } from "react-router-dom"
import { useTranslation } from "react-i18next"
import withReactContent from "sweetalert2-react-content"
import Avatar from "@components/avatar"

const MySwal = withReactContent(Swal)

const ManageUsers = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()

  const [rowsPerPage, setRowsPerPage] = useState({
    value: 20,
    label: "20"
  })

  const [currentPage, setCurrentPage] = useState(0)
  const [data, setData] = useState([])

  const renderClient = (row) => {
    if (row.hasOwnProperty("avatar") && row.avatar.length) {
      return <Avatar className="me-1" img={row.avatar} width="32" height="32" />
    } else {
      return (
        <Avatar
          initials
          className="me-1"
          color={row.avatarColor || "light-primary"}
          content={row.name != "" ? row.name.charAt(0).toUpperCase() : "N/A"}
        />
      )
    }
  }

  const dispatch = useDispatch()

  const { stats, users, updated } = useSelector((state) => state.usersReducer)

  useEffect(() => {
    if (updated) {
      toast.success(t("User Updated Successfully"))
    }
  }, [updated])

  const handleChangeStatus = (data, type) => {
    return MySwal.fire({
      title: t("Are you sure?"),
      text: t("You won't be able to revert this!"),
      icon: type == "block" ? "error" : "success",
      showCancelButton: true,
      confirmButtonText: type == "block" ? t("Block") : t("Give Access"),
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(
          userActions.blockUserRequest({
            params: data.id,
            body: {
              status: type === "block"
            }
          })
        )
      }
    })
  }

  const ColumnsHeader = [
    {
      name: "FULL NAME",
      minWidth: "250px",
      selector: (row) => row.name,
      cell: (row) => (
        <div
          className="d-flex justify-content-left align-items-center cursor-pointer"
          onClick={() => navigate(`/profile?id=${row.id}`)}
        >
          {renderClient(row)}
          <div className="d-flex flex-column">
            <div className="user_name text-truncate text-body text-capitalize">
              <span className="fw-bolder text-primary">{row.name}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      name: t("EMAIL"),
      minWidth: "250px",
      selector: (row) => row.email,
      cell: (row) => {
        return (
          <div
            className={`d-flex justify-content-left align-items-center ${
              row.isEmailVerified ? "text-success" : "text-warning"
            }`}
          >
            <span>{row.email}</span>
          </div>
        )
      }
    },
    {
      name: t("PHONE"),
      sortable: true,
      minWidth: "250px",
      selector: (row) => row.phone
    },
    {
      name: t("EMAIL VERIFIED"),
      minWidth: "150px",
      center: true,
      cell: (row) => {
        return (
          <div
            className={`d-flex justify-content-left align-items-center ${
              row.isEmailVerified ? "text-success" : "text-warning"
            }`}
          >
            <span>{row.isEmailVerified ? t("YES") : t("NO")}</span>
          </div>
        )
      }
    },
    {
      name: t("ACTIVE"),
      minWidth: "150px",
      center: true,
      cell: (row) => {
        return (
          <div
            className={`d-flex justify-content-left align-items-center ${
              row.isActive ? "text-success" : "text-warning"
            }`}
          >
            <span>{row.isActive ? t("YES") : t("NO")}</span>
          </div>
        )
      }
    },

    {
      name: t("BLOCKED"),
      minWidth: "150px",
      center: true,
      cell: (row) => {
        return (
          <Badge
            color={row.isBlocked ? "light-danger" : "light-success"}
            pill
            className="text-capitalize align-middle"
          >
            {row.isBlocked ? t("YES") : t("NO")}
          </Badge>
        )
      }
    },

    {
      name: t("ACTIONS"),
      minWidth: "200px",

      cell: (row) => {
        return row.isBlocked || !row.isActive ? (
          <Button
            size="sm"
            color="success"
            outline
            className="btn btn-icon me-1"
            onClick={() => {
              handleChangeStatus(row, "giveAccess")
            }}
          >
            <Check className="font-medium-2" />
            <span className="align-middle ms-50">{t("Give Access")}</span>
          </Button>
        ) : (
          <Button
            size="sm"
            color="danger"
            outline
            className="btn btn-icon"
            onClick={() => {
              handleChangeStatus(row, "block")
            }}
          >
            <Slash className="font-medium-2" />
            <span className="align-middle ms-50">{t("Block Account")}</span>
          </Button>
        )
      }
    }
  ]

  useEffect(() => {
    setCurrentPage(0)
    if (isObjEmpty(!isNullObject(users))) {
      dispatch(
        userActions.getAllUsersRequest({
          perPage: rowsPerPage.value,
          page: currentPage + 1
        })
      )
    }
    dispatch(userActions.getStatsRequest())
  }, [dispatch])

  useEffect(() => {
    if (fieldExists(users, "results") && users.results.length > 0) {
      const a = users.results.map((item, index) => {
        return {
          id: item.id,
          name: item.personalInfo?.fullName || "",
          email: item.email || "",
          phone: item.personalInfo?.phone || "",
          isEmailVerified: item?.isEmailVerified ?? true,
          isBlocked: item?.isBlocked ?? false,
          isActive: item?.isActive ?? false
        }
      })
      setData(a)
    } else {
      setData([])
    }
    if (!isNullObject(users)) {
      setCurrentPage(users.page - 1)
    }
  }, [users])

  const dataToRender = () => {
    return data
  }

  const handlePagination = (page) => {
    dispatch(
      userActions.getAllUsersRequest({
        page: page.selected + 1,
        perPage: rowsPerPage
      })
    )
    setCurrentPage(page.selected)
  }

  // ** Function to handle per page
  const handlePerPage = (e) => {
    dispatch(
      userActions.getAllUsersRequest({
        perPage: e.value,
        page: 1
      })
    )
    setCurrentPage(0)
    setRowsPerPage({
      value: e.value,
      label: e.label
    })
  }

  const CustomPagination = () => (
    <ReactPaginate
      nextLabel=""
      breakLabel="..."
      previousLabel=""
      pageRangeDisplayed={2}
      forcePage={currentPage}
      marginPagesDisplayed={2}
      activeClassName="active"
      pageClassName="page-item"
      breakClassName="page-item"
      nextLinkClassName="page-link"
      pageLinkClassName="page-link"
      breakLinkClassName="page-link"
      previousLinkClassName="page-link"
      nextClassName="page-item next-item"
      previousClassName="page-item prev-item"
      pageCount={users?.totalPages ? users.totalPages : 1}
      onPageChange={(page) => handlePagination(page)}
      containerClassName="pagination react-paginate separated-pagination pagination-sm justify-content-end pe-1 mt-1"
    />
  )

  return (
    <Fragment>
      <div className="app-user-list">
        <Row>
          <Col lg="3" sm="6">
            <Card className="plan-card border-success">
              <CardBody>
                <div className="d-flex justify-content-between align-items-start mb-50">
                  <h3 className="fw-bolder mt-50">Total Verified Users</h3>
                  <div
                    className={"avatar avatar-stats p-50 m-0 bg-light-success"}
                  >
                    <div className="avatar-content">
                      <Users size={20} />
                    </div>
                  </div>
                </div>
                <h4 className="fw-bolder display-6 mb-0 text-success">
                  {stats?.totalUsers ? stats?.totalUsers : 0}
                </h4>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" sm="6">
            <Card className="plan-card border-info">
              <CardBody>
                <div className="d-flex justify-content-between align-items-start mb-50">
                  <h3 className="fw-bolder mt-50">Total Groups</h3>
                  <div className={"avatar avatar-stats p-50 m-0 bg-light-info"}>
                    <div className="avatar-content">
                      <UserPlus size={20} />
                    </div>
                  </div>
                </div>
                <h4 className="fw-bolder display-6 mb-0 text-info">
                  {stats?.totalGroups ? stats?.totalGroups : 0}
                </h4>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" sm="6">
            <Card className="plan-card border-warning">
              <CardBody>
                <div className="d-flex justify-content-between align-items-start mb-50">
                  <h3 className="fw-bolder mt-50">Most Popular Courses</h3>
                  <div
                    className={"avatar avatar-stats p-50 m-0 bg-light-warning"}
                  >
                    <div className="avatar-content">
                      <Book size={20} />
                    </div>
                  </div>
                </div>
                <ul className="ps-1 mt-50 grid grid-cols-1 gap-1">
                  {stats?.topCourses?.length > 0
                    ? stats?.topCourses?.map((item, index) => {
                        return (
                          <li className="m-50" key={index}>
                            {" "}
                            <Badge color="light-warning me-2 text-capitalize text-truncate">
                              {item.courseName}
                            </Badge>
                          </li>
                        )
                      })
                    : null}
                </ul>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" sm="6">
            <Card className="plan-card border-primary">
              <CardBody>
                <div className="d-flex justify-content-between align-items-start mb-50">
                  <h3 className="fw-bolder mt-50">Most Loved Interests</h3>
                  <div
                    className={`avatar avatar-stats p-50 m-0 bg-light-primary`}
                  >
                    <div className="avatar-content">
                      <Feather size={20} />
                    </div>
                  </div>
                </div>
                <ul className="ps-1 mt-50 grid grid-cols-1 gap-1">
                  {stats?.topInterests?.length > 0
                    ? stats?.topInterests?.map((item, index) => {
                        return (
                          <li className="mb-50">
                            <Badge color="light-primary me-2 text-capitalize">
                              {item.interestName}
                            </Badge>
                          </li>
                        )
                      })
                    : null}
                </ul>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
      <Card>
        <Row>
          <Col sm="12">
            <CardHeader className="flex-md-row flex-column align-md-items-center align-items-start border-bottom">
              <CardTitle tag="h4">{t("Manage Users")}</CardTitle>
            </CardHeader>
            <div className="react-dataTable">
              <DataTable
                noHeader
                columns={ColumnsHeader}
                paginationPerPage={rowsPerPage}
                className="react-dataTable"
                sortIcon={<ChevronDown size={10} />}
                paginationDefaultPage={currentPage + 1}
                data={dataToRender()}
              />
            </div>
            <CustomPagination />
          </Col>
          <Col lg="2" md="3" sm="1">
            <div className="ps-2 pb-2 d-flex align-items-center">
              <Select
                menuPlacement="top"
                theme={selectThemeColors}
                type="select"
                className="react-select"
                classNamePrefix="select"
                id="sort-select"
                options={rowsItemsOptions}
                isClearable={false}
                value={rowsPerPage}
                onChange={(e) => {
                  handlePerPage(e)
                }}
              />
            </div>
          </Col>
        </Row>
      </Card>
    </Fragment>
  )
}
export default ManageUsers
