import * as interestActions from "./actions"

import { all, call, put, takeEvery } from "redux-saga/effects"
import {
  createInterest,
  deleteInterest,
  getAllInterest,
  updateInterest
} from "@src/services/apis"

import { INTEREST_TYPES } from "./types"
import toast from "react-hot-toast"

function* getAllInterestRequest(action) {
  try {
    const response = yield call(getAllInterest, action.payload)
    yield put(interestActions.getAllInterestSuccess(response))
  } catch (err) {
    yield put(interestActions.getAllInterestFailure(err))
  }
}

function* createInterestRequest(action) {
  try {
    const response = yield call(createInterest, action.payload)
    if (response?.response?.data?.code === 400 && response?.response?.data?.message === "Name already taken") {
      toast.error("Interest already exists with this name")
      yield put(interestActions.createInterestFailure(err))

    }
    else if (response?.status === 201) {
      yield put(
        interestActions.createInterestSuccess(response)
      )
  
    }

  } catch (err) {
    yield put(interestActions.createInterestFailure(err))
  }
}

function* updateInterestRequest(action) {
  try {
    const response = yield call(updateInterest, action.payload)
    
    yield put(interestActions.updateInterestSuccess(response.data))
  } catch (err) {
    yield put(interestActions.updateInterestFailure(err))
  }
}

function* deleteInterestRequest(action) {
  try {
    const response = yield call(deleteInterest, action.payload)
    yield put(
      interestActions.deleteInterestSuccess(response)
    )
  } catch (err) {
    yield put(interestActions.deleteInterestFailure(err))
  }
}

export default function* interestSaga() {
  yield all([
    takeEvery(
      INTEREST_TYPES.GET_ALL_INTEREST_REQUEST,
      getAllInterestRequest
    ),

    takeEvery(
      INTEREST_TYPES.CREATE_INTEREST_REQUEST,
      createInterestRequest
    ),
    takeEvery(
      INTEREST_TYPES.UPDATE_INTEREST_REQUEST,
      updateInterestRequest
    ),
    takeEvery(
      INTEREST_TYPES.DELETE_INTEREST_REQUEST,
      deleteInterestRequest
    )
  ])
}
