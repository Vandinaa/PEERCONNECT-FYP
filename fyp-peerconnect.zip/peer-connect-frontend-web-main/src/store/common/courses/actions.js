import { COURSE_TYPES } from "./types"

export const getAllCoursesRequest = (data) => ({
  type: COURSE_TYPES.GET_ALL_COURSES_REQUEST,
  payload: data
})

export const getAllCoursesSuccess = (data) => ({
  type: COURSE_TYPES.GET_ALL_COURSES_SUCCESS,
  payload: data
})

export const getAllCoursesFailure = (data) => ({
  type: COURSE_TYPES.GET_ALL_COURSES_FAIL,
  payload: data
})

export const createCourseRequest = (data) => ({
  type: COURSE_TYPES.CREATE_COURSE_REQUEST,
  payload: data
})

export const createCourseSuccess = (data) => ({
  type: COURSE_TYPES.CREATE_COURSE_SUCCESS,
  payload: data
})

export const createCourseFailure = (data) => ({
  type: COURSE_TYPES.CREATE_COURSE_FAIL,
  payload: data
})

export const updateCourseRequest = (data) => ({
  type: COURSE_TYPES.UPDATE_COURSE_REQUEST,
  payload: data
})

export const updateCourseSuccess = (data) => ({
  type: COURSE_TYPES.UPDATE_COURSE_SUCCESS,
  payload: data
})

export const updateCourseFailure = (data) => ({
  type: COURSE_TYPES.UPDATE_COURSE_FAIL,
  payload: data
})

export const deleteCourseRequest = (data) => ({
  type: COURSE_TYPES.DELETE_COURSE_REQUEST,
  payload: data
})

export const deleteCourseSuccess = (data) => ({
  type: COURSE_TYPES.DELETE_COURSE_SUCCESS,
  payload: data
})

export const deleteCourseFailure = (data) => ({
  type: COURSE_TYPES.DELETE_COURSE_FAIL,
  payload: data
})
