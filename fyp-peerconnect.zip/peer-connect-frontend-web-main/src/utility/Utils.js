import {
  DefaultRouteForAdmin,
  DefaultRouteForUser,
  Routes
} from "../router/routes"

import { SideMenuItems } from "@src/navigation/menuItems"
import jwt from "jsonwebtoken"
import moment from "moment/moment"
import { toast } from "react-hot-toast"
import useJwt from "@src/auth/jwt/useJwt"

const config = useJwt.jwtConfig

// ** Checks if an object is empty (returns boolean)
export const isObjEmpty = (obj) => {
  if (obj === null || obj === undefined) {
    return true
  } else {
    return Object.keys(obj).length === 0
  }
}

export const isNullObject = (obj) => {
  return (
    obj === null || typeof obj === "undefined" || Object.keys(obj).length === 0
  )
}

// function to check value is not empty array or object if it is not null or undefined
export const isNotEmpty = (value) => {
  if (value !== null && value !== undefined) {
    if (Array.isArray(value)) {
      return value.length > 0
    } else if (typeof value === "object") {
      return Object.keys(value).length > 0
    } else {
      return value !== ""
    }
  } else {
    return false
  }
}

// ** Returns K format from a number
export const kFormatter = (num) => {
  return num > 999 ? `${(num / 1000).toFixed(1)}k` : num
}

export const fieldExists = (obj, field) => {
  return isNullObject(obj)
    ? false
    : obj.hasOwnProperty(field) && obj[field] !== undefined
}

// ** Capitalizes first letter of each word
export const capitalizeEachWord = (str) => {
  return str
    .toLowerCase()
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
}

// ** Checks if the passed date is today
const isToday = (date) => {
  const today = new Date()
  return (
    /* eslint-disable operator-linebreak */
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
    /* eslint-enable */
  )
}

// format date to July 4, 2023 format
export const formatDateToShow = (date) => {
  if (date) {
    const d = new Date(date)
    const month = d.toLocaleString("default", { month: "short" })
    const day = d.getDate()
    const year = d.getFullYear()
    return `${month} ${day}, ${year}`
  }
  return ""
}

export const formatDate = (
  value,
  formatting = { month: "short", day: "numeric", year: "numeric" }
) => {
  if (!value) return value
  return new Intl.DateTimeFormat("en-US", formatting).format(new Date(value))
}

export const formatDatetoISO = (date) => {
  if (date) {
    const d = new Date(date)
    const month = d.toLocaleString("default", { month: "short" })
    const day = d.getDate()
    const year = d.getFullYear()
    return `${year}-${month}-${day}`
  }
  return ""
}

// FOR EXAMPLE: 2021-07-04T00:00:00.000Z to July 4, 2021
export const formatDateForMeeting = (dateString) => {
  if (!dateString) {
    return "-"
  }

  const date = new Date(dateString)
  if (isNaN(date.getTime())) {
    return "-"
  }

  return date.toLocaleString("en-US", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    hour12: true
  })
}

// ** Returns short month of passed date
export const formatDateToMonthShort = (value, toTimeForCurrentDay = true) => {
  const date = new Date(value)
  let formatting = { month: "short", day: "numeric" }

  if (toTimeForCurrentDay && isToday(date)) {
    formatting = { hour: "numeric", minute: "numeric" }
  }

  return new Intl.DateTimeFormat("en-US", formatting).format(new Date(value))
}

export const getUserData = () =>
  JSON.parse(localStorage.getItem("userData") || null)

export const getUserRole = () => {
  if (localStorage.getItem("userData")) {
    const userData = JSON.parse(localStorage.getItem("userData"))
    return userData.role
  }
  return null
}

export const getDatafromToken = () => {
  if (
    fieldExists(getUserData(), "accessToken") &&
    !isNullObject(getUserData().accessToken)
  ) {
    return jwt.decode(getUserData().accessToken)
  }
  return null
}

export const getHomeRouteForLoggedInUser = () => {
  const userRole = getUserRole()
  if (!userRole) {
    localStorage.clear()
    return "/login"
  }
  return userRole === "user" ? DefaultRouteForUser : DefaultRouteForAdmin
}

export const getSideMenuItemsBasedOnRole = () => {
  const userRole = getUserRole()
  return SideMenuItems.filter((item) => {
    return item.role.includes(userRole)
  })
}

// get seeker_profile_id from token payload data (if exists) else return null value (if not exists)
export const getProfileId = () => {
  if (fieldExists(getUserData(), "id")) {
    return getUserData().id
  }
  return null
}

// if (

//   fieldExists(getUserData(), "accessToken") &&
//   !isNullObject(getUserData().accessToken) &&
//   jwt.decode(getUserData().accessToken).seeker_profile_id
// ) {
//   return jwt.decode(getUserData().accessToken).seeker_profile_id
// } else if (localStorage.getItem("seeker_profile_id")) {
//   return localStorage.getItem("seeker_profile_id")
// }
// return null
// }

// get company_profile_id from token payload data (if exists) else return null value (if not exists)
export const getCompanyProfileId = () => {
  if (
    fieldExists(getUserData(), "accessToken") &&
    !isNullObject(getUserData().accessToken) &&
    jwt.decode(getUserData().accessToken).company_id
  ) {
    return jwt.decode(getUserData().accessToken).company_id
  } else {
    return null
  }
}

export const createSeekerProfileId = (seekerProfileId) => {
  const seeker_profile_id = localStorage.getItem("seeker_profile_id")
  if (!seeker_profile_id) {
    localStorage.setItem("seeker_profile_id", seekerProfileId)
  }
}

// ** Get Job Categories from local storage
// export const getJobCategories = () => {
//   const jobCategories = localStorage.getItem("job_categories")
//   return !isNullObject(jobCategories) ? JSON.parse(jobCategories) : []
// }

// ** React Select Theme Colors
export const selectThemeColors = (theme) => ({
  ...theme,
  colors: {
    ...theme.colors,
    primary25: "#7367f01a", // for option hover bg-color
    primary: "#7367f0", // for selected option bg-color
    neutral10: "#7367f0", // for tags bg-color
    neutral20: "#ededed", // for input border-color
    neutral30: "#ededed" // for input hover border-color
  }
})

export const GetDateTimeRangeBasedOnDate = (date) => {
  const today = new Date()
  const jobPostDate = new Date(date)
  const diffTime = Math.abs(today - jobPostDate)
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  if (diffDays === 0) {
    return "Today"
  } else if (diffDays === 1) {
    return "Yesterday"
  }
  // if days are more than 365 then show years
  else if (diffDays > 365) {
    const diffYears = Math.ceil(diffDays / 365)
    return `${diffYears} years ago`
  }
  // if days are more than 28 or 30 or 31 then show months
  else if (diffDays > 30) {
    const diffMonths = Math.ceil(diffDays / 30)
    return `${diffMonths} months ago`
  }
  // if days are more than 7 then show weeks
  else if (diffDays > 7) {
    const diffWeeks = Math.ceil(diffDays / 7)
    return `${diffWeeks} weeks ago`
  }
  // if days are less than 7 then show days
  else {
    return `${diffDays} days ago`
  }
}

export const FormatDateInPostCard = (date, part) => {
  if (date) {
    const dateArray = [
      // uppercase all letters
      new Date(date)
        .toLocaleString("en-us", { weekday: "short" })
        .toUpperCase(),
      new Date(date).toLocaleString("en-us", { day: "numeric" })
    ]

    if (part === "day") {
      return dateArray[0]
    } else if (part === "date") {
      // if digit is single then add 0 before it
      if (dateArray[1].length === 1) {
        return `0${dateArray[1]}`
      } else {
        return dateArray[1]
      }
      // return dateArray[1]
    } else {
      return ""
    }
  } else {
    return ""
  }
}

export const getCompanyName = () => {
  return localStorage.getItem("company_name")
    ? localStorage.getItem("company_name")
    : ""
}

// remove slash from start
export const removeSlashFromStart = (str) => {
  return str.replace(/^\/+/, "")
}

export const convertSlugToTitle = (str) => {
  // validate if string is not empty
  if (!str) return ""
  return str.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())
}

export const getAIGenLimit = (key) => {
  return localStorage.getItem(key) ? localStorage.getItem(key) : 0
}

export const getCurrentPlan = () => {
  return localStorage.getItem(config.currentPlan)
    ? localStorage.getItem(config.currentPlan)
    : ""
}

export function JSONParse(str) {
  try {
    if (str === "") {
      return {}
    }
    return JSON.parse(str)
  } catch (e) {
    toast.error("JSON doesn't get parsed")
    return {}
  }
}

export function updatePersonalInfo(jsonObj, setFieldValue) {
  if (!isNullObject(jsonObj) && !isNullObject(jsonObj?.personal_info)) {
    const Names = splitName(jsonObj.personal_info.name)

    setFieldValue("first_name", Names.firstName)
    setFieldValue("middle_name", Names.middleName)
    setFieldValue("last_name", Names.lastName)
    setFieldValue("email", jsonObj.personal_info.email)
    setFieldValue("contact_number", jsonObj.personal_info.phone_number)
    setFieldValue("address", jsonObj.personal_info.address)
    setFieldValue("city", jsonObj.personal_info.city)
    setFieldValue("country", jsonObj.personal_info.country)
    setFieldValue("postal_code", jsonObj.personal_info.postal_code)
    setFieldValue("date_of_birth", jsonObj.personal_info.date_of_birth)

    // set links
    if (
      !isNullObject(jsonObj?.personal_info?.links) &&
      jsonObj?.personal_info?.links.length > 0
    ) {
      setFieldValue("links", jsonObj.personal_info.links)
    } else {
      setFieldValue("links", [
        {
          platform: "",
          url: ""
        }
      ])
    }
  }
}

export function updateWorkAndExperience(jsonObj, setFieldValue) {
  if (
    !isNullObject(jsonObj) &&
    !isNullObject(jsonObj?.work_and_experience) &&
    !isNullObject(jsonObj?.work_and_experience?.experience_details) &&
    jsonObj?.work_and_experience?.experience_details.length > 0
  ) {
    jsonObj.work_and_experience.experience_details.map((item, index) => {
      setFieldValue(
        `experience_details.${index}.job_title`,
        item.job_title || ""
      )
      setFieldValue(
        `experience_details.${index}.company_name`,
        item.company_name || ""
      )
      if (item?.start_date && validateDate(item.start_date)) {
        setFieldValue(
          `experience_details.${index}.start_date`,
          StringToDate(item.start_date) || ""
        )
      }

      if (item?.end_date && validateDate(item.end_date)) {
        setFieldValue(
          `experience_details.${index}.end_date`,
          StringToDate(item.end_date) || ""
        )
      }

      setFieldValue(
        `experience_details.${index}.is_current_job`,
        item.is_current_job
      )
    })
  }
  if (
    !isNullObject(jsonObj) &&
    !isNullObject(jsonObj?.work_and_experience) &&
    !isNullObject(jsonObj?.work_and_experience?.education_details) &&
    jsonObj?.work_and_experience?.education_details.length > 0
  ) {
    jsonObj.work_and_experience.education_details.map((item, index) => {
      setFieldValue(
        `education_details.${index}.certificate_degree_name`,
        item.certificate_degree_name || ""
      )
      setFieldValue(
        `education_details.${index}.institute_university_name`,
        item.institute_university_name || ""
      )
      setFieldValue(
        `education_details.${index}.field_of_study`,
        item.field_of_study || ""
      )

      if (validateDate(item.starting_date)) {
        setFieldValue(
          `education_details.${index}.starting_date`,
          StringToDate(item.starting_date) || ""
        )
      }

      if (validateDate(item.completion_date)) {
        setFieldValue(
          `education_details.${index}.completion_date`,
          StringToDate(item.completion_date) || ""
        )
      }
    })
  }

  if (
    !isNullObject(jsonObj) &&
    !isNullObject(jsonObj?.work_and_experience) &&
    !isNullObject(jsonObj?.work_and_experience?.seeker_skills) &&
    jsonObj?.work_and_experience?.seeker_skills.length > 0
  ) {
    jsonObj.work_and_experience.seeker_skills.map((item, index) => {
      setFieldValue(`seeker_skills.${index}.skill_name`, item.skill_name || "")
    })
  }
}

export const validateDate = (date) =>
  moment(date, "YYYY-MM-DDTHH:mm:ss.SSSZ", true).isValid()

export const StringToDate = (str) => {
  const date = moment(str, "YYYY-MM-DDTHH:mm:ss.SSSZ", true)
  return date.isValid() ? date.toDate() : null
}

export function MutationFactory(obj, tag, setFieldValues) {
  if (
    !isNullObject(obj) &&
    !isNullObject(obj?.categorizedData) &&
    obj?.categorizedData !== ""
  ) {
    if (tag === "personal_info") {
      // set resumeUrl
      updatePersonalInfo(JSONParse(obj.categorizedData), setFieldValues)
    } else if (tag === "work_and_experience") {
      updateWorkAndExperience(JSONParse(obj.categorizedData), setFieldValues)
    }
  }

  if (!isNullObject(obj) && !isNullObject(obj?.url) && obj?.url !== "") {
    setFieldValues("resume_url", obj.url)
  }
}

export function splitName(name) {
  const nameParts = name.trim().split(" ")
  const numParts = nameParts.length

  if (typeof name === "string" && name !== "") {
    if (numParts === 1) {
      return {
        firstName: name,
        middleName: "",
        lastName: ""
      }
    } else if (numParts === 2) {
      return {
        firstName: nameParts[0],
        middleName: "",
        lastName: nameParts[1]
      }
    } else if (numParts === 3) {
      return {
        firstName: nameParts[0],
        middleName: nameParts[1],
        lastName: nameParts[2]
      }
    }
  }

  return {
    firstName: "",
    middleName: "",
    lastName: ""
  }
}

export const getCompanyLogo = () => {
  return localStorage.getItem(config.companyLogo)
    ? localStorage.getItem(config.companyLogo)
    : ""
}

export const ChartProps = (score) => {
  return {
    type: "radialBar",
    series: [score],
    height: 30,
    width: 30,
    options: {
      grid: {
        show: false,
        padding: {
          left: -15,
          right: -15,
          top: -12,
          bottom: -15
        }
      },
      colors: [getChartColor(score)],
      plotOptions: {
        radialBar: {
          hollow: {
            size: "22%"
          },
          track: {
            background: "#e9ecef"
          },
          dataLabels: {
            showOn: "always",
            name: {
              show: false
            },
            value: {
              show: false
            }
          }
        }
      },
      stroke: {
        lineCap: "round"
      }
    }
  }
}

export const getChartColor = (score) => {
  if (score >= 0 && score <= 20) {
    return "#ff0000"
  } else if (score > 20 && score <= 40) {
    return "#ff6600"
  } else if (score > 40 && score <= 60) {
    return "#ffff00"
  } else if (score > 60 && score <= 80) {
    return "#99ff00"
  } else if (score > 80 && score <= 100) {
    return "#00ff00"
  } else {
    return "#5A8DEE"
  }
}

export const getInitials = (name) => {
  if (typeof name !== "string" || !name.length) {
    return ""
  }

  const parts = name.split(" ")
  if (parts.length === 3) {
    return `${parts[0]} ${parts[2]}`
  }
  return name
}

export const formatFileName = (fileName) =>  {
  // Take first 10 characters
  let newFileName = fileName.slice(0, 10);

  // Remove spaces and special characters
  newFileName = newFileName.replace(/[^a-zA-Z0-9]/g, "");

  // Add current date in Unix timestamp format
  const date = new Date();
  const timestamp = Math.floor(date.getTime() / 1000); // Unix timestamp is in seconds
  newFileName += "_" + timestamp;

  return newFileName;
}

export const encodeBase64String = (file) => {
  return new Promise((resolve, reject) => {
    // Create a new FileReader object
    const reader = new FileReader();

    // Set the onload function, which will be called once the file is read
    reader.onload = function(event) {
      // The result attribute contains the Base64 string
      const base64String = event.target.result;

      // Resolve the promise with the Base64 string
      resolve(base64String);
    };

    // Set the onerror function, which will be called if an error occurs while reading the file
    reader.onerror = function(error) {
      // Reject the promise with the error
      reject(error);
    };

    // Read the file as a Base64 string
    reader.readAsDataURL(file);
  });

}

export const isUserLoggedIn = () =>
  localStorage.getItem(config.storageTokenKeyName) !== null

export const isTokenExpired = () => {
  // const token = getDatafromToken()
  const expiredTime = localStorage.getItem("tokenExpireTime") || null

  if (expiredTime) {
    const currentTime = Date.now() / 1000
    return expiredTime < currentTime
  }
  return true
}
