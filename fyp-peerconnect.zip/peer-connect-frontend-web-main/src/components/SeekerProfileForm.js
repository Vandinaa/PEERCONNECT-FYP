import "@styles/react/libs/flatpickr/flatpickr.scss"

import * as Yup from "yup"
import * as userActions from "@src/store/common/users/actions"

import { Button, Col, Form, Input, Label, Row, Spinner } from "reactstrap"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState, useRef } from "react"

import Avatar from "@components/avatar"
import Flatpickr from "react-flatpickr"
import RadioButtonGroup from "./../components/RadioButtonGroup"
import Select from "react-select"
import Sidebar from "@components/sidebar"
import {
  encodeBase64String,
  fieldExists,
  getInitials,
  getProfileId,
  getUserData
} from "@src/utility/Utils"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"
import toast from "react-hot-toast"
import { X } from "react-feather"

const SeekerProfileForm = ({ open, toggleSidebar, data }) => {
  const { t } = useTranslation()
  const [submitted, setSubmitted] = useState(false)
  const dispatch = useDispatch()

  const alternateImage =
    require("@src/assets/images/avatars/avatar-blank.png").default

  // const inputFileRef = useRef(null)

  // const handleImageUpload = () => {
  //   inputFileRef.current.
  // }

  const {
    createdUpdatedLoading,
    updated,
    profileImageUrl,
    profileImageLoading
  } = useSelector((state) => state.usersReducer)

  const formik = useFormik({
    initialValues: {
      profile_image: {
        url: "",
        public_id: ""
      },
      full_name: "",
      date_of_birth: "",
      gender: "",
      contact_number: ""
    },
    validationSchema: Yup.object().shape({
      full_name: Yup.string().required("Required"),
      date_of_birth: Yup.string()
        .required("Required")
        .test(
          "dob",
          "Date of birth should be less than current date",
          function (value) {
            const { createError } = this
            const date = new Date(value)
            const currentDate = new Date()
            if (date > currentDate) {
              return createError({
                message: "Date of birth should be less than current date"
              })
            }
            return true
          }
        ),

      contact_number: Yup.string().required("Required"),
      gender: Yup.string().required("Required")
    }),

    onSubmit: (values) => {
      const body = {
        personalInfo: {
          fullName: values.full_name,
          phone: values.contact_number.toString(),
          dateOfBirth: values.date_of_birth,
          gender: values.gender,
          profile_image: values.profile_image
        }
      }

      dispatch(
        userActions.updateUserRequest({
          params: data.id,
          body
        })
      )
    }
  })

  const onChange = (e) => {
    if (e.target.files.length > 0) {
      const files = e.target.files
      const File1 = files[0]
      encodeBase64String(File1)
        .then((base64String) => {
          dispatch(
            userActions.uploadProfileImageRequest({
              image: base64String
            })
          )
        })
        .catch((err) => {
          toast.error("Error in uploading image , Try Again.")
        })
    }
  }

  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues
  } = formik

  const handleRemoveImage = () => {
    setFieldValue("profile_image", {
      url: "",
      public_id: ""
    })
  }

  useEffect(() => {
    if (profileImageUrl !== null) {
      setFieldValue("profile_image", profileImageUrl)
    }
  }, [profileImageUrl])

  useEffect(() => {
    if (updated) {
      dispatch(userActions.getLoggedInUserRequest(getProfileId()))
      dispatch(userActions.resetAllStatus())
      toggleSidebar()
    }
  }, [updated])

  useEffect(() => {
    setSubmitted(false)
    setValues({
      full_name: data?.personalInfo?.fullName || "",
      date_of_birth: data?.personalInfo?.dateOfBirth || "",
      gender: data?.personalInfo?.gender || "",
      contact_number: data?.personalInfo?.phone || "",
      profile_image: {
        url: data?.personalInfo?.profile_image?.url || "",
        public_id: data?.personalInfo?.profile_image?.public_id || ""
      }
    })
  }, [data])

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={t("Edit Account")}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3 sm:w-1/2"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmitted(true)
          handleSubmit()
        }}
      >
        <div className="d-flex justify-content-center align-items-center mb-1 text-capitalize">
          {!values.profile_image?.url ? (
            <Avatar
              color="light-primary"
              size="xl"
              content={getInitials(data?.personalInfo?.fullName)}
              initials
            />
          ) : (
            <div className="d-flex justify-content-center align-items-center">
              <div className="position-relative">
                <img
                  target="_blank"
                  alt="Profile Image Preview"
                  className="rounded me-50"
                  src={values.profile_image?.url || alternateImage}
                  onError={({ currentTarget }) => {
                    currentTarget.onerror = null // prevents looping
                    currentTarget.src = alternateImage
                  }}
                  height="50"
                />
                <X
                  className="position-absolute top-0 end-0 text-danger"
                  style={{ cursor: "pointer" }}
                  onClick={handleRemoveImage}
                />
              </div>
              {profileImageLoading && (
                <div className="position-absolute">
                  <Spinner color="dark" size="sm" />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="d-flex flex-wrap mt-2 justify-content-center align-items-center">
          <Button
            tag={Label}
            className="mb-75"
            size="sm"
            color="flat-primary"
            disabled={profileImageLoading}
          >
            Upload Profile Picture
            <Input
              type="file"
              onChange={onChange}
              hidden
              accept=".png, .jpg, .jpeg"
            />
          </Button>
        </div>

        <div className="mb-1">
          <Label className="form-label" for="full_name">
            {t("Full Name")}
          </Label>
          <Input
            type="text"
            id="full_name"
            name="full_name"
            placeholder="john doe"
            autoFocus
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.full_name}
          />
          {submitted && errors.full_name ? (
            <div className="error-message text-danger ">{errors.full_name}</div>
          ) : null}
        </div>

        <div className="mb-1">
          <Label className="form-label" for="date_of_birth">
            {t("Birth Date")}
          </Label>
          <Flatpickr
            value={values.date_of_birth}
            id="date-time-picker"
            placeholder="Select Date..."
            className="form-control"
            onChange={(date) => {
              setFieldValue("date_of_birth", date[0])
            }}
            onBlur={handleBlur}
          />

          {submitted && errors.date_of_birth ? (
            <div className="error-message text-danger">
              {errors.date_of_birth}
            </div>
          ) : null}
        </div>

        <div className="mb-1">
          <Label className="form-label" for="contact_number">
            {t("Phone")}
          </Label>
          <Input
            type="number"
            id="contact_number"
            name="contact_number"
            placeholder="********"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.contact_number}
          />
          {submitted && errors.contact_number ? (
            <div className="error-message text-danger">
              {errors.contact_number}
            </div>
          ) : null}
        </div>

        <div className="mb-1">
          <Label className="form-label" htmlFor="gender">
            {t("Gender")}
          </Label>
          <RadioButtonGroup
            name="gender"
            options={[
              { value: "male", label: t("Male") },
              { value: "female", label: t("Female") }
            ]}
            label="gender"
            onChange={handleChange}
            value={values.gender}
            onBlur={handleBlur}
          />
          {submitted && errors.gender ? (
            <div className="error-message text-danger">{errors.gender}</div>
          ) : null}
        </div>

        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={createdUpdatedLoading}
            // onClick={toggleSidebar}
          >
            {createdUpdatedLoading ? (
              <Spinner className="me-1" size="sm" />
            ) : null}
            {t("Save")}
          </Button>
          <Button color="secondary" outline onClick={toggleSidebar}>
            {t("Cancel")}
          </Button>
        </div>
      </Form>
    </Sidebar>
  )
}

export default SeekerProfileForm
