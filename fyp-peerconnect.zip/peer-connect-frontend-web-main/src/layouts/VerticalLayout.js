// ** Core Layout Import
// !Do not remove the Layout import
import Layout from "@layouts/VerticalLayout"
// ** React Imports
import { Outlet } from "react-router-dom"
// ** Menu Items Array
import { getSideMenuItemsBasedOnRole } from "@src/utility/Utils"
import navigation from "@src/navigation/vertical"

const VerticalLayout = (props) => {
  return (
    <Layout menuData={getSideMenuItemsBasedOnRole()} {...props}>
      <Outlet />
    </Layout>
  )
}
export default VerticalLayout
