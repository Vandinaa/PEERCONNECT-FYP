import { Card, CardBody, CardTitle, CardText, Alert } from "reactstrap"

import { Link, useNavigate } from "react-router-dom"
import { useEffect, useRef, useState } from "react"

import Wizard from "@components/wizard"

import "@styles/react/pages/page-authentication.scss"
import AccountDetails from "@src/components/registerform/AccountDetails"
import PersonalInfo from "@src/components/registerform/PersonalInfo"
import Education from "@src/components/registerform/Education"
import Experience from "@src/components/registerform/Experience"
import InterestAndCourse from "@src/components/registerform/InterestAndCourse"
import { useDispatch, useSelector } from "react-redux"
import { getAllCoursesRequest } from "@src/store/common/courses/actions"
import { isObjEmpty } from "@src/utility/Utils"
import { getAllInterestRequest } from "@src/store/common/interests/actions"

const RegisterBasic = () => {
  const navigate = useNavigate()

  const dispatch = useDispatch()

  useEffect(() => {
    if (isRegistered) {
      navigate("/verify-email?email=" + registered.email)
    }
  }, [isRegistered])

  const {
    data: registered,
    isRegistered,
    isEmailTaken,
    error,
    loading
  } = useSelector((state) => state.registerReducer)

  const { courses } = useSelector((state) => state.courseReducer)

  const { interests } = useSelector((state) => state.interestReducer)
  const ref = useRef(null)

  const [stepper, setStepper] = useState(null)
  const [data, setData] = useState({})
  const [step, setStep] = useState(1)
  const [body, setBody] = useState({})

  const steps = [
    {
      id: "account-details",
      title: "Account Details",
      subtitle: "Enter Your Account Details.",
      content: (
        <AccountDetails stepper={stepper} setData={setData} setStep={setStep} />
      )
    },
    {
      id: "personal-info",
      title: "Personal Info",
      subtitle: "Add Personal Info",
      content: (
        <PersonalInfo stepper={stepper} setData={setData} setStep={setStep} />
      )
    },
    {
      id: "education",
      title: "Education",
      subtitle: "Add Education",
      content: (
        <Education stepper={stepper} setData={setData} setStep={setStep} />
      )
    },
    {
      id: "experience",
      title: "Experience",
      subtitle: "Add Experience",
      content: (
        <Experience stepper={stepper} setData={setData} setStep={setStep} />
      )
    },
    {
      id: "interest",
      title: "Interest & Courses",
      subtitle: "Add Interests & Courses",
      content: (
        <InterestAndCourse
          stepper={stepper}
          setData={setData}
          setStep={setStep}
          data={body}
        />
      )
    }
  ]

  useEffect(() => {
    if (!isObjEmpty(registered)) {
      navigate("/verify-email")
    }
  }, [registered])

  useEffect(() => {
    if (isObjEmpty(courses)) {
      dispatch(
        getAllCoursesRequest({
          perPage: 1000,
          page: 1
        })
      )

    }

    if (isObjEmpty(interests)) {
      dispatch(
        getAllInterestRequest({
          perPage: 1000,
          page: 1
        })
      )
    }
    
  }, [dispatch])

  useEffect(() => {
    if (step === 1 || step === 2 || step === 3 || step === 4) {
      setBody({ ...body, ...data })
    }
  }, [data])

  useEffect(() => {
    if (isEmailTaken) {
      while (stepper._currentIndex !== 0) {
        stepper.previous()
      }
    }
  }, [isEmailTaken, stepper])

  return (
    <div className="auth-wrapper auth-basic">
      <div className="auth-inner my-2">
        <Card className="mb-0">
          <CardBody>
            <Link
              className="brand-logo"
              to="/"
              onClick={(e) => e.preventDefault()}
            >
              <svg viewBox="0 0 139 95" version="1.1" height="28">
                <defs>
                  <linearGradient
                    x1="100%"
                    y1="10.5120544%"
                    x2="50%"
                    y2="89.4879456%"
                    id="linearGradient-1"
                  >
                    <stop stopColor="#000000" offset="0%"></stop>
                    <stop stopColor="#FFFFFF" offset="100%"></stop>
                  </linearGradient>
                  <linearGradient
                    x1="64.0437835%"
                    y1="46.3276743%"
                    x2="37.373316%"
                    y2="100%"
                    id="linearGradient-2"
                  >
                    <stop
                      stopColor="#EEEEEE"
                      stopOpacity="0"
                      offset="0%"
                    ></stop>
                    <stop stopColor="#FFFFFF" offset="100%"></stop>
                  </linearGradient>
                </defs>
                <g
                  id="Page-1"
                  stroke="none"
                  strokeWidth="1"
                  fill="none"
                  fillRule="evenodd"
                >
                  <g
                    id="Artboard"
                    transform="translate(-400.000000, -178.000000)"
                  >
                    <g id="Group" transform="translate(400.000000, 178.000000)">
                      <path
                        d="M-5.68434189e-14,2.84217094e-14 L39.1816085,2.84217094e-14 L69.3453773,32.2519224 L101.428699,2.84217094e-14 L138.784583,2.84217094e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L6.71554594,44.4188507 C2.46876683,39.9813776 0.345377275,35.1089553 0.345377275,29.8015838 C0.345377275,24.4942122 0.230251516,14.560351 -5.68434189e-14,2.84217094e-14 Z"
                        id="Path"
                        className="text-primary"
                        style={{ fill: "currentColor" }}
                      ></path>
                      <path
                        d="M69.3453773,32.2519224 L101.428699,1.42108547e-14 L138.784583,1.42108547e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L32.8435758,70.5039241 L69.3453773,32.2519224 Z"
                        id="Path"
                        fill="url(#linearGradient-1)"
                        opacity="0.2"
                      ></path>
                      <polygon
                        id="Path-2"
                        fill="#000000"
                        opacity="0.049999997"
                        points="69.3922914 32.4202615 32.8435758 70.5039241 54.0490008 16.1851325"
                      ></polygon>
                      <polygon
                        id="Path-2"
                        fill="#000000"
                        opacity="0.099999994"
                        points="69.3922914 32.4202615 32.8435758 70.5039241 58.3683556 20.7402338"
                      ></polygon>
                      <polygon
                        id="Path-3"
                        fill="url(#linearGradient-2)"
                        opacity="0.099999994"
                        points="101.428699 0 83.0667527 94.1480575 130.378721 47.0740288"
                      ></polygon>
                    </g>
                  </g>
                </g>
              </svg>
              <h2 className="brand-text text-primary ms-1">PeerConnect</h2>
            </Link>
            <CardTitle tag="h4" className="mb-1">
              Adventure starts here 🚀
            </CardTitle>
            <CardText className="mb-2">
              Make your app management easy and fun!
            </CardText>
            {isEmailTaken && (
              <Alert color="danger">
                <div className="alert-body font-small-2 mt-2">
                  <p>
                    <small className="me-50">
                      <span className="fw-bold">
                        Please enter a different email address as this email is
                        already taken.
                      </span>
                    </small>
                  </p>
                </div>
              </Alert>
            )}

            <Wizard instance={(el) => setStepper(el)} ref={ref} steps={steps} />
            <p className="text-center mt-2">
              <span className="me-25">Already have an account?</span>
              <Link to="/login">
                <span>Sign in instead</span>
              </Link>
            </p>
          </CardBody>
        </Card>
      </div>
    </div>
  )
}

export default RegisterBasic
