import * as loginActions from "@src/store/common/login/actions"

import {
  CheckSquare,
  CreditCard,
  HelpCircle,
  Mail,
  MessageSquare,
  Power,
  Settings,
  User
} from "react-feather"
import {
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  UncontrolledDropdown
} from "reactstrap"
import { Link, useNavigate } from "react-router-dom"
import {
  getCompanyLogo,
  getDatafromToken,
  getInitials,
  getSeekerProfileId,
  getUserData,
  getUserRole
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import Avatar from "@components/avatar"
import MySwal from "sweetalert2"
import defaultAvatar from "@src/assets/images/portrait/small/no_img.jpg"
import useJwt from "@src/auth/jwt/useJwt"
import { useTranslation } from "react-i18next"
import { useEffect, useState } from "react"

const config = useJwt.jwtConfig

const alternateImage =
  require("@src/assets/images/avatars/avatar-blank.png").default

const UserDropdown = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const [name, setName] = useState(getUserData()?.personalInfo?.fullName ?? "")
  const [profileImage, setProfileImage] = useState(
    getUserData()?.personalInfo?.profile_image?.url ?? ""
  )

  const handleLogout = () => {
    dispatch(loginActions.logout())
  }

  const { updated } = useSelector((state) => state.usersReducer)

  const handleProfile = () => {
    navigate("/profile")
  }

  useEffect(() => {
    if (updated) {
      setName(getUserData().personalInfo?.fullName)
      setProfileImage(getUserData().personalInfo?.profile_image?.url)
    }
  }, [updated])

  return (
    <UncontrolledDropdown tag="li" className="dropdown-user nav-item">
      <DropdownToggle
        href="/"
        tag="a"
        className="nav-link dropdown-user-link"
        onClick={(e) => e.preventDefault()}
      >
        <div className="user-nav d-sm-flex d-none">
          <span className="user-name fw-bold">{name ?? ""}</span>
          <span className="user-status text-capitalize">
            {getUserRole() ?? ""}
          </span>
        </div>
        {profileImage != "" ? (
          <div className="d-flex justify-content-center align-items-center">
            <div className="position-relative">
              <img
                target="_blank"
                alt="Profile Image Preview"
                className="rounded me-50"
                src={profileImage || alternateImage}
                onError={({ currentTarget }) => {
                  currentTarget.onerror = null // prevents looping
                  currentTarget.src = alternateImage
                }}
                height="50"
                width="50"
                style={{
                  objectFit: "cover",
                  objectPosition: "center",
                  borderRadius: "50%"
                }}
              />
            </div>
          </div>
        ) : (
          <div className="text-capitalize">
            <Avatar
              color="light-primary"
              content={getInitials(name)}
              initials
              status="online"
            />
          </div>
        )}
      </DropdownToggle>
      <DropdownMenu end>
        <DropdownItem
          // tag={Link}
          // to="/profile"
          onClick={handleProfile}
        >
          <User size={14} className="me-75" />
          <span className="align-middle">{t("Profile")}</span>
        </DropdownItem>
        {/*
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <Mail size={14} className="me-75" />
          <span className="align-middle">Inbox</span>
        </DropdownItem>
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <CheckSquare size={14} className="me-75" />
          <span className="align-middle">Tasks</span>
        </DropdownItem>
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <MessageSquare size={14} className="me-75" />
          <span className="align-middle">Chats</span>
        </DropdownItem>
        <DropdownItem divider />
        <DropdownItem
          tag={Link}
          to="/pages/"
          onClick={(e) => e.preventDefault()}
        >
          <Settings size={14} className="me-75" />
          <span className="align-middle">Settings</span>
        </DropdownItem>
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <CreditCard size={14} className="me-75" />
          <span className="align-middle">Pricing</span>
        </DropdownItem>
        <DropdownItem tag={Link} to="/" onClick={(e) => e.preventDefault()}>
          <HelpCircle size={14} className="me-75" />
          <span className="align-middle">FAQ</span>
        </DropdownItem>
        */}
        <DropdownItem tag={Link} to="/login" onClick={handleLogout}>
          <Power size={14} className="me-75" />
          <span className="align-middle">{t("Logout")}</span>
        </DropdownItem>
      </DropdownMenu>
    </UncontrolledDropdown>
  )
}

export default UserDropdown
