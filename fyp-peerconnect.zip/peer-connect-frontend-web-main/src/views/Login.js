// ** Styles
import "@styles/react/pages/page-authentication.scss"

import * as yup from "yup"
import { yupResolver } from "@hookform/resolvers/yup"
import {
  Alert,
  Button,
  CardText,
  CardTitle,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
  Spinner
} from "reactstrap"

import { Controller, useForm } from "react-hook-form"
import { Link, useNavigate } from "react-router-dom"
import { fieldExists, isNullObject } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import InputPasswordToggle from "@components/input-password-toggle"
import Swal from "sweetalert2"
import { getHomeRouteForLoggedInUser } from "@utils"
import { clearError, loginRequest } from "@src/store/common/login/actions"
import toast from "react-hot-toast"
import { useEffect } from "react"
import { useSkin } from "@hooks/useSkin"
import withReactContent from "sweetalert2-react-content"

const defaultValues = {
  loginEmail: "",
  password: ""
}

const Login = () => {
  // ** Hooks
  const { skin } = useSkin()
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const MySwal = withReactContent(Swal)

  const loginStore = useSelector((state) => state.loginReducer)

  const handleUnauthorizedUser = () => {
    return MySwal.fire({
      text: "Email has not been verified. Please check your inbox.",
      icon: "error",
      confirmButtonText: "Next",
      customClass: {
        confirmButton: "btn btn-primary"
      },
      buttonsStyling: true
    }).then(() => {
      navigate("/verify-email")
    })
  }

  useEffect(() => {
    if (fieldExists(loginStore, "error") && !isNullObject(loginStore.error)) {
      if (
        loginStore.error?.status === 401 &&
        loginStore.error?.message === "User is not verified"
      ) {
        toast.error("Email has not been verified. Please check your inbox.")
        dispatch(clearError())
        navigate("/verify-email?email=" + loginStore.error?.email)
      }
    }
  }, [loginStore.error])

  useEffect(() => {
    if (
      fieldExists(loginStore, "accessToken") &&
      !isNullObject(loginStore.accessToken)
    ) {
      navigate(getHomeRouteForLoggedInUser())
    }
  }, [loginStore])

  const SignInSchema = yup.object().shape({
    loginEmail: yup.string().required("Email is required"),
    password: yup
      .string()
      .required("Please Enter your password")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        "Must Contain at least 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
      )
  })

  const {
    control,
    setError,
    handleSubmit,
    formState: { errors }
  } = useForm({ defaultValues, resolver: yupResolver(SignInSchema) })
  const illustration = skin === "dark" ? "login-v2-dark.svg" : "login-v2.svg",
    source = require(`@src/assets/images/pages/${illustration}`).default

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field.length > 0)) {
      dispatch(
        loginRequest({
          email: data.loginEmail,
          password: data.password
        })
      )
    } else {
      for (const key in data) {
        if (data[key].length === 0) {
          setError(key, {
            type: "manual"
          })
        }
      }
    }
  }

  return (
    <div className="auth-wrapper auth-cover">
      <Row className="auth-inner m-0">
        <Link
          className="brand-logo flex justify-content-start"
          to="/"
          onClick={(e) => e.preventDefault()}
        >
          <h2 className="brand-text text-primary ms-1">
            PeerConnect - Learn & Fun
          </h2>
        </Link>
        <Col className="d-none d-lg-flex align-items-center p-5" lg="8" sm="12">
          <div className="w-100 d-lg-flex align-items-center justify-content-center px-5">
            <img className="img-fluid" src={source} alt="Login Cover" />
          </div>
        </Col>
        <Col
          className="d-flex align-items-center auth-bg px-2 p-lg-5"
          lg="4"
          sm="12"
        >
          <Col className="px-xl-2 mx-auto" sm="8" md="6" lg="12">
            <CardTitle tag="h2" className="fw-bold mb-1">
              Welcome to PeerConnect! 👋
            </CardTitle>
            <CardText className="mb-2">
              Please sign-in to your account and start the adventure
            </CardText>

            <Form
              className="auth-login-form mt-2"
              onSubmit={handleSubmit(onSubmit)}
            >
              <div className="mb-1">
                <Label className="form-label" for="login-email">
                  Email
                </Label>
                <Controller
                  id="loginEmail"
                  name="loginEmail"
                  control={control}
                  render={({ field }) => (
                    <Input
                      autoFocus
                      type="email"
                      placeholder="john@example.com"
                      invalid={errors.loginEmail && true}
                      {...field}
                    />
                  )}
                />
                {errors.loginEmail && (
                  <FormFeedback>{errors.loginEmail.message}</FormFeedback>
                )}
              </div>
              <div className="mb-1">
                <div className="d-flex justify-content-between">
                  <Label className="form-label" for="login-password">
                    Password
                  </Label>
                </div>
                <Controller
                  id="password"
                  name="password"
                  control={control}
                  render={({ field }) => (
                    <InputPasswordToggle
                      className="input-group-merge"
                      invalid={errors.password && true}
                      {...field}
                    />
                  )}
                />
                {errors.password && (
                  <FormFeedback>{errors.password.message}</FormFeedback>
                )}

                <Link className="float-end mb-2" to="/forgot-password">
                  <small>Forgot Password?</small>
                </Link>
              </div>
              <Button
                type="submit"
                color="primary"
                block
                disabled={loginStore.loading}
              >
                {loginStore.loading ? (
                  <Spinner className="me-1" size="sm" />
                ) : null}
                Sign in
              </Button>
            </Form>
            {!isNullObject(loginStore.error) ? (
              <Alert color="danger">
                <div className="alert-body font-small-2 mt-2">
                  <p>
                    <small className="me-50">
                      <span className="fw-bold">
                        {loginStore?.error?.message}
                      </span>
                    </small>
                  </p>
                </div>
              </Alert>
            ) : null}

            <p className="text-center mt-2">
              <span className="me-25">New on our platform?</span>
              <Link to="/register">
                <span>Create an account</span>
              </Link>
            </p>
          </Col>
        </Col>
      </Row>
    </div>
  )
}

export default Login
