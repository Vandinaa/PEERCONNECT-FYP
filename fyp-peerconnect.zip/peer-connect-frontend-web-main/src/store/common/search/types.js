import { createActionTypes } from "@src/utility"

export const SEARCH_TYPES = createActionTypes("SEARCH", [
  "GET_LIST_OF_SEARCH_REQUEST",
  "GET_LIST_OF_SEARCH_SUCCESS",
  "GET_LIST_OF_SEARCH_FAILURE",
  "CLEAR_SEARCH_LIST"
])
