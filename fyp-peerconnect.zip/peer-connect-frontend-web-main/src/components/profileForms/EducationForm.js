import "@styles/react/libs/flatpickr/flatpickr.scss"

import * as Yup from "yup"
import * as userActions from "@src/store/common/users/actions"

import { selectThemeColors } from "@utils"
import Select from "react-select"

import {
  Alert,
  Button,
  Col,
  Form,
  Input,
  Label,
  Row,
  Spinner
} from "reactstrap"
import { formatDatetoISO, isNullObject } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Flatpickr from "react-flatpickr"
import Sidebar from "@components/sidebar"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"

const EducationForm = ({ open, toggleSidebar, formType, data }) => {
  const { t } = useTranslation()
  const [isSubmit, setSubmit] = useState(false)

  const dispatch = useDispatch()

  const { loading, error } = useSelector((state) => state.usersReducer)

  const GradeSystemOptions = [
    { value: "gpa_4", label: "GPA 4" },
    { value: "gpa_5", label: "GPA 5" },
    { value: "percentage", label: "Percentage" }
  ]

  const initialValues = {
    degree: "",
    schoolName: "",
    startDate: "",
    endDate: "",
    fieldOfStudy: "",
    grade: 0,
    isCurrentlyStudying: false,
    gradeSystem: "gpa_4"
  }

  const validationSchema = Yup.object().shape({
    schoolName: Yup.string().required(t("Institute is required")),
    degree: Yup.string().required(t("Certificate/Degree Name is required")),
    fieldOfStudy: Yup.string().required(t("Field Of Study is required")),
    grade: Yup.string().required(t("CGPA is required")),
    startDate: Yup.string().required(t("Starting date is required")),
    isCurrentlyStudying: Yup.boolean(),
    gradeSystem: Yup.string().required(t("Grade System is required")),
    endDate: Yup.date().when("isCurrentlyStudying", {
      is: false,
      then: Yup.date().required("Required")
    })
  })

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      setSubmit(false)
      const body = {
        degree: values.degree,
        schoolName: values.schoolName,
        startDate: formatDatetoISO(values.startDate),
        endDate: values.isCurrentlyStudying
          ? null
          : formatDatetoISO(values.endDate),
        isCurrentlyStudying: values.isCurrentlyStudying,
        fieldOfStudy: values.fieldOfStudy,
        grade: values.grade,
        gradeSystem: values.gradeSystem
      }

      if (formType === "edit" && values !== data) {
        dispatch(
          userActions.updateEducationRequest({
            params: data._id,
            body
          })
        )
      } else if (formType === "add") {
        dispatch(userActions.addEducationRequest(body))
      }
    }
  })

  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue
  } = formik

  useEffect(() => {
    setSubmit(false)
    if (formType === "edit" && !isNullObject(data)) {
      setFieldValue("degree", data.degree)
      setFieldValue("schoolName", data.schoolName)
      setFieldValue("startDate", data.startDate)
      setFieldValue("endDate", data.endDate ? data.endDate : "")
      setFieldValue("fieldOfStudy", data.fieldOfStudy)
      setFieldValue("grade", data.grade)
      setFieldValue("gradeSystem", data.gradeSystem)
      setFieldValue("isCurrentlyStudying", data.isCurrentlyStudying)
    } else {
      setFieldValue("degree", "")
      setFieldValue("schoolName", "")
      setFieldValue("startDate", "")
      setFieldValue("endDate", "")
      setFieldValue("grade", "")
      setFieldValue("fieldOfStudy", "")
      setFieldValue("gradeSystem", "gpa_4")
      setFieldValue("isCurrentlyStudying", false)
    }
  }, [data])

  const handleDateChange = (date, name) => {
    setFieldValue(name, date[0])
  }

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={t("Add Education")}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          handleSubmit()
          setSubmit(true)
        }}
      >
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Institute")}*
          </Label>
          <Input
            type="text"
            name="schoolName"
            onChange={handleChange}
            value={values.schoolName}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder="Enter Institute Name"
          />
          {isSubmit && errors.schoolName && (
            <div style={{ color: "red" }}>{errors.schoolName}</div>
          )}
        </div>
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Certificate/Degree Name")}*
          </Label>
          <Input
            type="text"
            name="degree"
            onChange={handleChange}
            value={values.degree}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder="Enter Certificate/Degree Name"
          />
          {isSubmit && errors.degree && (
            <div style={{ color: "red" }}>{errors.degree}</div>
          )}
        </div>
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Field Of Study")}*
          </Label>
          <Input
            type="text"
            name="fieldOfStudy"
            onChange={handleChange}
            value={values.fieldOfStudy}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder="Enter Field Of Study"
          />
          {isSubmit && errors.fieldOfStudy && (
            <div style={{ color: "red" }}>{errors.fieldOfStudy}</div>
          )}
        </div>

        <div className="mb-1">
          <Label for="invoice-subject" className="form-label">
            {t("CGPA / Percentage")}
          </Label>
          <Input
            type="number"
            name="grade"
            onChange={handleChange}
            value={values.grade}
            onBlur={handleBlur}
            id="invoice-subject"
            placeholder="Enter CGPA / Percentage"
          />
          {isSubmit && errors.grade && (
            <div style={{ color: "red" }}>{errors.grade}</div>
          )}
        </div>

        <div className="mb-1">
          <Label for="invoice-subject" className="form-label">
            {t("Grade System")}
          </Label>
          <Select
            name="gradeSystem"
            onChange={(e) => {
              setFieldValue("gradeSystem", e.value)
            }}
            onBlur={handleBlur}
            value={GradeSystemOptions.find(
              (obj) => obj.value === values.gradeSystem || ""
            )}
            theme={selectThemeColors}
            className="react-select"
            classNamePrefix="select"
            options={GradeSystemOptions}
            isClearable={false}
            placeholder="Select Grade System"
            bsSize="sm"
          />
          {isSubmit && errors.gradeSystem && (
            <div className="text-danger">{errors.gradeSystem}</div>
          )}
        </div>

        <div className="mb-1">
          <div className="form-check form-check-inline">
            <Input
              className="form-check-input"
              type="checkbox"
              id="basic-cb-unchecked"
              name="isCurrentlyStudying"
              onChange={handleChange}
              checked={values.isCurrentlyStudying}
              onBlur={handleBlur}
            />
            <Label for="basic-cb-unchecked" className="form-check-label">
              {t("Is Currently Studying")}
            </Label>
          </div>
        </div>

        <Row>
          <Col md="6" sm="12" className="mb-1">
            <Label className="form-label" for="date-time-picker">
              {t("Start Date")}
            </Label>
            <Flatpickr
              id="date-time-picker"
              onBlur={handleBlur}
              className="form-control"
              placeholder="Select Date"
              value={values.startDate}
              onChange={(date) => {
                handleDateChange(date, "startDate")
              }}
            />
            {isSubmit && errors.startDate && (
              <div style={{ color: "red" }}>{errors.startDate}</div>
            )}
          </Col>

          <Col md="6" sm="12" className="mb-1">
            <Label className="form-label" for="lastNameMulti">
              {t("End Date")}
            </Label>
            <Flatpickr
              id="date-time-picker"
              onBlur={handleBlur}
              disabled={values.isCurrentlyStudying}
              placeholder="Select Date"
              className="form-control"
              value={values.endDate}
              onChange={(date) => {
                handleDateChange(date, "endDate")
              }}
            />
            {isSubmit && errors.endDate && (
              <div style={{ color: "red" }}>{errors.endDate}</div>
            )}
          </Col>
        </Row>

        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={loading}
            // onClick={toggleSidebar}
          >
            {loading ? <Spinner className="me-1" size="sm" /> : null}
            {formType === t("edit") ? t("Update") : t("Add")}
          </Button>
          <Button color="secondary" outline onClick={toggleSidebar}>
            {t("Cancel")}
          </Button>
        </div>
      </Form>
      {loading ? (
        <Alert color="success">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">Updating...</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
      {error ? (
        <Alert color="danger">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">{error?.message}</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
    </Sidebar>
  )
}

export default EducationForm
