import "@styles/react/libs/flatpickr/flatpickr.scss"
import "@styles/react/libs/tables/react-dataTable-component.scss"

import * as interestActions from "@src/store/common/interests/actions"

import {
  Button,
  Card,
  CardHeader,
  CardTitle,
  Col,
  Row,
} from "reactstrap"
import { ChevronDown, Edit, Plus, Trash } from "react-feather"
import { Fragment, useEffect, useState } from "react"
import {
  fieldExists,
  isNullObject,
  isObjEmpty
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import AddInterestForm from "@src/components/AddInterestForm"
import DataTable from "react-data-table-component"
import ReactPaginate from "react-paginate"
import Select from "react-select"
import Swal from "sweetalert2"
import { categoriesOptions, rowsItemsOptions } from "@src/utility/Options"
import { selectThemeColors } from "@utils"
import toast from "react-hot-toast"
import { useTranslation } from "react-i18next"
import withReactContent from "sweetalert2-react-content"

const MySwal = withReactContent(Swal)

const Interest = () => {
  const { t } = useTranslation()
 
  const [rowsPerPage, setRowsPerPage] = useState({
    value: 20,
    label: "20"
  })

  const [currentPage, setCurrentPage] = useState(0)
  const [data, setData] = useState([])

  const [sendSidebarOpen, setSendSidebarOpen] = useState({
    open: false,
    data: {},
    formType: ""
  })

  const toggleSendSidebar = () =>
    setSendSidebarOpen({
      open: !sendSidebarOpen.open,
      data: {},
      formType: ""
    })

  const dispatch = useDispatch()

  const { interests, deleted, updated, created } = useSelector(
    (state) => state.interestReducer
  )

  useEffect(() => {
    if (created || updated || deleted) {
      sendSidebarOpen.open = false
      toast.success(
        created
          ? t("Interest Created Successfully")
          : updated
          ? t("Interest Updated Successfully")
          : t("Interest Deleted Successfully")
      )
      dispatch(interestActions.getAllInterestRequest(
        {
          perPage: rowsPerPage.value,
          page: currentPage + 1
        }
      ))
    }
  }, [created, updated, deleted])

  const handleConfirmCancel = (data) => {
    return MySwal.fire({
      title: t("Are you sure?"),
      text: t("You won't be able to revert this!"),
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: t("Yes, delete it!"),
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(
          interestActions.deleteInterestRequest({
            params: data.id
          })
        )
      }
    })
  }

  const ColumnsHeader = [
    {

      name: t("INTEREST NAME"),
      minWidth: "250px",
      center: true,
      cell : (row) => {
        return (
          <div className="fw-bolder text-capitalize text-primary">
            <span>{row.name}</span>
          </div>
        )
      }
    },
    {
      name: t("CATEGORY"),
      minWidth: "250px",
      selector: (row) => row.category
    },
    {
      name: t("ACTIONS"),
      minWidth: "200px",

      cell: (row) => {
        return (
          <div className="d-flex justify-content-center">
            <Button
              size="sm"
              color="primary"
              outline
              className="btn btn-icon me-1"
              onClick={() => {
                setSendSidebarOpen({
                  open: true,
                  data: row,
                  formType: "edit"
                })
              }}
            >
              <Edit className="font-medium-2" />
              <span className="align-middle ms-50">{t("Edit")}</span>
            </Button>
            <Button
              size="sm"
              color="danger"
              outline
              className="btn btn-icon"
              onClick={() => {
                handleConfirmCancel(row)
              }}
            >
              <Trash className="font-medium-2" />
              <span className="align-middle ms-50">{t("Delete")}</span>
            </Button>
          </div>
        )
      }
    }
  ]

  useEffect(() => {
    setCurrentPage(0)
    if (isObjEmpty(!isNullObject(interests))) {
      dispatch(
        interestActions.getAllInterestRequest({
          perPage: rowsPerPage.value,
          page: currentPage + 1
        })
      )
    }
  }, [dispatch])

  useEffect(() => {
    if (fieldExists(interests, "results") && interests.results.length > 0) {
      const a = interests.results.map((item, index) => {
        return {
          id: item.id,
          name: item.interestName,
          category: categoriesOptions.find(
            (category) => category.value === item.category
          ).label || "",
          categoryValue: item.category

        }
      })
      setData(a)
    } else {
      setData([])
    }
    if (!isNullObject(interests)) {
      setCurrentPage(interests.page - 1)
    }
  }, [interests])

  const dataToRender = () => {
    return data
  }


  const handlePagination = (page) => {
    dispatch(
      interestActions.getAllInterestRequest({
        page: page.selected + 1,
        perPage: rowsPerPage
      })
    )
    setCurrentPage(page.selected)
  }

  // ** Function to handle per page
  const handlePerPage = (e) => {
    dispatch(
      interestActions.getAllInterestRequest({
        perPage: e.value,
        page: 1
      })
    )
    setCurrentPage(0)
    setRowsPerPage({
      value: e.value,
      label: e.label
    })
  }

  const CustomPagination = () => (
    <ReactPaginate
      nextLabel=""
      breakLabel="..."
      previousLabel=""
      pageRangeDisplayed={2}
      forcePage={currentPage}
      marginPagesDisplayed={2}
      activeClassName="active"
      pageClassName="page-item"
      breakClassName="page-item"
      nextLinkClassName="page-link"
      pageLinkClassName="page-link"
      breakLinkClassName="page-link"
      previousLinkClassName="page-link"
      nextClassName="page-item next-item"
      previousClassName="page-item prev-item"
      pageCount={
        interests?.totalPages ? interests.totalPages : 1
      }
      onPageChange={(page) => handlePagination(page)}
      containerClassName="pagination react-paginate separated-pagination pagination-sm justify-content-end pe-1 mt-1"
    />
  )

  return (
    <Fragment>
      <Card>
        <Row>
          <Col sm="12">
          
            <CardHeader className="flex-md-row flex-column align-md-items-center align-items-start border-bottom">
              <CardTitle tag="h4">{t("Interests")}</CardTitle>
              <div className="d-flex mt-md-0 mt-1">
                <Button
                  className="ms-2"
                  color="primary"
                  onClick={() => {
                    setSendSidebarOpen({
                      open: true,
                      data: "",
                      formType: "add"
                    })
                  }}
                >
                  <Plus size={15} />
                  <span className="align-middle ms-50">{t("Add Record")}</span>
                </Button>
              </div>
            </CardHeader>
            <div className="react-dataTable">
              <DataTable
                noHeader
                columns={ColumnsHeader}
                paginationPerPage={rowsPerPage}
                className="react-dataTable"
                sortIcon={<ChevronDown size={10} />}
                paginationDefaultPage={currentPage + 1}
                // paginationComponent={CustomPagination}
                data={dataToRender()}
              />
            </div>
            <CustomPagination />
          </Col>
          <Col lg="2" md="3" sm="1">
            <div className="ps-2 pb-2 d-flex align-items-center">
              <Select
                menuPlacement="top"
                theme={selectThemeColors}
                type="select"
                className="react-select"
                classNamePrefix="select"
                id="sort-select"
                options={rowsItemsOptions}
                isClearable={false}
                value={rowsPerPage}
                onChange={(e) => {
                  handlePerPage(e)
                }}
              />
            </div>
          </Col>
        </Row>
      </Card>
      <AddInterestForm
        toggleSidebar={toggleSendSidebar}
        open={sendSidebarOpen.open}
        formType={sendSidebarOpen.formType}
        data={sendSidebarOpen.data}
      />
    </Fragment>
  )
}
export default Interest
