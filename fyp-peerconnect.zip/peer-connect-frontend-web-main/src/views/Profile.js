import { getAllCoursesRequest } from "@src/store/common/courses/actions"
import { getAllInterestRequest } from "@src/store/common/interests/actions"
import * as userActions from "@src/store/common/users/actions"
import * as loginActions from "@src/store/common/login/actions"

import { Bell, Bookmark, Lock, User } from "react-feather"
import {
  Button,
  Card,
  CardBody,
  CardText,
  Col,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane
} from "reactstrap"
import { Fragment, useEffect, useState } from "react"
import {
  fieldExists,
  formatDateToShow,
  getInitials,
  getProfileId,
  getSeekerProfileId,
  isObjEmpty
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"

import Avatar from "@src/@core/components/avatar"
import ChangePasswordCard from "@src/components/profileCards/ChangePasswordCard"
import EducationCard from "@src/components/profileCards/EducationCard"
import ExperienceCard from "@src/components/profileCards/ExperienceCard"
import ProfileForm from "../components/SeekerProfileForm"
import SkillsCard from "@src/components/profileCards/SkillsCard"
import { useTranslation } from "react-i18next"
import Swal from "sweetalert2"
import withReactContent from "sweetalert2-react-content"
import { useNavigate } from "react-router-dom"

const alternateImage =
  require("@src/assets/images/avatars/avatar-blank.png").default

const MySwal = withReactContent(Swal)

const Profile = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [sendSidebarOpen, setSendSidebarOpen] = useState(false)
  const [UserId, setUserId] = useState(
    new URLSearchParams(window.location.search).get("id") || getProfileId()
  )

  const toggleSendSidebar = () => setSendSidebarOpen(!sendSidebarOpen)

  const dispatch = useDispatch()

  const { loggedInUser, deactivated, loggedInUserLoading, fetchingUsers } =
    useSelector((state) => state.usersReducer)

  // // get params id from url
  // const params = window.location.pathname.split("/")
  // const id = params[params.length - 1]
  // // from searchpARAMS
  // const searchParams = new URLSearchParams(window.location.search)
  // const searchId = searchParams.get("id")

  useEffect(() => {
    if (UserId) {
      dispatch(userActions.getLoggedInUserRequest(UserId))
    }
  }, [UserId])

  const { courses } = useSelector((state) => state.courseReducer)

  const { interests } = useSelector((state) => state.interestReducer)

  useEffect(() => {
    if (isObjEmpty(loggedInUser)) {
      if (UserId) {
        dispatch(userActions.getLoggedInUserRequest(UserId))
      }
    }
    if (isObjEmpty(courses)) {
      dispatch(getAllCoursesRequest())
    }

    if (isObjEmpty(interests)) {
      dispatch(getAllInterestRequest())
    }
  }, [UserId])

  useEffect(() => {
    if (deactivated) {
      dispatch(loginActions.logout())
      dispatch(userActions.resetAllStatus())
      navigate("/login")
    }
  }, [deactivated])

  const { successforpatch, successforpost, deleted } = useSelector(
    (state) => state.usersReducer
  )

  useEffect(() => {
    if (successforpatch || successforpost || deleted) {
      // for rerendering
      dispatch(userActions.getLoggedInUserRequest(getProfileId()))
      dispatch(userActions.resetAllStatus())
    }
  }, [successforpatch, successforpost, deleted])


  const [active, setActive] = useState("1")

  const toggleTab = (tab) => {
    if (active !== tab) {
      setActive(tab)
    }
  }

  const handleDeactivateAccount = () => {
    return MySwal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this by logging in again!",

      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Deactivate it!",
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-danger ms-1"
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        dispatch(
          userActions.deactivateAccountRequest({
            activateIt: false
          })
        )
      }
    })
  }

  return (
    <Fragment>
      <Row>
        <Col lg="4" md="4">
          <Card title="Profile Detail" actions="collapse">
            <div id="user-profile">
              <Row>
                <Col sm="12">
                  <Card className="profile-header mb-0">
                    <div className="profile-img-container d-flex align-items-center pt-5 justify-content-center text-capitalize">
                      {loggedInUser?.personalInfo?.profile_image &&
                      loggedInUser?.personalInfo?.profile_image?.url !== "" ? (
                        <div className="d-flex justify-content-center align-items-center">
                          <div className="position-relative">
                            <img
                              target="_blank"
                              alt="Profile Image Preview"
                              className="rounded me-50"
                              src={
                                loggedInUser?.personalInfo?.profile_image
                                  ?.url || alternateImage
                              }
                              onError={({ currentTarget }) => {
                                currentTarget.onerror = null // prevents looping
                                currentTarget.src = alternateImage
                              }}
                              height="100"
                              width="100"
                              style={{
                                objectFit: "cover",
                                objectPosition: "center",
                                borderRadius: "50%"
                              }}
                            />
                          </div>
                        </div>
                      ) : (
                        <Avatar
                          color="light-primary"
                          size="xl"
                          content={getInitials(
                            loggedInUser?.personalInfo?.fullName
                          )}
                          initials
                        />
                      )}
                    </div>
                  </Card>
                </Col>
              </Row>
            </div>
            <ProfileForm
              toggleSidebar={toggleSendSidebar}
              open={sendSidebarOpen}
              data={loggedInUser}
            />

            <CardBody className="pt-2 ">
              <div style={{ textAlign: "center" }}>
                <h5 className="text-capitalize">
                  {loggedInUser?.personalInfo?.fullName}
                </h5>
                <h6 className="text-capitalize text-primary">
                  {loggedInUser?.role}
                </h6>
              </div>
              <h4 className="fw-bolder border-bottom pb-50 mb-1 pt-2">
                {t("Details")}
              </h4>
              <div className="info-container">
                <ul className="list-unstyled">
                  <li className="mb-75">
                    <span className="fw-bolder me-25">{t("Email")} : </span>
                    <span>{loggedInUser?.email}</span>
                  </li>
                  <li className="mb-75">
                    <span className="fw-bolder me-25">
                      {t("Date of Birth")} :{" "}
                    </span>
                    <span>
                      {formatDateToShow(
                        loggedInUser?.personalInfo?.dateOfBirth
                      )}
                    </span>
                  </li>
                  <li className="mb-75 text-capitalize">
                    <span className="fw-bolder me-25">{t("Gender")} : </span>
                    <span className="text-capitalize">
                      {loggedInUser?.personalInfo?.gender}
                    </span>
                  </li>
                  <li className="mb-75">
                    <span className="fw-bolder me-25">
                      {t("Contact Number")} :{" "}
                    </span>
                    <span>{loggedInUser?.personalInfo?.phone}</span>
                  </li>
                </ul>
              </div>
              {getProfileId() === UserId && (
                <div className="d-flex justify-content-center pt-2">
                  <Button
                    color="primary"
                    onClick={() => {
                      setSendSidebarOpen(true)
                    }}
                  >
                    {t("Edit ")}
                  </Button>
                  <Button
                    className="ms-1"
                    color="danger"
                    onClick={handleDeactivateAccount}
                  >
                    {t("Deactivate")}
                  </Button>
                </div>
              )}
            </CardBody>
          </Card>
        </Col>

        <Col md="8" sm="12" lg="8">
          <Nav pills className="mb-2" style={{ width: "100%" }}>
            <NavItem>
              <NavLink active={active === "1"} onClick={() => toggleTab("1")}>
                <User className="font-medium-3 me-50" />
                <span className="fw-bold">{t("Experience")}</span>
              </NavLink>
            </NavItem>

            <NavItem>
              <NavLink active={active === "2"} onClick={() => toggleTab("2")}>
                <Lock className="font-medium-3 me-50" />
                <span className="fw-bold">{t("Education")}</span>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink active={active === "3"} onClick={() => toggleTab("3")}>
                <Bookmark className="font-medium-3 me-50" />
                <span className="fw-bold">{t("Interests & Courses")}</span>
              </NavLink>
            </NavItem>


            {getProfileId() === UserId && (
              <NavItem>
                <NavLink active={active === "6"} onClick={() => toggleTab("6")}>
                  <Bell className="font-medium-3 me-50" />
                  <span className="fw-bold">{t("Change Password")}</span>
                </NavLink>
              </NavItem>
            )}
          </Nav>
          <TabContent activeTab={active}>
            <TabPane tabId="1">
              <ExperienceCard
                data={loggedInUser?.experience ? loggedInUser?.experience : []}
              />
            </TabPane>

            <TabPane tabId="2">
              <EducationCard
                data={loggedInUser?.education ? loggedInUser?.education : []}
              />
            </TabPane>

            <TabPane tabId="3">
              <SkillsCard
                data={loggedInUser?.interests ? loggedInUser?.interests : []}
                courses={loggedInUser?.courses ? loggedInUser?.courses : []}
              />
            </TabPane>
            {getProfileId() === UserId && (
              <TabPane tabId="6">
                <ChangePasswordCard />
              </TabPane>
            )}
          </TabContent>
        </Col>
      </Row>
    </Fragment>
  )
}

export default Profile
