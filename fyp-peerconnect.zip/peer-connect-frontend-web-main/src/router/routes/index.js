// ** React Imports

import { Fragment, lazy } from "react"
import { getHomeRouteForLoggedInUser, getUserData } from "@src/utility/Utils"

import BlankLayout from "@layouts/BlankLayout"
import HorizontalLayout from "@src/layouts/HorizontalLayout"
import LayoutWrapper from "@src/@core/layouts/components/layout-wrapper"
import { Navigate } from "react-router-dom"
import RoleBasedRoute from "@components/routes/RoleBasedRoute"
import VerticalLayout from "@src/layouts/VerticalLayout"
import { isObjEmpty } from "@utils"
import useJwt from "@src/auth/jwt/useJwt"

const getLayout = {
  blank: <BlankLayout />,
  vertical: <VerticalLayout />,
  horizontal: <HorizontalLayout />
}
const TemplateTitle = "%s - PeerConnect - Learn & Fun "

const DefaultRouteForUser = "/home"
const DefaultRouteForAdmin = "/manage-users"
const Home = lazy(() => import("../../views/Home"))
const Login = lazy(() => import("../../views/Login"))
const Register = lazy(() => import("../../views/Register"))
const ForgotPassword = lazy(() => import("../../views/ForgotPassword"))
const Error = lazy(() => import("../../views/Error"))
const VerifyEmail = lazy(() => import("../../views/VerifyEmail"))
const Profile = lazy(() => import("../../views/Profile"))
const ResetPassword = lazy(() => import("./../../views/ResetPassword"))
const NotAuthorized = lazy(() => import("./../../views/NotAuthorized"))
const ManageUsers = lazy(() => import("./../../views/ManageUsers"))
const Courses = lazy(() => import("./../../views/Courses"))
const Interests = lazy(() => import("./../../views/Interests"))
const Search = lazy(() => import("./../../views/SearchList"))
const Chats = lazy(() => import("./../../views/Chat"))
const Groups = lazy(() => import("./../../views/Groups"))
const GroupProfile = lazy(() => import("./../../views/GroupProfile"))
const GroupChat = lazy(() => import("./../../views/GroupChat"))

const Routes = [
  {
    path: "/",
    index: true,
    element: <Navigate replace to={getHomeRouteForLoggedInUser()} />,
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/verify-email",
    element: <VerifyEmail />,
    meta: {
      layout: "blank",
      meta: {
        type: "public"
      }
    }
  },

  {
    path: "/login",
    element: <Login />,
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/register",
    element: <Register />,
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/forgot-password",
    element: <ForgotPassword />,
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/reset-password",
    element: <ResetPassword />,
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "*",
    element: <Error />,
    children: [{ path: "*", element: <Error /> }],
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/auth/not-auth",
    element: <BlankLayout />,
    children: [{ path: "/auth/not-auth", element: <NotAuthorized /> }],
    meta: {
      layout: "blank",
      type: "public"
    }
  },
  {
    path: "/home",
    element: <Home />,
    meta: {
      role: ["user"],
      type: "protected"
    }
  },
  {
    path: "/manage-users",
    element: <ManageUsers />,
    meta: {
      role: ["admin"],
      type: "protected"
    }
  },
  {
    path: "/profile",
    element: <Profile />,
    meta: {
      role: ["user", "admin"],
      type: "protected"
    }
  },
  {
    path: "/interests",
    element: <Interests />,
    meta: {
      role: ["admin"],
      type: "protected"
    }
  },
  {
    path: "/courses",
    element: <Courses />,
    meta: {
      role: ["admin"],
      type: "protected"
    }
  },
  {
    path: "/search",
    element: <Search />,
    meta: {
      role: ["admin", "user"],
      type: "protected"
    }
  },
  {
    path: "/chats",
    element: <Chats />,
    meta: {
      role: ["user"],
      type: "protected"
    }
  },
  {
    path: "/groups",
    element: <Groups />,
    meta: {
      role: ["user"],
      type: "protected"
    }
  },
  {
    path: "/group",
    element: <GroupProfile />,
    meta: {
      role: ["user"],
      type: "protected"
    }
  },
  {
    path : "/group-chat",
    element : <GroupChat />,
    meta : {
      role : ["user"],
      type : "protected"
    }
  }
]

const getRouteMeta = (route) => {
  if (isObjEmpty(route.element.props)) {
    if (route.meta) {
      return { routeMeta: route.meta }
    } else {
      return {}
    }
  }
}

const MergeLayoutRoutes = (layout, defaultLayout) => {
  const LayoutRoutes = []
  Routes.map((route) => {
    let isBlank = false
    // ** Checks if Route layout or Default layout matches current layout
    if (
      (route.meta && route.meta.layout && route.meta.layout === layout) ||
      ((route.meta === undefined || route.meta.layout === undefined) &&
        defaultLayout === layout)
    ) {
      const RouteTag = RoleBasedRoute

      if (route.meta) {
        route.meta.layout === "blank" ? (isBlank = true) : (isBlank = false)
      }
      if (route.element) {
        const Wrapper =
          // eslint-disable-next-line multiline-ternary
          isObjEmpty(route.element.props) && isBlank === false
            ? // eslint-disable-next-line multiline-ternary
              LayoutWrapper
            : Fragment
        route.element = (
          <Wrapper {...(isBlank === false ? getRouteMeta(route) : {})}>
            <RouteTag route={route}>{route.element}</RouteTag>
          </Wrapper>
        )
      }

      // Push route to LayoutRoutes
      LayoutRoutes.push(route)
    }
    return LayoutRoutes
  })

  //}
  return LayoutRoutes
}

const getRoutes = (layout) => {
  const defaultLayout = layout || "vertical"
  const layouts = ["vertical", "horizontal", "blank"]

  const AllRoutes = []

  layouts.forEach((layoutItem) => {
    const LayoutRoutes = MergeLayoutRoutes(layoutItem, defaultLayout)

    AllRoutes.push({
      path: "/",
      element: getLayout[layoutItem] || getLayout[defaultLayout],
      children: LayoutRoutes
    })
  })
  return AllRoutes
}

export {
  DefaultRouteForUser,
  DefaultRouteForAdmin,
  TemplateTitle,
  Routes,
  getRoutes
}
