import { devConfig } from "./dev"
//import { prodConfig } from "./prod";
export const config = devConfig