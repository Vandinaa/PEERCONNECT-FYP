// ** React Imports
import { useEffect, useState } from "react"

// ** Third Party Components
import axios from "axios"
import classnames from "classnames"
import * as Icon from "react-feather"

// ** Reactstrap Imports
import { NavItem, NavLink } from "reactstrap"

// ** Store & Actions
import { useDispatch, useSelector } from "react-redux"

// ** Store Imports
// import * as navbarActions from "@src/store/common/navbar/actions"
import * as searchActions from "@src/store/common/search/actions"

// ** Custom Components
import Autocomplete from "@components/autocomplete"
import { isNullObject } from "@src/utility/Utils"
import { useNavigate } from "react-router-dom"

const NavbarSearch = () => {
  // ** Store Vars
  const dispatch = useDispatch()
  const navigate = useNavigate()
  // const history = useHistory();

  // ** States
  const [suggestions, setSuggestions] = useState([])
  const [navbarSearch, setNavbarSearch] = useState(false)

  const { listOfSearch, searching } = useSelector(
    (state) => state.searchReducer
  )

  useEffect(() => {
    if (!isNullObject(listOfSearch)) {
      const searchArr = []
      if (listOfSearch.usersResult) {
        const users = listOfSearch.usersResult.results
          .slice(0, 3)
          .map((user) => ({
            title: user?.personalInfo?.fullName + "- " + user?.email,
            icon: "User",
            link: `/profile?id=${user.id}`
          }))
        searchArr.push({
          groupTitle: "Users",
          searchLimit: 3,
          data: users
        })
      }

      if (listOfSearch.groupsResult) {
        console.log(listOfSearch.groupsResult)
        const groups = listOfSearch.groupsResult.results
          .slice(0, 3)
          .map((group) => ({
            title: group?.groupName,
            icon: "Users",
            link: `/groups/${group.id}`
          }))

        searchArr.push({
          groupTitle: "Groups",
          searchLimit: 4,
          data: groups
        })
      }

      setSuggestions(searchArr)
    } else {
      setSuggestions([])
    }
  }, [listOfSearch])

  // ** Removes query in store
  const handleClearQueryInStore = () =>
    dispatch(searchActions.clearSearchList())
  // dispatch(navbarActions.handleSearchQuery(""))

  // ** Function to handle external Input click
  const handleExternalClick = () => {
    if (navbarSearch === true) {
      setNavbarSearch(false)
      handleClearQueryInStore()
    }
  }

  // ** Function to clear input value
  const handleClearInput = (setUserInput) => {
    if (!navbarSearch) {
      setUserInput("")
      handleClearQueryInStore()
    }
  }

  // ** Function to close search on ESC & ENTER Click
  const onKeyDown = (e) => {
    if (e.keyCode === 27 || (e.keyCode === 13 && !searching)) {
      if (e.keyCode === 13) {
        if (e.target.value !== "") {
          navigate("/search?q=" + e.target.value)
          setNavbarSearch(false)
        }
      } else {
        setTimeout(() => {
          setNavbarSearch(false)
          handleClearQueryInStore()
        }, 2)
      }
    }
  }

  // ** Function to handle search suggestion Click
  const handleSuggestionItemClick = () => {
    console.log("clicked here")
    setNavbarSearch(false)
    handleClearQueryInStore()
  }

  // ** Function to handle search list Click
  const handleListItemClick = (func, link, e) => {
    console.log("clicked here click")

    func(link, e)
    setTimeout(() => {
      setNavbarSearch(false)
    }, 1)
    handleClearQueryInStore()
  }

  return (
    <NavItem className="nav-search" onClick={() => setNavbarSearch(true)}>
      <NavLink className="nav-link-search">
        <Icon.Search className="ficon" />
      </NavLink>
      <div
        className={classnames("search-input", {
          open: navbarSearch === true
        })}
      >
        <div className="search-input-icon">
          <Icon.Search />
        </div>
        {navbarSearch ? (
          <Autocomplete
            className="form-control"
            suggestions={suggestions}
            filterKey="title"
            filterHeaderKey="groupTitle"
            grouped={true}
            placeholder="Explore PeerConnect..."
            autoFocus={true}
            onSuggestionItemClick={handleSuggestionItemClick}
            externalClick={handleExternalClick}
            clearInput={(userInput, setUserInput) =>
              handleClearInput(setUserInput)
            }
            onKeyDown={onKeyDown}
            onChange={(e) => {
              dispatch(searchActions.getListOfSearchRequest(e.target.value))
              // navigate(`/search?q=${e.target.value}`);
            }}
            customRender={(
              item,
              i,
              filteredData,
              activeSuggestion,
              onSuggestionItemClick,
              onSuggestionItemHover
            ) => {
              const IconTag = Icon[item.icon ? item.icon : "X"]
              return (
                <li
                  className={classnames("suggestion-item", {
                    active: filteredData.indexOf(item) === activeSuggestion
                  })}
                  key={i}
                  onClick={(e) => {
                    console.log("clicked")
                    handleListItemClick(onSuggestionItemClick, item?.link, e)
                  }}
                  onMouseEnter={() => {
                    console.log("hovered")
                    onSuggestionItemHover(filteredData.indexOf(item))
                  }}
                >
                  <div
                    className={classnames({
                      "d-flex justify-content-between align-items-center":
                        item.file || item.img
                    })}
                  >
                    <div className="item-container d-flex">
                      {item.icon ? (
                        <IconTag size={17} />
                      ) : item.file ? (
                        <img
                          src={item.file}
                          height="36"
                          width="28"
                          alt={item.title}
                        />
                      ) : item.img ? (
                        <img
                          className="rounded-circle mt-25"
                          src={item.img}
                          height="28"
                          width="28"
                          alt={item.title}
                        />
                      ) : null}
                      <div className="item-info ms-1">
                        <p className="align-middle mb-0">{item.title}</p>
                        {item.by || item.email ? (
                          <small className="text-muted">
                            {item.by ? item.by : item.email ? item.email : null}
                          </small>
                        ) : null}
                      </div>
                    </div>
                    {item.size || item.date ? (
                      <div className="meta-container">
                        <small className="text-muted">
                          {item.size ? item.size : item.date ? item.date : null}
                        </small>
                      </div>
                    ) : null}
                  </div>
                </li>
              )
            }}
          />
        ) : null}
        <div className="search-input-close">
          <Icon.X
            className="ficon"
            onClick={(e) => {
              e.stopPropagation()
              setNavbarSearch(false)
              handleClearQueryInStore()
            }}
          />
        </div>
      </div>
    </NavItem>
  )
}

export default NavbarSearch
