import { USERS_TYPES } from "./types"
import { toast } from "react-hot-toast"

const initialState = {
  users: {},
  recommendedUsers: {},
  error: null,
  user: {},
  created: false,
  deleted: false,
  updated: false,
  createdUpdatedLoading: false,
  fetchingUsers: false,
  deletedLoading: false,
  userFetched: false,
  userNotFound: false,
  loggedInUser: {},
  loading_patch_profile: false,
  patched_profile: false,
  loggedInUserLoading: false,
  loading: false,
  successforpatch: false,
  successforpost: false,
  profileImageUrl: null,
  profileImageLoading: false,
  deactivated: false,
  stats : {
    totalUsers : 0,
    totalGroups : 0,
    topInterests : [],
    topCourses : [],
  }
}

const usersReducer = (state = initialState, action) => {
  switch (action.type) {
    case USERS_TYPES.GET_ALL_USERS_REQUEST:
      return {
        ...state,
        error: null,
        fetchingUsers: true,
        created: false,
        deleted: false,
        updated: false
      }
    case USERS_TYPES.GET_ALL_USERS_SUCCESS:
      return {
        ...state,
        fetchingUsers: false,
        users: action.payload,
        createdUpdatedLoading: false,
        deletedLoading: false
      }
    case USERS_TYPES.GET_ALL_USERS_FAIL:
      return {
        ...state,
        fetchingUsers: false,

        error: action.payload
      }
    case USERS_TYPES.GET_RECOMMENDED_USERS_REQUEST:
      return {
        ...state,
        error: null,
        fetchingUsers: true,
        created: false,
        deleted: false,
        updated: false
      }
    case USERS_TYPES.GET_RECOMMENDED_USERS_SUCCESS:
      return {
        ...state,
        fetchingUsers: false,
        recommendedUsers: action.payload,
        createdUpdatedLoading: false,
        deletedLoading: false
      }

    case USERS_TYPES.GET_RECOMMENDED_USERS_FAIL:
      return {
        ...state,
        fetchingUsers: false,
        error: action.payload
      }

















    case USERS_TYPES.GET_USER_REQUEST:
      return {
        ...state,
        error: null,
        userFetched: false,
        fetchingUsers: true,
        userNotFound: false
      }

    case USERS_TYPES.GET_USER_SUCCESS:
      return {
        ...state,
        fetchingUsers: false,
        userFetched: true,
        user: action.payload
      }

    case USERS_TYPES.GET_USER_FAIL:
      return {
        ...state,
        fetchingUsers: false,
        userFetched: false,
        error: action.payload,
        userNotFound:
          typeof action.payload === "string" &&
          action.payload === "User Not Found"
            ? true
            : false
      }

    case USERS_TYPES.RESET_ALL_STATUS:
      return {
        ...state,
        created: false,
        deleted: false,
        userNotFound: false,
        userFetched: false,
        fetchingUsers: false,
        error: null,
        updated: false,
        createdUpdatedLoading: false,
        deletedLoading: false,
        loading_patch_profile: false,
        patched_profile: false,
        loading: false,
        successforpatch: false,
        successforpost: false,
        deactivated: false
      }

    case USERS_TYPES.CREATE_USER_REQUEST:
      return {
        ...state,
        createdUpdatedLoading: true,
        error: null,
        created: false
      }

    case USERS_TYPES.CREATE_USER_SUCCESS:
      return {
        ...state,
        createdUpdatedLoading: false,
        created: true
      }
    case USERS_TYPES.CREATE_USER_FAIL:
      // if action.payload is string, it means that the email already exists
      if (typeof action.payload === "string") {
        toast.error(action.payload)
      }

      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false,
        created: false
      }

    case USERS_TYPES.UPDATE_USER_REQUEST:
      return {
        ...state,
        createdUpdatedLoading: true,
        error: null,
        updated: false
      }

    case USERS_TYPES.UPDATE_USER_SUCCESS:
      const oldUserData = localStorage.getItem("userData")
      if (oldUserData) {
        const oldUserDataJson = JSON.parse(oldUserData)
        oldUserDataJson.personalInfo.fullName =
          action.payload.personalInfo.fullName
        oldUserDataJson.personalInfo.profile_image =
          action.payload.personalInfo.profile_image
        localStorage.setItem("userData", JSON.stringify(oldUserDataJson))
      }

      return {
        ...state,
        updated: true,
        createdUpdatedLoading: false
      }

    case USERS_TYPES.UPDATE_USER_FAIL:
      return {
        ...state,
        error: action.payload,
        createdUpdatedLoading: false,
        updated: false
      }

    case USERS_TYPES.DELETE_USER_REQUEST:
      return {
        ...state,
        deletedLoading: true,
        error: null,
        deleted: false
      }

    case USERS_TYPES.DELETE_USER_SUCCESS:
      return {
        ...state,
        deleted: true,
        deletedLoading: false
      }

    case USERS_TYPES.DELETE_USER_FAIL:
      return {
        ...state,
        error: action.payload,
        deletedLoading: false,
        deleted: false
      }

    case USERS_TYPES.BLOCK_USER_REQUEST:
      return {
        ...state,
        deletedLoading: true,
        error: null
        // deleted: false
      }

    case USERS_TYPES.BLOCK_USER_SUCCESS:
      const updatedUsers = state.users?.results?.map((user) =>
        user.id === action.payload.id
          ? { ...user, isBlocked: action.payload.isBlocked }
          : user
      )

      return {
        ...state,
        deletedLoading: false,
        users: { ...state.users, results: updatedUsers }
      }

    case USERS_TYPES.BLOCK_USER_FAIL:
      return {
        ...state,
        error: action.payload,
        deletedLoading: false
        // deleted: false
      }

    case USERS_TYPES.GET_LOGGED_IN_USER_REQUEST:
      return {
        ...state,
        loggedInUserLoading: true,
        error: null
      }

    case USERS_TYPES.GET_LOGGED_IN_USER_SUCCESS:
      return {
        ...state,
        loggedInUserLoading: false,
        loggedInUser: action.payload
      }

    case USERS_TYPES.GET_LOGGED_IN_USER_FAIL:
      return {
        ...state,
        error: action.payload,
        loggedInUserLoading: false
      }

    case USERS_TYPES.UPDATE_EDUCATION_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        successforpatch: false
      }

    case USERS_TYPES.UPDATE_EDUCATION_SUCCESS:
      return {
        ...state,
        loading: false,
        successforpatch: true
      }

    case USERS_TYPES.UPDATE_EDUCATION_FAIL:
      return {
        ...state,
        error: action.payload,
        loading: false,
        successforpatch: false
      }

    case USERS_TYPES.UPDATE_EXPERIENCE_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        successforpatch: false
      }

    case USERS_TYPES.UPDATE_EXPERIENCE_SUCCESS:
      return {
        ...state,
        loading: false,
        successforpatch: true
      }

    case USERS_TYPES.UPDATE_EXPERIENCE_FAIL:
      return {
        ...state,
        error: action.payload,
        loading: false,
        successforpatch: false
      }

    case USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        successforpatch: false
      }

    case USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_SUCCESS:
      return {
        ...state,
        loading: false,
        successforpatch: true
      }

    case USERS_TYPES.UPDATE_INTERESTS_AND_COURSES_FAIL:
      return {
        ...state,
        error: action.payload,
        loading: false,
        successforpatch: false
      }

    case USERS_TYPES.DELETE_EDUCATION_REQUEST:
      return {
        ...state,
        deleted: true
      }

    case USERS_TYPES.DELETE_EDUCATION_SUCCESS:
      return {
        ...state,
        deleted: false
      }

    case USERS_TYPES.DELETE_EDUCATION_FAIL:
      return {
        ...state,
        error: action.payload,
        deleted: false
      }

    case USERS_TYPES.DELETE_EXPERIENCE_REQUEST:
      return {
        ...state,
        deleted: true
      }

    case USERS_TYPES.DELETE_EXPERIENCE_SUCCESS:
      return {
        ...state,
        deleted: false
      }

    case USERS_TYPES.DELETE_EXPERIENCE_FAIL:
      return {
        ...state,
        error: action.payload,
        deleted: false
      }

    case USERS_TYPES.ADD_EDUCATION_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        successforpost: false
      }

    case USERS_TYPES.ADD_EDUCATION_SUCCESS:
      return {
        ...state,
        loading: false,
        successforpost: true
      }

    case USERS_TYPES.ADD_EDUCATION_FAIL:
      return {
        ...state,
        error: action.payload,
        loading: false,
        successforpost: false
      }

    case USERS_TYPES.ADD_EXPERIENCE_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
        successforpost: false
      }

    case USERS_TYPES.ADD_EXPERIENCE_SUCCESS:
      return {
        ...state,
        loading: false,
        successforpost: true
      }

    case USERS_TYPES.ADD_EXPERIENCE_FAIL:
      return {
        ...state,
        error: action.payload,
        loading: false,
        successforpost: false
      }

    case USERS_TYPES.UPLOAD_PROFILE_IMAGE_REQUEST:
      return {
        ...state,
        profileImageLoading: true,
        error: null,
        profileImageUrl: null
      }

    case USERS_TYPES.UPLOAD_PROFILE_IMAGE_SUCCESS:
      return {
        ...state,
        profileImageLoading: false,
        profileImageUrl: action.payload
      }

    case USERS_TYPES.UPLOAD_PROFILE_IMAGE_FAIL:
      return {
        ...state,
        error: action.payload,
        profileImageLoading: false,
        profileImageUrl: null
      }

    case USERS_TYPES.DEACTIVATE_ACCOUNT_REQUEST:
      return {
        ...state,
        deactivated: false
      }

    case USERS_TYPES.DEACTIVATE_ACCOUNT_SUCCESS:
      return {
        ...state,
        deactivated: true
      }

    case USERS_TYPES.DEACTIVATE_ACCOUNT_FAIL:
      return {
        ...state,
        error: action.payload,
        deactivated: false
      }

    case USERS_TYPES.GET_STATS_REQUEST:
      return {
        ...state,
        error: null,
        stats: {
          totalUsers : 0,
          totalGroups : 0,
          topInterests : [],
          topCourses : [],
        }
      }

    case USERS_TYPES.GET_STATS_SUCCESS:
      return {
        ...state,
        stats: action.payload
      }

    case USERS_TYPES.GET_STATS_FAIL:
      return {
        ...state,
        error: action.payload,
        stats: {
          totalUsers : 0,
          totalGroups : 0,
          topInterests : [],
          topCourses : [],
        }
      }



  

    default:
      return state
  }
}

export default usersReducer
