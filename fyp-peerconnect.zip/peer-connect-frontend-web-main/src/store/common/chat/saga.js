import * as chatActions from "./actions"

import { all, call, put, takeEvery } from "redux-saga/effects"
import {

  chatNotification,
  getChatHistory,
  getGroupChatHistory,
  uploadChatMedia,
  uploadFiles
} from "@src/services/apis"

import { CHAT_TYPES } from "./types"

function* getChatHistoryRequest(action) {
  try {
    const response = yield call(getChatHistory, action.payload)
    if (response.status === 200) {
      yield put(chatActions.getChatHistorySuccess(response.data))
    } else {
      yield put(chatActions.getChatHistoryFailure(response))
    }
  } catch (err) {
    yield put(chatActions.getChatHistoryFailure(err))
  }
}

function* getGroupChatHistoryRequest(action) {
  try {
    const response = yield call(getGroupChatHistory, action.payload)
    if (response.status === 200) {
      yield put(chatActions.getGroupChatHistorySuccess(response.data))
    } else {
      yield put(chatActions.getGroupChatHistoryFailure(response))
    }
  } catch (err) {
    yield put(chatActions.getGroupChatHistoryFailure(err))
  }
}

function* uploadChatMediaRequest(action) {
  try {
    const response = yield call(uploadChatMedia, action.payload)
    if (response.status === 200) {
      yield put(chatActions.uploadChatMediaSuccess(response.data))
    } else {
      yield put(chatActions.uploadChatMediaFailure(response))
    }
  } catch (err) {
    yield put(chatActions.uploadChatMediaFailure(err))
  }
}

function* uploadChatDocumentRequest(action) {
  try {
    const response = yield call(uploadFiles, action.payload)
    console.log(response)
    if (response && response.fileList && response.fileList.length > 0) {
      yield put(chatActions.uploadChatDocumentSuccess(response.fileList[0]))
    } else {
      yield put(chatActions.uploadChatDocumentFailure(response))
    }
  } catch (err) {
    yield put(chatActions.uploadChatDocumentFailure(err))
  }
}

function* chatNotificationRequest(action) {
  try {
    const response = yield call(chatNotification, action.payload)
    if (response.status === 200) {
      yield put(chatActions.chatNotificationSuccess(response.data))
    } else {
      yield put(chatActions.chatNotificationFailure(response))
    }
  } catch (err) {
    yield put(chatActions.chatNotificationFailure(err))
  }
}



// function* createEvaluationRequest(action) {
//   try {
//     const response = yield call(createEvaluation, action.payload)
//     if (response.status === 201) {
//       yield put(chatActions.createEvaluationSuccess(response.message))
//     } else {
//       yield put(chatActions.createEvaluationFailure(response.message))
//     }
//   } catch (err) {
//     yield put(chatActions.createEvaluationFailure(err))
//   }
// }

// function* getEvaluationRequest(action) {
//   try {
//     const response = yield call(getEvaluation, action.payload)
//     if (response.status === 200) {
//       yield put(chatActions.getEvaluationSuccess(response.data))
//     } else {
//       yield put(chatActions.getEvaluationFailure(response.message))
//     }
//   } catch (err) {
//     yield put(chatActions.getEvaluationFailure(err))
//   }
// }

// function* updateEvaluationRequest(action) {
//   try {
//     const response = yield call(updateEvaluation, action.payload)
//     if (response.status === 200) {
//       yield put(chatActions.updateEvaluationSuccess(response.message))
//     } else {
//       yield put(chatActions.updateEvaluationFailure(response.message))
//     }
//   } catch (err) {
//     yield put(chatActions.updateEvaluationFailure(err))
//   }
// }

// function* deleteEvaluationRequest(action) {
//   try {
//     const response = yield call(deleteEvaluation, action.payload)
//     if (response.status === 200) {
//       yield put(chatActions.deleteEvaluationSuccess(response.message))
//     } else {
//       yield put(chatActions.deleteEvaluationFailure(response.message))
//     }
//   } catch (err) {
//     yield put(chatActions.deleteEvaluationFailure(err))
//   }
// }

// function* getAllEvaluationRequest(action) {
//   try {
//     const response = yield call(getAllEvaluation, action.payload)
//     if (response.status === 200) {
//       yield put(chatActions.getAllEvaluationSuccess(response.data))
//     } else {
//       yield put(chatActions.getAllEvaluationFailure(response.message))
//     }
//   } catch (err) {
//     yield put(chatActions.getAllEvaluationFailure(err))
//   }
// }

export default function* chatSaga() {
  yield all([
    takeEvery(CHAT_TYPES.GET_CHAT_HISTORY_REQUEST, getChatHistoryRequest),
    takeEvery(CHAT_TYPES.GET_GROUP_CHAT_HISTORY_REQUEST, getGroupChatHistoryRequest),
    takeEvery(CHAT_TYPES.UPLOAD_CHAT_MEDIA_REQUEST, uploadChatMediaRequest),
    takeEvery(CHAT_TYPES.UPLOAD_CHAT_DOCUMENT_REQUEST, uploadChatDocumentRequest),
    takeEvery(CHAT_TYPES.CHAT_NOTIFICATION_REQUEST, chatNotificationRequest)
    // takeEvery(
    //   CHAT_TYPES.CREATE_CHAT_REQUEST,
    //   createEvaluationRequest
    // ),
    // takeEvery(CHAT_TYPES.GET_CHAT_REQUEST, getEvaluationRequest),
    // takeEvery(
    //   CHAT_TYPES.UPDATE_CHAT_REQUEST,
    //   updateEvaluationRequest
    // ),
    // takeEvery(
    //   CHAT_TYPES.DELETE_CHAT_REQUEST,
    //   deleteEvaluationRequest
    // ),
    // takeEvery(
    //   CHAT_TYPES.GET_ALL_CHAT_REQUEST,
    //   getAllEvaluationRequest
    // )
  ])
}
