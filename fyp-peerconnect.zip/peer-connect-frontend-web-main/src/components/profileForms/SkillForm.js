import * as Yup from "yup"
import * as userActions from "@src/store/common/users/actions"

import makeAnimated from "react-select/animated"

import { Alert, Button, Form, Label, Spinner } from "reactstrap"
import { fieldExists, getProfileId, isNullObject } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Select from "react-select"
import Sidebar from "@components/sidebar"
import { selectThemeColors } from "@utils"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"

const SkillForm = ({ open, toggleSidebar, formType, data }) => {
  const { t } = useTranslation()
  const [isSubmit, setSubmit] = useState(false)

  const dispatch = useDispatch()
  const animatedComponents = makeAnimated()


  const { loading, error, successforpatch } = useSelector(
    (state) => state.usersReducer
  )
  const { interests } = useSelector((state) => state.interestReducer)
  const { courses } = useSelector((state) => state.courseReducer)

  const [interestsOptions, setInterestsOptions] = useState([])
  const [coursesOptions, setCoursesOptions] = useState([])


  useEffect(() => {
    if( successforpatch){
      toggleSidebar()
    }
  }, [successforpatch])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          value: item.id,
          label: item.courseName + " - " + item.courseCode
        }
      })
      setCoursesOptions(a)
    }
  }, [courses])

  useEffect(() => {
    if (fieldExists(interests, "results") && interests.results.length > 0) {
      const a = interests.results.map((item, index) => {
        return {
          value: item.id,
          label: item.interestName
        }
      })
      setInterestsOptions(a)
    }
  }, [interests])

  const validationSchema = Yup.object().shape({
    interests: Yup.array().required(t("Required")).min(1, t("Required")),
    courses: Yup.array().required(t("Required")).min(1, t("Required"))
  })

  const formik = useFormik({
    initialValues: {
      interests: [],
      courses: []
    },
    validationSchema,
    onSubmit: (values) => {
      setSubmit(false)

      dispatch(
        userActions.updateInterestsAndCoursesRequest({
          params: getProfileId(),
          body: {
            interests: values.interests.map((item) => item.value),
            courses: values.courses.map((item) => item.value)
          }
        })
      )

    }
  })
  const {
    values,
    errors,
    handleSubmit,
    handleBlur,
    setFieldValue
  } = formik

  useEffect(() => {
    if (formType === "edit" && !isNullObject(data)) {
      const { interests, courses } = data

      setFieldValue("interests", interestsOptions.filter((item) => interests.some((i) => i.id === item.value)) || [])
      
      setFieldValue("courses", coursesOptions.filter((item) => courses.some((i) => i.id === item.value)) || [])


    }
  }, [data])

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={`${formType === "edit" ? t("Edit") : t("Add")} ${t("Skill")}`}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmit(true)
          handleSubmit()
        }}
      >
        <div className="mb-1">
          <Label for="invoice-to" className="form-label">
            {t("Interests")}*
          </Label>
          <Select
            id="interests"
            theme={selectThemeColors}
            className="react-select"
            classNamePrefix="select"
            options={interestsOptions}
            isClearable={false}
            components={animatedComponents}
            closeMenuOnSelect={true}
            isMulti
            name="interests"
            value={values.interests}
            // value={interestsOptions.filter((item) => values.interests.includes(item.value)) || []}
            onChange={(value) => {
              setFieldValue("interests", value)
            }}
            onBlur={handleBlur}
          />
          {isSubmit && errors.interests && (
            <div className="text-danger text-small mt-50">
              {errors.interests}
            </div>
          )}
        </div>

        <div className="mb-1">
          <Label for="invoice-to" className="form-label">
            {t("Courses")}*
          </Label>
          <Select
            id="courses"
            theme={selectThemeColors}
            className="react-select"
            classNamePrefix="select"
            options={coursesOptions}
            isClearable={false}
            components={animatedComponents}
            closeMenuOnSelect={true}
            isMulti
            name="courses"
            value={values.courses}
            onChange={(value) => {
              setFieldValue("courses", value)
            }}
            onBlur={handleBlur}
          />
          {isSubmit && errors.courses && (
            <div className="text-danger text-small mt-50">{errors.courses}</div>
          )}
        </div>

        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={loading}
            // onClick={toggleSidebar}
          >
            {loading ? <Spinner className="me-1" size="sm" /> : null}
            {formType === t("edit") ? t("Update") : t("Add")}
          </Button>
          <Button color="secondary" outline onClick={toggleSidebar}>
            {t("Cancel")}
          </Button>
        </div>
      </Form>
      {loading ? (
        <Alert color="success">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">Updating...</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
      {error ? (
        <Alert color="danger">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">{error?.message}</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
    </Sidebar>
  )
}

export default SkillForm
