import "@styles/react/libs/flatpickr/flatpickr.scss"

import * as Yup from "yup"
import * as userActions from "@src/store/common/users/actions"

import {
  Alert,
  Button,
  Col,
  Form,
  Input,
  Label,
  Row,
  Spinner
} from "reactstrap"
import {
  formatDatetoISO,
  getProfileId,
  isNullObject
} from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Flatpickr from "react-flatpickr"
import Sidebar from "@components/sidebar"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"

const ExperienceForm = ({ open, toggleSidebar, formType, data }) => {
  const { t } = useTranslation()
  const [isSubmit, setSubmit] = useState(false)

  const { loading, error, successforpatch, successforpost } = useSelector(
    (state) => state.usersReducer
  )

  const dispatch = useDispatch()

  useEffect(() => {
    if (successforpatch || successforpost) {
      // for rerendering
      dispatch(
        userActions.getLoggedInUserRequest(
          getProfileId()
        )
      )
      dispatch(
        userActions.resetAllStatus())
    }
  }, [successforpatch, successforpost])

  const initialValues = {
    job_title: "",
    company_name: "",
    is_current_job: false,
    start_date: "",
    end_date: "",
    description: ""
  }

  const validationSchema = Yup.object().shape({
    job_title: Yup.string().required((t("Profile title is required"))),
    company_name: Yup.string().required(t("Company name is required")),
    start_date: Yup.string().required(t("Start date is required")),
    end_date: Yup.string().when("is_current_job", {
      is: false,
      then: Yup.string()
        .required(t("End date is required"))
        .max(new Date(), t("end date should be less than today"))
    }),
    description: Yup.string().required(t("Description is required"))
  })

  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      setSubmit(false)
      values.start_date = formatDatetoISO(values.start_date)
      values.end_date = formatDatetoISO(values.end_date) 

      if (formType === "edit" && values !== data) {
        dispatch(
          userActions.updateExperienceRequest({
            params: data._id,
            body: {
              jobTitle: values.job_title,
              company : values.company_name,
              startDate: values.start_date,
              endDate: values.is_current_job ? null : values.end_date,
              isCurrentlyWorking: values.is_current_job,
              description: values.description
            }
          })
        )
      } else if (formType === "add") {
        // values.seeker_profile_id = getSeekerProfileId()
        dispatch(userActions.addExperienceRequest({
          jobTitle: values.job_title,
          company : values.company_name,
          startDate: values.start_date,
          endDate: values.is_current_job ? null : values.end_date,
          isCurrentlyWorking: values.is_current_job,
          description: values.description
        }))
      }
    }
  })

  const handleDateChange = (date, name) => {
    setFieldValue(name, date[0])
  }

  useEffect(() => {
    setSubmit(false)
    if (formType === "edit" && !isNullObject(data)) {
      setFieldValue("job_title", data.jobTitle)
      setFieldValue("company_name", data.company)
      setFieldValue("start_date", data.startDate)
      setFieldValue("end_date", data.endDate)
      setFieldValue("description", data.description)
      setFieldValue("is_current_job", data.isCurrentlyWorking)
    } else {
      setFieldValue("job_title", "")
      setFieldValue("company_name", "")
      setFieldValue("is_current_job", false)
      setFieldValue("start_date", "")
      setFieldValue("end_date", "")
      setFieldValue("description", "")
    }
  }, [data])

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={`${formType === "edit" ? t("Edit") : t("Add")} ${t("Experience")}`}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmit(true)
          handleSubmit()
        }}
      >
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Title")}*
          </Label>
          <Input
            type="text"
            name="job_title"
            onChange={handleChange}
            value={values.job_title}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder=""
          />
          {isSubmit && errors.job_title && <div style={{color:"red"}}>{errors.job_title}</div>}
        </div>
        <div className="mb-1">
          <Label for="invoice-subject" className="form-label">
            {t("Company Name")}*
          </Label>
          <Input
            name="company_name"
            onChange={handleChange}
            value={values.company_name}
            onBlur={handleBlur}
            id="invoice-subject"
            placeholder=""
          />
          {isSubmit && errors.company_name && <div style={{color:"red"}}>{errors.company_name}</div>}
        </div>

        <Row>
          <Col md="6" sm="12" className="mb-1">
            <Label className="form-label" for="default-picker">
              {t("Start Date")}*
            </Label>
            <Flatpickr
              type="data"
              className="form-control"
              value={values.start_date}
              onChange={(date) => {
                handleDateChange(date, `start_date`)
              }}
              id="default-picker"
            />
            {isSubmit && errors.start_date && <div style={{color:"red"}}>{errors.start_date}</div>}
          </Col>
          <Col md="6" sm="12" className="mb-1">
            <Label className="form-label" for="lastNameMulti">
              {t("End Date")}*
            </Label>
            <Flatpickr
              type="data"
              disabled={values.is_current_job}
              className="form-control"
              value={values.end_date}
              onChange={(date) => {
                handleDateChange(date, `end_date`)
              }}
              id="default-picker"
            />
            {isSubmit && errors.end_date && <div style={{color:"red"}}>{errors.end_date}</div>}
          </Col>
        </Row>
        <div className="mb-1">
          <div className="form-check form-check-inline">
            <Input
              className="form-check-input"
              type="checkbox"
              id="basic-cb-unchecked"
              name="is_current_job"
              onChange={() => {
                setFieldValue("is_current_job", !values.is_current_job)
                setFieldValue("end_date", "")
              }}
              // value={values.is_current_job}
              checked={values.is_current_job}
              onBlur={handleBlur}
            />

            <Label for="basic-cb-unchecked" className="form-check-label">
              {t("Currently Working")}
            </Label>
          </div>
        </div>

        <div className="mt-2">
          <Label for="invoice-message" className="form-label">
            {t("Description")}
          </Label>

          <Input
            name="description"
            onChange={handleChange}
            value={values.description}
            onBlur={handleBlur}
            type="textarea"
            cols="3"
            rows="3"
            id="invoice-message"
          />
          {isSubmit && errors.description && <div style={{color:"red"}}>{errors.description}</div>}
        </div>

        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={loading}
            // onClick={toggleSidebar}
          >
            {loading ? <Spinner className="me-1" size="sm" /> : null}
            {formType === t("edit") ? t("Update") : t("Add")}
          </Button>

          <Button color="secondary" outline onClick={toggleSidebar}>
            {t("Cancel")}
          </Button>
        </div>
      </Form>
      {loading ? (
        <Alert color="success">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">Updating...</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
      {error ? (
        <Alert color="danger">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">{error?.message}</span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
    </Sidebar>
  )
}

export default ExperienceForm
