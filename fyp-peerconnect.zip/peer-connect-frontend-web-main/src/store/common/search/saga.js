import * as searchActions from "./actions"

import { all, call, put, takeEvery } from "redux-saga/effects"

import { SEARCH_TYPES } from "./types"
import { getSearch } from "@src/services/apis"

function* getSearchRequest(action) {
  try {
    const response = yield call(getSearch, action.payload)

    if (response?.status === 200) {
      yield put(searchActions.getListOfSearchSuccess(response.data))
    }
  } catch (err) {
    yield put(searchActions.getListOfSearchFailure(err))
  }
}

function* searchSaga() {
  yield all([takeEvery(SEARCH_TYPES.GET_LIST_OF_SEARCH_REQUEST, getSearchRequest)])
}

export default searchSaga
