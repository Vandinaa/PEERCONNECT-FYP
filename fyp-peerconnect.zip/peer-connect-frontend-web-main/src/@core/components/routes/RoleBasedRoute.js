// ** React Imports

import {
  getCompanyName,
  getHomeRouteForLoggedInUser,
  getUserRole,
  isNullObject
} from "@utils"

import { Navigate } from "react-router-dom"
import { Suspense } from "react"

const RoleBasedRoute = ({ children, route }) => {
  if (route) {
    const role = getUserRole()

    if (route.meta.type === "public") {
      if (isNullObject(role) || route.path === "/auth/not-auth"|| route.path === "/reset-password") {
        return <Suspense fallback={null}>{children}</Suspense>
      } else {
        return <Navigate replace to={getHomeRouteForLoggedInUser(role)} />
      }
    }

    if (route.meta.type === "protected") {
      if (isNullObject(role)) {
        return <Navigate replace to={"/login"} />
      }
      else {
        if (route.meta?.role.includes(role)) {
          return <Suspense fallback={null}>{children}</Suspense>
        } else {
          return <Navigate replace to={"/auth/not-auth"} />
        }
      } 
    }
    return <Suspense fallback={null}>{children}</Suspense>
  }
}

export default RoleBasedRoute
