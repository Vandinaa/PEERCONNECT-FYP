import * as userActions from "@src/store/common/users/actions"

import { Fragment,  useEffect } from "react"

import { useDispatch, useSelector } from "react-redux"

import {  isNullObject, isObjEmpty } from "@src/utility/Utils"

import { Button, Spinner } from "reactstrap"

import UserCard from "@src/components/UserCard"

function Home() {
  const dispatch = useDispatch()

  const { recommendedUsers, fetchingUsers } = useSelector((state) => state.usersReducer)

  useEffect(() => {
      dispatch(
        userActions.getRecommendedUsersRequest({
          perPage: 6,
          page: 1,
          isActive: true,
          isBlocked: false,
          isEmailVerified: true
        })
      )
  }, [dispatch])

  return (
    <Fragment>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center ">
        <div>
          <h3>Users</h3>
          <p className="mb-2">
            Recommended users based on your Interests and Courses you studied.
          </p>
        </div>
      </div>
      {fetchingUsers ? (
        <div className="text-center">
          <Spinner color="primary" className="mb-1" />
        </div>
      ) : recommendedUsers?.results?.length > 0 ? (
        <>
          <UserCard users={recommendedUsers} />
          {recommendedUsers?.totalPages > recommendedUsers?.page ? (
            <div className="d-flex justify-content-end flex-wrap">
              <Button
                color="primary"
                className="text-nowrap mb-1"
                size="sm"
                onClick={() => {
                  dispatch(
                    userActions.getRecommendedUsersRequest({
                      perPage: recommendedUsers?.limit + 6,
                      page: 1
                    })
                  )
                }}
              >
                View More
              </Button>
            </div>
          ) : null}
        </>
      ) : (
        <div className="text-center">
          <h3>No Users Found</h3>
        </div>
      )}
    </Fragment>
  )
}

export default Home
