import * as Yup from "yup"
import * as interestActions from "@src/store/common/interests/actions"
import Select from "react-select"

import { selectThemeColors } from "@utils"

import {
  Alert,
  Button,
  Form,
  FormText,
  Input,
  Label,
  Spinner
} from "reactstrap"
import { isNullObject } from "@src/utility/Utils"
import { useDispatch, useSelector } from "react-redux"
import { useEffect, useState } from "react"

import Sidebar from "@components/sidebar"
import { useFormik } from "formik"
import { useTranslation } from "react-i18next"
import { categoriesOptions } from "@src/utility/Options"

const AddInterestsForm = ({ open, toggleSidebar, formType, data }) => {
  const [isSubmit, setSubmit] = useState(false)
  const dispatch = useDispatch()
  const { t } = useTranslation()

  // const jobCategories = useSelector(
  //   (state) => state.jobInterestReducer.jobCategories
  // )

  const { deleted, updated, created, createdUpdatedLoading } = useSelector(
    (state) => state.interestReducer
  )

  useEffect(() => {
    if (updated || created) resetForm()
  }, [updated, created])

  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    resetForm
  } = useFormik({
    initialValues: {
      name: "",
      category: ""
    },
    validationSchema: Yup.object().shape({
      name: Yup.string().required(t("Interest Name is required")),
      category: Yup.string().required(t("Category is required"))
    }),
    onSubmit: (values) => {
      if (formType === "edit") {
        dispatch(
          interestActions.updateInterestRequest({
            params: data.id,
            body: {
              interestName: values.name,
              category: values.category
            }
          })
        )
      } else if (formType === "add") {
        dispatch(
          interestActions.createInterestRequest({
            interestName: values.name,
            category: values.category
          })
        )
      }
      setSubmit(false)
      //toggleSidebar()
    }
  })

  useEffect(() => {

    setSubmit(false)
    if (formType === "edit" && !isNullObject(data)) {
      setFieldValue("name", data.name)
      setFieldValue("category", data.categoryValue) 
    } else {
      
      setFieldValue("name", "")
      setFieldValue("category", "")
    }
  }, [data])

  return (
    <Sidebar
      width={window.innerWidth > 992 ? "50%" : "100%"}
      size="lg"
      open={open}
      title={`${formType === "edit" ? t("Edit") : t("Add")} ${t("Interest")}`}
      headerClassName="mb-1"
      contentClassName="p-0"
      bodyClassName="pb-sm-0 pb-3"
      toggleSidebar={toggleSidebar}
    >
      <Form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmit(true)
          handleSubmit()
        }}
      >
        <div className="mb-1">
          <Label for="invoice-from" className="form-label">
            {t("Interest Name")}*
          </Label>
          <Input
            type="text"
            name="name"
            onChange={handleChange}
            value={values.name}
            onBlur={handleBlur}
            id="invoice-from"
            placeholder="Enter Interest Name"
          />
          {isSubmit && errors.name && touched.name && (
            <div className="text-danger">{errors.name}</div>
          )}
        </div>

        <div className="mb-1">
          <Label for="category" className="form-label">
            {t("Category")}*
          </Label>

          <Select
            id="category"
            name="category"
            theme={selectThemeColors}
            className="react-select"
            classNamePrefix="select"
            isClearable={false}
            placeholder="Select Category"
            bsSize="sm"
            options={categoriesOptions}
            value={categoriesOptions.find(
              (obj) => obj.value === values.category
            ) || ""}
            onChange={(e) => {
              setFieldValue("category", e.value)
            }}
            onBlur={handleBlur}
          />
          {isSubmit && errors.category && touched.category && (
            <div className="text-danger">{errors.category}</div>
          )}
        </div>

        <div className="d-flex flex-wrap mt-2">
          <Button
            type="submit"
            className="me-1"
            color="primary"
            disabled={createdUpdatedLoading}
          >
            {createdUpdatedLoading ? (
              <Spinner className="me-1" size="sm" />
            ) : null}
            {t("Save")}
          </Button>
          <Button
            color="secondary"
            outline
            onClick={() => {
              toggleSidebar()
              setSubmit(false)
            }}
            disabled={createdUpdatedLoading}
          >
            {t("Cancel")}
          </Button>
        </div>
      </Form>
      {createdUpdatedLoading ? (
        <Alert color="success">
          <div className="alert-body font-small-2 mt-2">
            <p>
              <small className="me-50">
                <span className="fw-bold">
                  {formType === "edit" ? t("Updating") : t("Adding")}...
                </span>
              </small>
            </p>
          </div>
        </Alert>
      ) : null}
    </Sidebar>
  )
}

export default AddInterestsForm
