// ** React Imports
import { Fragment, useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"

import * as groupActions from "@src/store/common/groupManagement/actions"

// ** Reactstrap Imports
import {
  Row,
  Col,
  Card,
  Label,
  Input,
  Table,
  Spinner,
  Modal,
  Button,
  CardBody,
  ModalBody,
  ModalHeader,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  UncontrolledDropdown,
  FormFeedback,
  UncontrolledTooltip,
  Badge
} from "reactstrap"
import Select from "react-select"

// ** Third Party Components

import {
  Copy,
  Edit,
  MoreVertical,
  Trash,
  Info,
  MessageSquare,
  Link2
} from "react-feather"
// import { useForm, Controller } from "react-hook-form"

// ** Custom Components
import { useDispatch, useSelector } from "react-redux"
import * as Yup from "yup"

import { useFormik } from "formik"

import {
  fieldExists,
  getProfileId,
  getUserData,
  isObjEmpty
} from "@src/utility/Utils"
import Avatar from "@src/@core/components/avatar"

import { selectThemeColors } from "@utils"

import makeAnimated from "react-select/animated"

import socketIOClient from "socket.io-client"
import { getUser } from "@src/services/apis"

const GroupCards = ({ groups, type }) => {
  // ** States
  const navigate = useNavigate()
  const [show, setShow] = useState(false)
  const [modalType, setModalType] = useState("Add New")
  const [selectedGroup, setSelectedGroup] = useState({})
  const animatedComponents = makeAnimated()
  const dispatch = useDispatch()

  const [isSubmit, setIsSubmit] = useState(false)
  const [socket] = useState(socketIOClient(process.env.REACT_APP_SOCKET_URL))

  const { courses } = useSelector((state) => state.courseReducer)
  const { users } = useSelector((state) => state.usersReducer)
  const [id, setId] = useState(null)
  const { created, updated, joinGroupLoading, creationLoading } = useSelector(
    (state) => state.groupManagementReducer
  )

  const [coursesOptions, setCoursesOptions] = useState([])
  const [membersOptions, setMembersOptions] = useState([])

  useEffect(() => {
    if (fieldExists(courses, "results") && courses.results.length > 0) {
      const a = courses.results.map((item, index) => {
        return {
          value: item.id,
          label: item.courseName + " - " + item.courseCode
        }
      })
      setCoursesOptions(a)
    } else {
      setCoursesOptions([])
    }
  }, [courses])

  useEffect(() => {
    if (fieldExists(users, "results") && users.results.length > 0) {
      const a = users.results.map((item, index) => {
        return {
          value: item.id,
          label: item?.personalInfo?.fullName + " - " + item.email
        }
      })
      setMembersOptions(a)
    } else {
      setMembersOptions([])
    }
  }, [users])

  useEffect(() => {
    if (modalType === "Edit") {
      setFieldValue("groupName", selectedGroup.groupName)
      setFieldValue(
        "courses",
        selectedGroup.courses.map((item) => {
          return {
            value: item.id,
            label: item.courseName + " - " + item.courseCode
          }
        })
      )
      setFieldValue(
        "members",
        selectedGroup.members.map((item) => {
          return {
            value: item.id,
            label: item?.personalInfo?.fullName + " - " + item.email
          }
        })
      )
    } else {
      setFieldValue("groupName", "")
      setFieldValue("courses", [])
      setFieldValue("members", [])
    }
  }, [selectedGroup, show])

  const initialValues = {
    groupName: "",
    courses: [],
    members: []
  }

  const validationSchema = Yup.object().shape({
    groupName: Yup.string().required("Required"),
    courses: Yup.array().min(1, "At least 1 course required"),
    members: Yup.array().min(2, "At least 2 members required")
  })

  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
    setValues,
    resetForm
  } = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      if (modalType === "Edit") {
        dispatch(
          groupActions.editGroupRequest({
            groupId: selectedGroup.id,
            body: {
              groupName: values.groupName,
              courses: values.courses.map((item) => item.value),
              members: values.members.map((item) => item.value)
            }
          })
        )
      } else {
        dispatch(
          groupActions.createGroupRequest({
            groupName: values.groupName,
            courses: values.courses.map((item) => item.value),
            members: values.members.map((item) => item.value)
          })
        )
      }
    }
  })

  const onReset = () => {
    setShow(false)
    setIsSubmit(false)
    resetForm()
  }

  const handleModalClosed = () => {
    setModalType("Add New")
    onReset()
  }

  const handleLeaveGroup = (groupId) => {
    dispatch(groupActions.leaveGroupRequest({ groupId }))
  }

  return (
    <Fragment>
      <Row>
        {!isObjEmpty(groups) &&
          groups?.results?.map((item, index) => {
            return (
              <Col key={index} xl={4} md={6}>
                <Card className="cursor-pointer design-group-card">
                  <CardBody>
                    <div className="d-flex justify-content-between">
                      <div className="role-heading">
                        <h4 className="fw-bolder text-capitalize text-truncate w-90">
                          {item.groupName}
                        </h4>
                        {item?.creator?.id === getProfileId() && (
                          <small className="text-muted text-nowrap">
                            Admin : {item?.creator?.personalInfo?.fullName}
                          </small>
                        )}
                      </div>
                      <div className="d-flex">
                        {type === "my" ? (
                          <>
                            <Button
                              color="primary"
                              className="text-nowrap mb-1 me-1"
                              size="sm"
                              onClick={() => {
                                navigate("/group?id=" + item.id)
                              }}
                            >
                              <MessageSquare size={18} className="me-50" />
                              <span className="align-middle">View</span>
                            </Button>

                            <UncontrolledDropdown className="chart-dropdown">
                              <DropdownToggle
                                color=""
                                className="bg-transparent btn-sm border-0 p-50"
                              >
                                <MoreVertical
                                  size={18}
                                  className="cursor-pointer"
                                />
                              </DropdownToggle>
                              <DropdownMenu end>
                                {item?.creator?.id === getProfileId() ? (
                                  <DropdownItem
                                    className="w-100"
                                    onClick={(e) => {
                                      e.preventDefault()
                                      setSelectedGroup(item)
                                      setModalType("Edit")
                                      setShow(true)
                                    }}
                                  >
                                    <Edit size={18} className="me-50" />
                                    <span className="align-middle">Edit</span>
                                  </DropdownItem>
                                ) : 
                                item?.members?.find(
                                  (obj) => obj.id == getProfileId()
                                ) ?
                                
                                (
                                  <DropdownItem
                                    className="w-100"
                                    onClick={(e) => {
                                      e.preventDefault()
                                      handleLeaveGroup(item.id)
                                    }}
                                  >
                                    <Trash size={18} className="me-50" />
                                    <span className="align-middle">
                                      Leave Group
                                    </span>
                                  </DropdownItem>
                                )
                                : null
                                
                                }
                              </DropdownMenu>
                            </UncontrolledDropdown>
                          </>
                        ) : !item?.joinRequests?.find(
                            (obj) => obj.id == getProfileId()
                          ) ? (
                          !item?.members?.find(
                            (obj) => obj.id == getProfileId()
                          ) ? (
                            <Button
                              color="primary"
                              className="text-nowrap mb-1 me-1"
                              size="sm"
                              onClick={(e) => {
                                e.preventDefault()
                                socket.emit("joinRequest", {
                                  user: getUserData(),
                                  groupId: item.id,
                                  groupName: item.groupName,
                                  creator: item.creator.id
                                })
                                dispatch(groupActions.joinGroupRequest(item.id))
                                setId(item.id)
                              }}
                              disabled={joinGroupLoading && id === item.id}
                            >
                              {joinGroupLoading && id === item.id ? (
                                <>
                                  <Spinner className="me-1" size="sm" />
                                  <span className="align-middle">
                                    Sending Request
                                  </span>
                                </>
                              ) : (
                                <>
                                  {" "}
                                  <Link2 size={18} className="me-50" />
                                  <span className="align-middle">Join</span>
                                </>
                              )}
                            </Button>
                          ) : (
                            <Button
                              color="primary"
                              className="text-nowrap mb-1 me-1"
                              size="sm"
                              disabled
                              onClick={(e) => {}}
                            >
                              <span className="align-middle">Member</span>
                            </Button>
                          )
                        ) : (
                          <Button
                            color="primary"
                            className="text-nowrap mb-1 me-1"
                            size="sm"
                            disabled
                            onClick={(e) => {}}
                          >
                            <Info size={18} className="me-50" />
                            <span className="align-middle">Pending</span>
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="d-flex justify-content-between align-items-end">
                      <div className="design-group mb-50 pt-50">
                        <h6 className="section-label">Courses</h6>
                        {item?.courses?.map((course, index) => {
                          return (
                            <Badge
                              key={index}
                              className="me-1"
                              color="light-primary"
                            >
                              {course?.courseName}
                            </Badge>
                          )
                        })}
                      </div>
                      <div className="design-group pt-25">
                        <h6 className="section-label">Members</h6>
                        {item?.members?.slice(0, 3).map((obj, index) => {
                          let memberAvatar = {
                            content: obj?.personalInfo?.fullName ?? "",
                            color: "light-warning",
                            initials: true,
                            title: obj?.personalInfo?.fullName ?? ""
                          }
                          return (
                            <Avatar
                              key={index}
                              className="me-75"
                              {...memberAvatar}
                            />
                          )
                        })}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Col>
            )
          })}
      </Row>
      <Modal
        isOpen={show}
        onClosed={handleModalClosed}
        toggle={() => setShow(!show)}
        className="modal-dialog-centered modal-lg"
      >
        <ModalHeader
          className="bg-transparent"
          toggle={() => setShow(!show)}
        ></ModalHeader>
        <ModalBody className="px-5 pb-5">
          <div className="text-center mb-4">
            <h1>{modalType} Group</h1>
            <p>Fill out the details</p>
          </div>
          <Row
            tag="form"
            onSubmit={(e) => {
              e.preventDefault()
              setIsSubmit(true)
              handleSubmit()
            }}
          >
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="groupName">
                Group Name
              </Label>
              <Input
                type="text"
                id="groupName"
                name="groupName"
                placeholder="Enter group name"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.groupName}
              />
              {isSubmit && errors.groupName && touched.groupName ? (
                <div className="error-message text-danger">
                  {errors.groupName}
                </div>
              ) : null}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="courses">
                Courses
              </Label>
              <Select
                id="courses"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={coursesOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="courses"
                value={values.courses}
                onChange={(value) => {
                  setFieldValue("courses", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.courses && (
                <div className="text-danger text-small mt-50">
                  {errors.courses}
                </div>
              )}
            </Col>
            <Col xs={12} className="mb-1">
              <Label className="form-label" for="members">
                Members
              </Label>

              <Select
                id="members"
                theme={selectThemeColors}
                className="react-select"
                classNamePrefix="select"
                options={membersOptions}
                isClearable={false}
                components={animatedComponents}
                closeMenuOnSelect={true}
                isMulti
                name="members"
                value={values.members}
                onChange={(value) => {
                  setFieldValue("members", value)
                }}
                onBlur={handleBlur}
              />
              {isSubmit && errors.members && (
                <div className="text-danger text-small mt-50">
                  {errors.members}
                </div>
              )}
            </Col>
            <Col className="text-center mt-2" xs={12}>
              <Button
                type="submit"
                color="primary"
                className="me-1"
                disabled={creationLoading}
              >
                {creationLoading ? (
                  <Spinner className="me-1" size="sm" />
                ) : null}
                Submit
              </Button>
              <Button
                type="reset"
                outline
                onClick={onReset}
                disabled={creationLoading}
              >
                Discard
              </Button>
            </Col>
          </Row>
        </ModalBody>
      </Modal>
    </Fragment>
  )
}

export default GroupCards
